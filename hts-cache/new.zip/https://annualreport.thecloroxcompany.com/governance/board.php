<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=Edge"/>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="../_images/global/shareImage.png?v.2018.1" />

<title>Clorox 2018 Integrated Annual Report</title>
<link rel="stylesheet" href="../_css/main.css?v.2018.4">
<link rel="stylesheet" href="../_js/jquery.fancybox.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	    <script src="//assets.adobedtm.com/cfd7100a02cbfa40b2c485d333da22f89ccabd9c/satelliteLib-e1a96af74edf26406b64b1c5cb0abedb7b5a6c6c.js"></script>
	</head>
<body class="scorecardInterior">
<header>
	<div class="header__hamburger">
		<span>MENU</span>
		<div class="header__hamburger__bars">
			<div></div>
		</div>
	</div>

	<a class="logoWrap" href="../index.php">
		<img class="header__logo" src="../_images/global/logo.svg">
	</a>
    <div class="container container--header">
        <div class="row">
			<div class="header__links">
				<span class="ir">2018 Integrated Annual Report</span>
				<ul>
					<li><a class="header__links__resources" href="#">Resources</a></li>
					<li><a class="header__links__download" href="#">Download</a></li>
					<li><a class="header__links__search" href="#"><i class="fas fa-search"></i></a></li>
					<li class="socialLink facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="socialLink twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
					<li class="socialLink linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="socialLink"><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
				</ul>
			</div>

			<div class="headerSearch">
				<div class="headerSearch__relativeWrapper">
					<form action="../search.php">
						<input class="headerSearch__input" type="text" class="search" name="q" id="tipue_search_input" autocomplete="off" placeholder="Search" required="">
						<span class="headerSearch__del">X</span>
					</form>
				</div>
			</div>

			<div class="headerResources">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../about.php">About This Report</a></li>
						<li><a href="../materiality.php">Materiality Overview</a></li>
						<li><a href="../gri.php">GRI Content Index</a></li>
						<li><a href="../info.php">Stockholder Information</a></li>
						<li><a target="_blank" href="https://www.thecloroxcompany.com/">The Clorox Company</a></li>
					</ul>
				</div>
			</div>

			<div class="downloads">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../Clorox_2018_Integrated_Report.pdf?v10-11-2018" target="_blank">Full PDF</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_English.pdf" target="_blank">Executive Summary English</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_Spanish.pdf" target="_blank">Executive Summary Spanish</a></li>
					</ul>
				</div>
			</div>
        </div>
	</div>

	<nav class="mainNav">
		<div class="mainNav__box mainNav__box--1">
			<a class="mainNav__mainLink" href="../ceo-letter/">CEO Letter</a>

			<img src="../_images/global/nav1.png" class="mainNav__product mainNav__product--1">
		</div>

		<div class="mainNav__box mainNav__box--2">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../strategy/">2020 Strategy</a>

				<ul class="secondaryNav">
					<li><a href="../strategy/people.php">Engage our People</a></li>
					<li><a href="../strategy/value.php">Drive Superior Consumer Value</a></li>
					<li><a href="../strategy/portfolio.php">Accelerate Portfolio Momentum</a></li>
					<li><a href="../strategy/growth.php">Fund Growth</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav2.png" class="mainNav__product mainNav__product--2">
		</div>

		<div class="mainNav__box mainNav__box--3">
			<a class="mainNav__mainLink" href="../innovation/">Innovation</a>

			<img src="../_images/global/nav3.png" class="mainNav__product mainNav__product--3">
		</div>

		<div class="mainNav__box mainNav__box--4">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../scorecard/">Scorecard</a>

				<ul class="secondaryNav">
					<li><a href="../scorecard/footprint.php">Global Footprint</a></li>
					<li><a href="../scorecard/performance.php">Performance</a></li>
					<li><a href="../scorecard/product.php">Product</a></li>
					<li><a href="../scorecard/people.php">People</a></li>
					<li><a href="../scorecard/community.php">Community</a></li>
					<li><a href="../scorecard/planet.php">Planet</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav4.png" class="mainNav__product mainNav__product--4">
		</div>

		<div class="mainNav__box mainNav__box--5">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../recognitions/">Recognitions</a>

				<ul class="secondaryNav">
					<li><a href="../recognitions/">Company Recognitions</a></li>
					<li><a href="../recognitions/brand.php">Brand Recognitions</a></li>
				</ul>
			</div>
			<img src="../_images/global/nav5.png" class="mainNav__product mainNav__product--5">
		</div>

		<div class="mainNav__box mainNav__box--6">
			<a class="mainNav__mainLink" href="../financials/">Financials</a>

			<img src="../_images/global/nav6.png" class="mainNav__product mainNav__product--6">
		</div>

		<div class="mainNav__box mainNav__box--7">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../governance/">Governance</a>

				<ul class="secondaryNav">
					<li><a href="../governance/board.php">Board of Directors</a></li>
					<li><a href="../governance/committee.php">Executive Committee</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav7.png" class="mainNav__product mainNav__product--7">
		</div>

		<div class="mainNav__box mainNav__box--mobile">
			<ul>
				<li class="facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li class="twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li class="linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
			</ul>
		</div>
	</nav>
</header>
<div class="interiorWrapper interiorWrapper--gov">
	<div class="container">        
        <div class="row">
            <div class="boardWrap">
                <div class="scoreRow">
                    <h1 class="pageTitle pageTitle--board">board of<br> directors</h1>

                    <div class="shelf shelf--board shelf--board--1">
                        <div class="boardMember">
                            <div class="boardMember__profile">
                                <img src="../_images/governance/board/person1.png" class="boardMember__profile__image">
                                <img src="../_images/governance/board/person1.png" class="boardMember__placer">
                            </div>
                            <div class="boardMember__textWrap fade fade--up">
                                <h3 class="boardMember__name">Benno Dorer</h3>
                                <span class="boardMember__text">Chair and Chief Executive Officer,<br> The Clorox Company</span>
                            </div>
                        </div>

                        <div class="boardMember">
                            <div class="boardMember__profile">
                                <img src="../_images/governance/board/person2.png" class="boardMember__profile__image">
                                <img src="../_images/governance/board/person2.png" class="boardMember__placer">
                            </div>

                            <div class="boardMember__textWrap fade fade--up">
                                <h3 class="boardMember__name">Pamela Thomas-Graham</h3>
                                <span class="boardMember__text">Lead Independent Director</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="scoreRow">
                    <div class="shelf shelf--board shelf--board--2">
                        <div class="boardMember">
                            <div class="boardMember__profile">
                                <img src="../_images/governance/board/person3.png" class="boardMember__profile__image">
                                <img src="../_images/governance/board/person3.png" class="boardMember__placer">
                            </div>

                            <div class="boardMember__textWrap fade fade--up">
                                <h3 class="boardMember__name">Amy Banse</h3>
                                <span class="boardMember__text">Managing Director and Head<br> of Funds, Comcast Ventures</span>
                            </div>
                        </div>

                        <div class="boardMember">
                            <div class="boardMember__profile">
                                <img src="../_images/governance/board/person4.png" class="boardMember__profile__image">
                                <img src="../_images/governance/board/person4.png" class="boardMember__placer">
                            </div>

                            <div class="boardMember__textWrap fade fade--up">
                                <h3 class="boardMember__name">Richard H. Carmona,<br> M.D., M.P.H., F.A.C.S.</h3>
                                <span class="boardMember__text">Chief of Health Innovations,<br> Canyon Ranch; former<br> U.S. Surgeon General</span>
                            </div>
                        </div>

                        <div class="boardMember">
                            <div class="boardMember__profile">
                                <img src="../_images/governance/board/person5.png" class="boardMember__profile__image">
                                <img src="../_images/governance/board/person5.png" class="boardMember__placer">
                            </div>

                            <div class="boardMember__textWrap fade fade--up">
                                <h3 class="boardMember__name">Spencer C. Fleischer</h3>
                                <span class="boardMember__text">Managing Partner,<br> FFL Partners</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="scoreRow">
                    <div class="shelf shelf--board shelf--board--3">
                        <div class="boardMember">
                            <div class="boardMember__profile">
                                <img src="../_images/governance/board/person6.png" class="boardMember__profile__image">
                                <img src="../_images/governance/board/person6.png" class="boardMember__placer">
                            </div>

                            <div class="boardMember__textWrap fade fade--up">
                                <h3 class="boardMember__name">Esther Lee</h3>
                                <span class="boardMember__text">Executive Vice President —<br> Global Chief Marketing<br> Officer, MetLife Inc.</span>
                            </div>
                        </div>

                        <div class="boardMember">
                            <div class="boardMember__profile">
                                <img src="../_images/governance/board/person7.png" class="boardMember__profile__image">
                                <img src="../_images/governance/board/person7.png" class="boardMember__placer">
                            </div>

                            <div class="boardMember__textWrap fade fade--up">
                                <h3 class="boardMember__name">A.D. David Mackay</h3>
                                <span class="boardMember__text">Retired President and<br> Chief Executive Officer,<br> Kellogg Company</span>
                            </div>
                        </div>

                        <div class="boardMember">
                            <div class="boardMember__profile">
                                <img src="../_images/governance/board/person8.png" class="boardMember__profile__image">
                                <img src="../_images/governance/board/person8.png" class="boardMember__placer">
                            </div>

                            <div class="boardMember__textWrap fade fade--up">
                                <h3 class="boardMember__name">Robert W. Matschullat</h3>
                                <span class="boardMember__text">Retired Vice Chairman<br> and Chief Financial Officer,<br> The Seagram Company Ltd.</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="scoreRow">
                    <div class="shelf shelf--board shelf--board--4">
                        <div class="boardMember">
                            <div class="boardMember__profile">
                                <img src="../_images/governance/board/person9.png" class="boardMember__profile__image">
                                <img src="../_images/governance/board/person9.png" class="boardMember__placer">
                            </div>

                            <div class="boardMember__textWrap fade fade--up">
                                <h3 class="boardMember__name">Jeffrey Noddle</h3>
                                <span class="boardMember__text">Retired Executive<br> Chairman, SuperValu Inc.</span>
                                <p class="boardMember__footnote">Mr. Noddle will retire from the board of directors<br> effective November 2018.</p>
                            </div>
                        </div>

                        <div class="boardMember">
                            <div class="boardMember__profile">
                                <img src="../_images/governance/board/person10.png" class="boardMember__profile__image">
                                <img src="../_images/governance/board/person10.png" class="boardMember__placer">
                            </div>

                            <div class="boardMember__textWrap fade fade--up">
                                <h3 class="boardMember__name">Matthew J. Shattock</h3>
                                <span class="boardMember__text">Chairman and CEO,<br> Beam Suntory Inc.</span>
                                <p class="boardMember__footnote">Mr. Shattock joined the board of directors<br> Aug. 1, 2018.</p>
                            </div>
                        </div>

                        <div class="boardMember">
                            <div class="boardMember__profile">
                                <img src="../_images/governance/board/person11.png" class="boardMember__profile__image">
                                <img src="../_images/governance/board/person11.png" class="boardMember__placer">
                            </div>

                            <div class="boardMember__textWrap fade fade--up">
                                <h3 class="boardMember__name">Carolyn M. Ticknor</h3>
                                <span class="boardMember__text">Retired President,<br> Imaging & Printing Systems,<br> Hewlett-Packard Company</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="scoreRow">
                    <div class="shelf shelf--board shelf--board--5">
                        <div class="boardMember">
                            <div class="boardMember__profile">
                                <img src="../_images/governance/board/person12.png" class="boardMember__profile__image">
                                <img src="../_images/governance/board/person12.png" class="boardMember__placer">
                            </div>

                            <div class="boardMember__textWrap fade fade--up">
                                <h3 class="boardMember__name">Russell J. Weiner</h3>
                                <span class="boardMember__text">Chief Operating Officer and<br> President of the Americas,<br> Domino’s Inc.</span>
                            </div>
                        </div>

                        <div class="boardMember">
                            <div class="boardMember__profile">
                                <img src="../_images/governance/board/person13.png" class="boardMember__profile__image">
                                <img src="../_images/governance/board/person13.png" class="boardMember__placer">
                            </div>

                            <div class="boardMember__textWrap fade fade--up">
                                <h3 class="boardMember__name">Christopher J. Williams</h3>
                                <span class="boardMember__text">Chairman and Chief Executive<br> Officer, The Williams Capital<br> Group L.P. and Williams<br> Capital Management LLC</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</div>
</div>
<div class="subnav subnav--scorecard">
	<div class="container">
		<div class="row">
			<ul class="subNav__items">
                <li class="single"><a href="index.php">corporate governance</a></li>
                <li class="single"><a href="board.php">board of directors</a></li>
                <li class="single"><a href="committee.php">executive committee</a></li>
			</ul>
		</div>
	</div>
</div>
<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="../_js/jquery.fancybox.min.js"></script>
<script src="../_js/jquery.mousewheel.js"></script>
<script src="../_js/greensock/TimelineMax.min.js"></script>
<script src="../_js/greensock/TweenMax.min.js"></script>
<script src="../_js/ScrollMagic.js"></script>
<script src="../_js/plugins/jquery.ScrollMagic.js"></script>
<script src="../_js/plugins/debug.addIndicators.js"></script>
<script src="../_js/greensock/plugins/DrawSVGPlugin.min.js"></script>
<script src="../_js/plugins/animation.gsap.js"></script>
<script src="../_js/jquery.cycle2.min.js"></script>
<script src="../_js/main.js?v.2018.2"></script><script>board();</script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=Edge"/>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="../_images/global/shareImage.png?v.2018.1" />

<title>Clorox 2018 Integrated Annual Report</title>
<link rel="stylesheet" href="../_css/main.css?v.2018.4">
<link rel="stylesheet" href="../_js/jquery.fancybox.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	    <script src="//assets.adobedtm.com/cfd7100a02cbfa40b2c485d333da22f89ccabd9c/satelliteLib-e1a96af74edf26406b64b1c5cb0abedb7b5a6c6c.js"></script>
	</head>
<body class="committee">
<header>
	<div class="header__hamburger">
		<span>MENU</span>
		<div class="header__hamburger__bars">
			<div></div>
		</div>
	</div>

	<a class="logoWrap" href="../index.php">
		<img class="header__logo" src="../_images/global/logo.svg">
	</a>
    <div class="container container--header">
        <div class="row">
			<div class="header__links">
				<span class="ir">2018 Integrated Annual Report</span>
				<ul>
					<li><a class="header__links__resources" href="#">Resources</a></li>
					<li><a class="header__links__download" href="#">Download</a></li>
					<li><a class="header__links__search" href="#"><i class="fas fa-search"></i></a></li>
					<li class="socialLink facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="socialLink twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
					<li class="socialLink linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="socialLink"><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
				</ul>
			</div>

			<div class="headerSearch">
				<div class="headerSearch__relativeWrapper">
					<form action="../search.php">
						<input class="headerSearch__input" type="text" class="search" name="q" id="tipue_search_input" autocomplete="off" placeholder="Search" required="">
						<span class="headerSearch__del">X</span>
					</form>
				</div>
			</div>

			<div class="headerResources">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../about.php">About This Report</a></li>
						<li><a href="../materiality.php">Materiality Overview</a></li>
						<li><a href="../gri.php">GRI Content Index</a></li>
						<li><a href="../info.php">Stockholder Information</a></li>
						<li><a target="_blank" href="https://www.thecloroxcompany.com/">The Clorox Company</a></li>
					</ul>
				</div>
			</div>

			<div class="downloads">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../Clorox_2018_Integrated_Report.pdf?v10-11-2018" target="_blank">Full PDF</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_English.pdf" target="_blank">Executive Summary English</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_Spanish.pdf" target="_blank">Executive Summary Spanish</a></li>
					</ul>
				</div>
			</div>
        </div>
	</div>

	<nav class="mainNav">
		<div class="mainNav__box mainNav__box--1">
			<a class="mainNav__mainLink" href="../ceo-letter/">CEO Letter</a>

			<img src="../_images/global/nav1.png" class="mainNav__product mainNav__product--1">
		</div>

		<div class="mainNav__box mainNav__box--2">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../strategy/">2020 Strategy</a>

				<ul class="secondaryNav">
					<li><a href="../strategy/people.php">Engage our People</a></li>
					<li><a href="../strategy/value.php">Drive Superior Consumer Value</a></li>
					<li><a href="../strategy/portfolio.php">Accelerate Portfolio Momentum</a></li>
					<li><a href="../strategy/growth.php">Fund Growth</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav2.png" class="mainNav__product mainNav__product--2">
		</div>

		<div class="mainNav__box mainNav__box--3">
			<a class="mainNav__mainLink" href="../innovation/">Innovation</a>

			<img src="../_images/global/nav3.png" class="mainNav__product mainNav__product--3">
		</div>

		<div class="mainNav__box mainNav__box--4">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../scorecard/">Scorecard</a>

				<ul class="secondaryNav">
					<li><a href="../scorecard/footprint.php">Global Footprint</a></li>
					<li><a href="../scorecard/performance.php">Performance</a></li>
					<li><a href="../scorecard/product.php">Product</a></li>
					<li><a href="../scorecard/people.php">People</a></li>
					<li><a href="../scorecard/community.php">Community</a></li>
					<li><a href="../scorecard/planet.php">Planet</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav4.png" class="mainNav__product mainNav__product--4">
		</div>

		<div class="mainNav__box mainNav__box--5">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../recognitions/">Recognitions</a>

				<ul class="secondaryNav">
					<li><a href="../recognitions/">Company Recognitions</a></li>
					<li><a href="../recognitions/brand.php">Brand Recognitions</a></li>
				</ul>
			</div>
			<img src="../_images/global/nav5.png" class="mainNav__product mainNav__product--5">
		</div>

		<div class="mainNav__box mainNav__box--6">
			<a class="mainNav__mainLink" href="../financials/">Financials</a>

			<img src="../_images/global/nav6.png" class="mainNav__product mainNav__product--6">
		</div>

		<div class="mainNav__box mainNav__box--7">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../governance/">Governance</a>

				<ul class="secondaryNav">
					<li><a href="../governance/board.php">Board of Directors</a></li>
					<li><a href="../governance/committee.php">Executive Committee</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav7.png" class="mainNav__product mainNav__product--7">
		</div>

		<div class="mainNav__box mainNav__box--mobile">
			<ul>
				<li class="facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li class="twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li class="linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
			</ul>
		</div>
	</nav>
</header>
<div class="interiorWrapper interiorWrapper--com interiorWrapper--gov">
    <div class="container">
        <div class="row">
			<div class="content">
				<h1 class="pageTitle pageTitle--gov">Clorox executive committee</h1>
			</div>
        </div>
        
        <div class="row">
            <div class="committeeText">
                <p class="govText">The composition of the Clorox Executive Committee changed in fiscal year 2018 primarily as the result of retirements and business expansion from our Nutranext acquisition. Thanks to strong succession planning, five individuals were tapped from within the organization to lead Finance, International, Product Supply, our Nutranext and RenewLife businesses, and Information Technology. Additionally, two existing CEC members were elevated to executive vice president, with Jon Balousek assuming additional responsibility for Corporate Development and Linda Rendle assuming additional responsibility for Corporate Strategy. With the CEC’s expansion to 15 members, women now make up one-third of the senior leadership team at Clorox, with roles overseeing company operations; Legal and Corporate Affairs; Research & Development; Human Resources; and the Cleaning Division, our largest business.</p>
            </div>
		</div>
		
		<div class="row">
            <div class="committeeWrap notSurface margin-top-20 margin-bottom-20">
				<div class="committeeHover committeeHover--1">
					<img src="../_images/governance/committee/hover.svg">
					<span>Andy Mowery</span>
				</div>

				<div class="committeeHover committeeHover--2">
					<img src="../_images/governance/committee/hover.svg">
					<span>Laura Stein</span>
				</div>

				<div class="committeeHover committeeHover--3">
					<img src="../_images/governance/committee/hover.svg">
					<span>Dawn Willoughby</span>
				</div>

				<div class="committeeHover committeeHover--4">
					<img src="../_images/governance/committee/hover.svg">
					<span>Denise Garner</span>
				</div>

				<div class="committeeHover committeeHover--5">
					<img src="../_images/governance/committee/hover.svg">
					<span>Diego Barral</span>
				</div>

				<div class="committeeHover committeeHover--6">
					<img src="../_images/governance/committee/hover.svg">
					<span>Bill Bailey</span>
				</div>

				<div class="committeeHover committeeHover--7">
					<img src="../_images/governance/committee/hover.svg">
					<span>Kevin Jacobsen</span>
				</div>

				<div class="committeeHover committeeHover--8">
					<img src="../_images/governance/committee/hover.svg">
					<span>Kirsten Marriner</span>
				</div>

				<div class="committeeHover committeeHover--9">
					<img src="../_images/governance/committee/hover.svg">
					<span>Benno Dorer</span>
				</div>

				<div class="committeeHover committeeHover--10">
					<img src="../_images/governance/committee/hover.svg">
					<span>Eric Reynolds</span>
				</div>

				<div class="committeeHover committeeHover--11">
					<img src="../_images/governance/committee/hover.svg">
					<span>Linda Rendle</span>
				</div>

				<div class="committeeHover committeeHover--12">
					<img src="../_images/governance/committee/hover.svg">
					<span>Jay McNulty</span>
				</div>

				<div class="committeeHover committeeHover--13">
					<img src="../_images/governance/committee/hover.svg">
					<span>Michael Costello</span>
				</div>

				<div class="committeeHover committeeHover--14">
					<img src="../_images/governance/committee/hover.svg">
					<span>Jon Balousek</span>
				</div>

				<div class="committeeHover committeeHover--15">
					<img src="../_images/governance/committee/hover.svg">
					<span>Matt Laszlo</span>
				</div>
				
                <img src="../_images/governance/committee/image1.png" class="committeeImg">
            </div>
        </div>

        <div class="row">
            <div class="committeeCol committeeCol--first">
                <h4 class="seated">Seated from left to right:</h4>

                <h3 class="boardMember__name margin-top-20">Andy Mowery</h3>
                <span class="boardMember__text">Senior Vice President and Chief Product Supply Officer</span>

                <h3 class="boardMember__name margin-top-20">Laura Stein</h3>
                <span class="boardMember__text">Executive Vice President — General Counsel and Corporate Affairs</span>

                <h3 class="boardMember__name margin-top-20">Dawn Willoughby</h3>
                <span class="boardMember__text">Executive Vice President and Chief Operating Officer</span>

                <h3 class="boardMember__name margin-top-20">Denise Garner</h3>
                <span class="boardMember__text">Senior Vice President and Chief Innovation Officer</span>

            </div>

            <div class="committeeCol">
                <h3 class="boardMember__name">Diego Barral</h3>
                <span class="boardMember__text">Senior Vice President and General Manager — International Division</span>

                <h4 class="seated margin-top-20">Standing from left to right:</h4>

                <h3 class="boardMember__name margin-top-20">Bill Bailey</h3>
                <span class="boardMember__text">Senior Vice President — Corporate Business Development</span>

                <h3 class="boardMember__name margin-top-20">Kevin Jacobsen</h3>
                <span class="boardMember__text">Senior Vice President and Chief Financial Officer</span>

                <h3 class="boardMember__name margin-top-20">Kirsten Marriner</h3>
                <span class="boardMember__text">Senior Vice President and Chief People Officer</span>

            </div>

            <div class="committeeCol">
                <h3 class="boardMember__name">Benno Dorer</h3>
                <span class="boardMember__text">Chair and Chief<br> Executive Officer</span>

                <h3 class="boardMember__name margin-top-20">Eric Reynolds</h3>
                <span class="boardMember__text">Senior Vice President and Chief Marketing Officer</span>

                <h3 class="boardMember__name margin-top-20">Linda Rendle</h3>
                <span class="boardMember__text">Executive Vice President — Cleaning and Strategy</span>

                <h3 class="boardMember__name margin-top-20">Jay McNulty</h3>
                <span class="boardMember__text">Senior Vice President and Chief Information Officer</span>
            </div>

            <div class="committeeCol">
                <h3 class="boardMember__name">Michael Costello</h3>
                <span class="boardMember__text">Senior Vice President and General Manager — Nutranext and RenewLife</span>

                <h3 class="boardMember__name margin-top-20">Jon Balousek</h3>
                <span class="boardMember__text">Executive Vice President — Specialty and Corporate Development</span>

                <h3 class="boardMember__name margin-top-20">Matt Laszlo</h3>
                <span class="boardMember__text">Senior Vice President and Chief Customer Officer</span>
            </div>
        </div>
    </div>

</div>

<div class="subnav subnav--scorecard">
	<div class="container">
		<div class="row">
			<ul class="subNav__items">
                <li class="single"><a href="index.php">corporate governance</a></li>
                <li class="single"><a href="board.php">board of directors</a></li>
                <li class="single"><a href="committee.php">executive committee</a></li>
			</ul>
		</div>
	</div>
</div>
<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="../_js/jquery.fancybox.min.js"></script>
<script src="../_js/jquery.mousewheel.js"></script>
<script src="../_js/greensock/TimelineMax.min.js"></script>
<script src="../_js/greensock/TweenMax.min.js"></script>
<script src="../_js/ScrollMagic.js"></script>
<script src="../_js/plugins/jquery.ScrollMagic.js"></script>
<script src="../_js/plugins/debug.addIndicators.js"></script>
<script src="../_js/greensock/plugins/DrawSVGPlugin.min.js"></script>
<script src="../_js/plugins/animation.gsap.js"></script>
<script src="../_js/jquery.cycle2.min.js"></script>
<script src="../_js/main.js?v.2018.2"></script></body>
</html>
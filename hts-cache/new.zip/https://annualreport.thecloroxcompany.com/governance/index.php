<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=Edge"/>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="../_images/global/shareImage.png?v.2018.1" />

<title>Clorox 2018 Integrated Annual Report</title>
<link rel="stylesheet" href="../_css/main.css?v.2018.4">
<link rel="stylesheet" href="../_js/jquery.fancybox.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	    <script src="//assets.adobedtm.com/cfd7100a02cbfa40b2c485d333da22f89ccabd9c/satelliteLib-e1a96af74edf26406b64b1c5cb0abedb7b5a6c6c.js"></script>
	</head>
<body>
<header>
	<div class="header__hamburger">
		<span>MENU</span>
		<div class="header__hamburger__bars">
			<div></div>
		</div>
	</div>

	<a class="logoWrap" href="../index.php">
		<img class="header__logo" src="../_images/global/logo.svg">
	</a>
    <div class="container container--header">
        <div class="row">
			<div class="header__links">
				<span class="ir">2018 Integrated Annual Report</span>
				<ul>
					<li><a class="header__links__resources" href="#">Resources</a></li>
					<li><a class="header__links__download" href="#">Download</a></li>
					<li><a class="header__links__search" href="#"><i class="fas fa-search"></i></a></li>
					<li class="socialLink facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="socialLink twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
					<li class="socialLink linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="socialLink"><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
				</ul>
			</div>

			<div class="headerSearch">
				<div class="headerSearch__relativeWrapper">
					<form action="../search.php">
						<input class="headerSearch__input" type="text" class="search" name="q" id="tipue_search_input" autocomplete="off" placeholder="Search" required="">
						<span class="headerSearch__del">X</span>
					</form>
				</div>
			</div>

			<div class="headerResources">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../about.php">About This Report</a></li>
						<li><a href="../materiality.php">Materiality Overview</a></li>
						<li><a href="../gri.php">GRI Content Index</a></li>
						<li><a href="../info.php">Stockholder Information</a></li>
						<li><a target="_blank" href="https://www.thecloroxcompany.com/">The Clorox Company</a></li>
					</ul>
				</div>
			</div>

			<div class="downloads">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../Clorox_2018_Integrated_Report.pdf?v10-11-2018" target="_blank">Full PDF</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_English.pdf" target="_blank">Executive Summary English</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_Spanish.pdf" target="_blank">Executive Summary Spanish</a></li>
					</ul>
				</div>
			</div>
        </div>
	</div>

	<nav class="mainNav">
		<div class="mainNav__box mainNav__box--1">
			<a class="mainNav__mainLink" href="../ceo-letter/">CEO Letter</a>

			<img src="../_images/global/nav1.png" class="mainNav__product mainNav__product--1">
		</div>

		<div class="mainNav__box mainNav__box--2">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../strategy/">2020 Strategy</a>

				<ul class="secondaryNav">
					<li><a href="../strategy/people.php">Engage our People</a></li>
					<li><a href="../strategy/value.php">Drive Superior Consumer Value</a></li>
					<li><a href="../strategy/portfolio.php">Accelerate Portfolio Momentum</a></li>
					<li><a href="../strategy/growth.php">Fund Growth</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav2.png" class="mainNav__product mainNav__product--2">
		</div>

		<div class="mainNav__box mainNav__box--3">
			<a class="mainNav__mainLink" href="../innovation/">Innovation</a>

			<img src="../_images/global/nav3.png" class="mainNav__product mainNav__product--3">
		</div>

		<div class="mainNav__box mainNav__box--4">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../scorecard/">Scorecard</a>

				<ul class="secondaryNav">
					<li><a href="../scorecard/footprint.php">Global Footprint</a></li>
					<li><a href="../scorecard/performance.php">Performance</a></li>
					<li><a href="../scorecard/product.php">Product</a></li>
					<li><a href="../scorecard/people.php">People</a></li>
					<li><a href="../scorecard/community.php">Community</a></li>
					<li><a href="../scorecard/planet.php">Planet</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav4.png" class="mainNav__product mainNav__product--4">
		</div>

		<div class="mainNav__box mainNav__box--5">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../recognitions/">Recognitions</a>

				<ul class="secondaryNav">
					<li><a href="../recognitions/">Company Recognitions</a></li>
					<li><a href="../recognitions/brand.php">Brand Recognitions</a></li>
				</ul>
			</div>
			<img src="../_images/global/nav5.png" class="mainNav__product mainNav__product--5">
		</div>

		<div class="mainNav__box mainNav__box--6">
			<a class="mainNav__mainLink" href="../financials/">Financials</a>

			<img src="../_images/global/nav6.png" class="mainNav__product mainNav__product--6">
		</div>

		<div class="mainNav__box mainNav__box--7">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../governance/">Governance</a>

				<ul class="secondaryNav">
					<li><a href="../governance/board.php">Board of Directors</a></li>
					<li><a href="../governance/committee.php">Executive Committee</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav7.png" class="mainNav__product mainNav__product--7">
		</div>

		<div class="mainNav__box mainNav__box--mobile">
			<ul>
				<li class="facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li class="twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li class="linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
			</ul>
		</div>
	</nav>
</header>
<div class="interiorWrapper interiorWrapper--gov">
<div class="govWave"><img src="../_images/about/wave.svg"></div>
    <div class="container">
        <div class="row">
			<div class="content">
				<h1 class="pageTitle pageTitle--gov">corporate governance</h1>
                <h2 class="sectionSubHeading centered">Clorox remains at the forefront of good governance, continually assessing our existing framework to identify new opportunities to deliver Good Growth and provide long-term shareholder value.</h2>
                
                <p class="govText">Steps taken by the board in fiscal year 2018 reinforced a culture of independence and our leadership in adopting best practices.</p>

                <h3 class="govHeading">• Shareholder Engagement</h3>
                <p class="govText padding-left-10">As part of stockholder engagement on environmental, social and governance issues, the board, represented by its independent lead director, collaborated with senior management to meet with significant institutional investors and highlight our progress in areas such as diversity and environmental sustainability, which play a strategic role in long-term growth.</p>

                <h3 class="govHeading">• Expansion of Board Oversight</h3>
                <p class="govText padding-left-10">The board took a number of steps in recognition of the importance of greater oversight for certain critical issues:</p>
                <ul class="list govText">
					<li>The newly renamed Nominating, Governance and Corporate Responsibility Committee now formally includes corporate responsibility matters. The official change is detailed in the committee charter.</li>
					<li>Consistent with best practices, the board amended guidelines to oversee decisions about the company’s political contributions.</li>
					<li>Standing cybersecurity updates are now part of the agenda at every meeting of the Audit Committee.</li>
                </ul>

				<h3 class="govHeading margin-top-20">• Implementation of Individual Director and Peer Assessments</h3>
				<p class="govText padding-left-10">It’s important for the board to include directors who have the right skill sets to meet our evolving business needs, can offer a variety of experiences and backgrounds, and can bring fresh perspectives.</p>
				<ul class="list govText">
					<li>Individual director and peer assessments, considered a best practice, are now used by the board to help identify areas of opportunity that would make the board composition even stronger. These assessments also support overall board effectiveness and serve to complement the annual board and committee evaluations that were already in place to enhance the performance of these bodies, as well as overall governance practices.</li>
				</ul>
			</div>
		</div>
    </div>
</div>

<div class="landingFooter"><div class="subnav subnav--scorecard">
	<div class="container">
		<div class="row">
			<ul class="subNav__items">
                <li class="single"><a href="index.php">corporate governance</a></li>
                <li class="single"><a href="board.php">board of directors</a></li>
                <li class="single"><a href="committee.php">executive committee</a></li>
			</ul>
		</div>
	</div>
</div></div>

<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="../_js/jquery.fancybox.min.js"></script>
<script src="../_js/jquery.mousewheel.js"></script>
<script src="../_js/greensock/TimelineMax.min.js"></script>
<script src="../_js/greensock/TweenMax.min.js"></script>
<script src="../_js/ScrollMagic.js"></script>
<script src="../_js/plugins/jquery.ScrollMagic.js"></script>
<script src="../_js/plugins/debug.addIndicators.js"></script>
<script src="../_js/greensock/plugins/DrawSVGPlugin.min.js"></script>
<script src="../_js/plugins/animation.gsap.js"></script>
<script src="../_js/jquery.cycle2.min.js"></script>
<script src="../_js/main.js?v.2018.2"></script></body>
</html>
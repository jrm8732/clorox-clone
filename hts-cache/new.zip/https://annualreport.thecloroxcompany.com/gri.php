<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=Edge"/>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="_images/global/shareImage.png?v.2018.1" />

<title>Clorox 2018 Integrated Annual Report</title>
<link rel="stylesheet" href="_css/main.css?v.2018.4">
<link rel="stylesheet" href="_js/jquery.fancybox.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	    <script src="//assets.adobedtm.com/cfd7100a02cbfa40b2c485d333da22f89ccabd9c/satelliteLib-e1a96af74edf26406b64b1c5cb0abedb7b5a6c6c.js"></script>
	</head>
<body>
<header>
	<div class="header__hamburger">
		<span>MENU</span>
		<div class="header__hamburger__bars">
			<div></div>
		</div>
	</div>

	<a class="logoWrap" href="index.php">
		<img class="header__logo" src="_images/global/logo.svg">
	</a>
    <div class="container container--header">
        <div class="row">
			<div class="header__links">
				<span class="ir">2018 Integrated Annual Report</span>
				<ul>
					<li><a class="header__links__resources" href="#">Resources</a></li>
					<li><a class="header__links__download" href="#">Download</a></li>
					<li><a class="header__links__search" href="#"><i class="fas fa-search"></i></a></li>
					<li class="socialLink facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="socialLink twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
					<li class="socialLink linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="socialLink"><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
				</ul>
			</div>

			<div class="headerSearch">
				<div class="headerSearch__relativeWrapper">
					<form action="search.php">
						<input class="headerSearch__input" type="text" class="search" name="q" id="tipue_search_input" autocomplete="off" placeholder="Search" required="">
						<span class="headerSearch__del">X</span>
					</form>
				</div>
			</div>

			<div class="headerResources">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="about.php">About This Report</a></li>
						<li><a href="materiality.php">Materiality Overview</a></li>
						<li><a href="gri.php">GRI Content Index</a></li>
						<li><a href="info.php">Stockholder Information</a></li>
						<li><a target="_blank" href="https://www.thecloroxcompany.com/">The Clorox Company</a></li>
					</ul>
				</div>
			</div>

			<div class="downloads">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="Clorox_2018_Integrated_Report.pdf?v10-11-2018" target="_blank">Full PDF</a></li>
						<li><a href="Clorox_2018_Executive_Summary_English.pdf" target="_blank">Executive Summary English</a></li>
						<li><a href="Clorox_2018_Executive_Summary_Spanish.pdf" target="_blank">Executive Summary Spanish</a></li>
					</ul>
				</div>
			</div>
        </div>
	</div>

	<nav class="mainNav">
		<div class="mainNav__box mainNav__box--1">
			<a class="mainNav__mainLink" href="ceo-letter/">CEO Letter</a>

			<img src="_images/global/nav1.png" class="mainNav__product mainNav__product--1">
		</div>

		<div class="mainNav__box mainNav__box--2">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="strategy/">2020 Strategy</a>

				<ul class="secondaryNav">
					<li><a href="strategy/people.php">Engage our People</a></li>
					<li><a href="strategy/value.php">Drive Superior Consumer Value</a></li>
					<li><a href="strategy/portfolio.php">Accelerate Portfolio Momentum</a></li>
					<li><a href="strategy/growth.php">Fund Growth</a></li>
				</ul>
			</div>

			<img src="_images/global/nav2.png" class="mainNav__product mainNav__product--2">
		</div>

		<div class="mainNav__box mainNav__box--3">
			<a class="mainNav__mainLink" href="innovation/">Innovation</a>

			<img src="_images/global/nav3.png" class="mainNav__product mainNav__product--3">
		</div>

		<div class="mainNav__box mainNav__box--4">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="scorecard/">Scorecard</a>

				<ul class="secondaryNav">
					<li><a href="scorecard/footprint.php">Global Footprint</a></li>
					<li><a href="scorecard/performance.php">Performance</a></li>
					<li><a href="scorecard/product.php">Product</a></li>
					<li><a href="scorecard/people.php">People</a></li>
					<li><a href="scorecard/community.php">Community</a></li>
					<li><a href="scorecard/planet.php">Planet</a></li>
				</ul>
			</div>

			<img src="_images/global/nav4.png" class="mainNav__product mainNav__product--4">
		</div>

		<div class="mainNav__box mainNav__box--5">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="recognitions/">Recognitions</a>

				<ul class="secondaryNav">
					<li><a href="recognitions/">Company Recognitions</a></li>
					<li><a href="recognitions/brand.php">Brand Recognitions</a></li>
				</ul>
			</div>
			<img src="_images/global/nav5.png" class="mainNav__product mainNav__product--5">
		</div>

		<div class="mainNav__box mainNav__box--6">
			<a class="mainNav__mainLink" href="financials/">Financials</a>

			<img src="_images/global/nav6.png" class="mainNav__product mainNav__product--6">
		</div>

		<div class="mainNav__box mainNav__box--7">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="governance/">Governance</a>

				<ul class="secondaryNav">
					<li><a href="governance/board.php">Board of Directors</a></li>
					<li><a href="governance/committee.php">Executive Committee</a></li>
				</ul>
			</div>

			<img src="_images/global/nav7.png" class="mainNav__product mainNav__product--7">
		</div>

		<div class="mainNav__box mainNav__box--mobile">
			<ul>
				<li class="facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li class="twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li class="linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
			</ul>
		</div>
	</nav>
</header>
<div class="interiorWrapper interiorWrapper--materiality">
    <div class="container">
        <div class="row">
			<div class="materialityContent">
				<h1 class="pageTitle pageTitle--visible pageTitle--materiality">GRI Content Index</h1>
				<h3 class="sectionSubHeading centered">General Disclosures</h3>
			</div>
		</div>

		<div class="row">
			<div class="griWrap">
				<div class="griSection active">
					<div class="griSection__heading">ORGANIZATIONAL PROFILE</div>
					<table class="griTable">
						<thead>
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>102-1</td>
								<td>Name of the organization</td>
								<td>The Clorox Company</td>
								<td>CEO Letter reinforces Clorox&apos;s <br />commitment to the UN Global <br />Compact Ten Principles.</td>
							</tr>
							<tr>
								<td>102-2</td>
								<td>Activities, brands, <br />products, and services</td>
								<td><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> <a target="_blank" href="strategy/">2020 Strategy Overview and Progress</a><br> 10-K: Item: Overview of Business, pages 1-5</td>
								<td />
							</tr>
							<tr>
								<td>102-3</td>
								<td>Location of headquarters</td>
								<td><a target="_blank" href="scorecard/footprint.php">2018 Scorecard</a>, <br>The Clorox Company <br>1221 Broadway, Oakland, CA 94612</td>
								<td />
							</tr>
							<tr>
								<td>102-4</td>
								<td>Location of operations</td>
								<td><a target="_blank" href="scorecard/footprint.php">2018 Scorecard</a></td>
								<td />
							</tr>
							<tr>
								<td>102-5</td>
								<td>Ownership and legal form</td>
								<td>10-K: Cover page (The Clorox Company; state or other <br />jurisdiction of incorporation of organization: Delaware)</td>
								<td />
							</tr>
							<tr>
								<td>102-6</td>
								<td>Markets served</td>
								<td><a target="_blank" href="scorecard/footprint.php">2018 Scorecard</a> 10-K: page 3</td>
								<td />
							</tr>
							<tr>
								<td>102-7</td>
								<td>Scale of the organization</td>
								<td><a target="_blank" href="scorecard/">2018 Scorecard</a></td>
								<td />
							</tr>
							<tr>
								<td>102-8</td>
								<td>Information on employees and other workers</td>
								<td><a target="_blank" href="strategy/people.php">Strategy 1</a><br> <a target="_blank" href="scorecard/people.php">2018 Scorecard, (People section)</a><br> 
									<a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/inclusion-diversity/">Clorox Website: Our People</a></td>
								<td />
							</tr>
							<tr>
								<td>102-9</td>
								<td>Supply chain</td>
								<td>Clorox’s supply chain reflects the company as a <br />formulator (not a chemical company) with a broad <br />portfolio of products for consumers and professionals. Raw material inputs are varied. <br><br><a target="_blank"a href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/supply-chain/">Clorox Website: Corporate Responsiblity: Supply Chain</a></td>
								<td>UNGC Ten Principles — The Clorox Company Business Partner Code of Conduct includes our expectations of suppliers on business ethics, human rights, labor and environmental <br />compliance and sustainability.</td>
							</tr>
							<tr>
								<td>102-10</td>
								<td>Significant changes to <br />the organization and <br />its supply chain</td>
								<td>Clorox made the following changes to its organization, which also impacted its supply chain: August 2017 divestiture of the Aplicare business, including manufacturing; April 2018 acquisition of the Nutranext business, which added a manufacturing facility in Sunrise, FL. </td>
								<td />
							</tr>
							<tr>
								<td>102-11</td>
								<td>Precautionary Principle <br />or approach</td>
								<td>
									<a target="_blank" href="https://www.thecloroxcompany.com/brands/what-were-made-of/">Clorox Website: Brands — What We&apos;re Made Of</a></td>
								<td>Principle 7</td>
							</tr>
							<tr>
								<td>102-12</td>
								<td>External initiatives</td>
								<td>CDP, UNGC — See <a target="_blank" href="ceo-letter/">CEO Letter</a><br> IIRC and GRI, <br><a href="about.php" target="_blank">About This Report</a><br><a target="_blank"a href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/supply-chain/industry-collaboration-2/">Clorox Website: AIM Progress Industry Collaboration</a></td>
								<td>UNGC Ten Principles</td>
							</tr>
							<tr>
								<td>102-13</td>
								<td>Membership of <br />associations </td>
								<td>
									<a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/stakeholder-engagement/">Clorox Website: Stakeholder Engagement</a></td>
								<td>UNGC Principles 7-9 (See Responsible Sourcing Information)</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div class="griSection">
					<div class="griSection__heading">Strategy</div>
					<table class="griTable">
						<tr class="hide">
							<th>DISCLOSURE Number</th>
							<th>Description</th>
							<th>Response</th>
							<th>UNGC PRINCIPLEs</th>
						</tr>

						<tr>
							<td>102-14</td>
							<td>Statement from senior decision-maker</td>
							<td><a target="_blank" href="ceo-letter/">CEO Letter</a></td>
							<td></td>
						</tr>

						<tr>
							<td>102-15</td>
							<td>Key impacts, risks, and opportunities</td>
							<td><a target="_blank" href="strategy/">2020 Strategy Overview and Progress</a> <br> 10-K: Item 1.A. Risk Factors, pages 6-18</td>
							<td></td>
						</tr>
					</table>
				</div>

				<div class="griSection">
					<div class="griSection__heading">Ethics and Integrity</div>
					<table class="griTable">
						<tr class="hide">
							<th>DISCLOSURE Number</th>
							<th>Description</th>
							<th>Response</th>
							<th>UNGC PRINCIPLEs</th>
						</tr>

						<tr>
							<td>102-16</td>
							<td>Values, principles, standards, and norms of behavior</td>
							<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/mission-values/">Clorox Website: Mission and Values</a></td>
							<td>Principle 10</td>
						</tr>

						<tr>
							<td>102-17</td>
							<td>Mechanisms for advice and concerns about ethics</td>
							<td><a href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/" target="_blank">Clorox Website: Clorox Code of Conduct and Clorox Business Partner Code of Conduct</a></td>
							<td>Principle 10</td>
						</tr>
					</table>
				</div>

				<div class="griSection">
					<div class="griSection__heading">Governance</div>
					
					<table class="griTable">
						<thead>
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>102-18</td>
								<td>Governance structure </td>
								<td><a target="_blank" href="governance/">Corporate Governance</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/">Clorox Website: Corporate Governance</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/governance-guidelines/">Clorox Website: Governance Guidelines</a></td>
								<td>UNGC Ten Principles</td>
							</tr>
							<tr>
								<td>102-19</td>
								<td>Delegating authority </td>
								<td><a target="_blank" href="governance/">Corporate Governance</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/">Clorox Website: Corporate Governance</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/eco-governance/">Clorox Website: Eco Governance</a></td>
								<td>Principles 7-9</td>
							</tr>
							<tr>
								<td>102-20</td>
								<td>Executive-level responsibility for economic, environmental, and social topics </td>
								<td><a target="_blank" href="governance/">Corporate Governance</a></td>
								<td />
							</tr>
							<tr>
								<td>102-21</td>
								<td>Consulting stakeholders on economic, environmental, and social topics </td>
								<td><a target="_blank" href="governance/">Corporate Governance</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/board-of-directors/">Clorox Website: Board of Directors</a></td>
								<td />
							</tr>
							<tr>
								<td>102-22</td>
								<td>Composition of the highest governance body and its committees </td>
								<td><a target="_blank" href="governance/">Corporate Governance</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/board-of-directors/">Clorox Website: Corporate Governance</a></td>
								<td />
							</tr>
							<tr>
								<td>102-23</td>
								<td>Chair of the highest <br />governance body</td>
								<td><a target="_blank" href="governance/">Corporate Governance</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/">Clorox Website: Corporate Governance</a></td>
								<td />
							</tr>
							<tr>
								<td>102-24</td>
								<td>Nominating and selecting the highest governance body </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/committee-charters/">Clorox Website: Corporate Governance <br />Committee Charters</a></td>
								<td />
							</tr>
							<tr>
								<td>102-25</td>
								<td>Conflicts of interest </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Clorox Code of Conduct</a></td>
								<td>Principle 10</td>
							</tr>
							<tr>
								<td>102-26</td>
								<td>Role of highest governance body in setting purpose, <br />values, and strategy</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/governance-guidelines/">Clorox Website: Governance Guidelines</a></td>
								<td>UNGC Ten Principles</td>
							</tr>
							<tr>
								<td>102-27</td>
								<td>Collective knowledge of <br />highest governance body</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/board-of-directors/">Clorox Website: Clorox Board of Directors</a></td>
								<td>UNGC Ten Principles</td>
							</tr>
							<tr>
								<td>102-28</td>
								<td>Evaluating the highest <br />governance body’s <br />performance </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/committee-charters/">Clorox Website: Corporate Governance <br />Committee Charters</a></td>
								<td>UNGC Ten Principles</td>
							</tr>
							<tr>
								<td>102-29</td>
								<td>Identifying and managing economic, environmental, <br />and social impacts</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/governance-guidelines/">Clorox Website: Governance Guidelines</a></td>
								<td>UNGC Ten Principles</td>
							</tr>
							<tr>
								<td>102-30</td>
								<td>Effectiveness of risk <br />management processes </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/governance-guidelines/">Clorox Website: Governance Guidelines</a></td>
								<td>UNGC Ten Principles</td>
							</tr>
							<tr>
								<td>102-31</td>
								<td>Review of economic, <br />environmental, and <br />social topics</td>
								<td>The Clorox board of directors meets at least quarterly to review key issues/opportunities impacting the company.</td>
								<td>UNGC Ten Principles</td>
							</tr>
							<tr>
								<td>102-32</td>
								<td>Highest governance body’s role in sustainability reporting </td>
								<td>Clorox&apos;s CEO, CFO and general counsel approve our integrated report.</td>
								<td />
							</tr>
							<tr>
								<td>102-33</td>
								<td>Communicating critical concerns</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/board-of-directors/   ">Clorox Website: Communicating with Clorox <br />Board of Directors</a></td>
								<td />
							</tr>
							<tr>
								<td>102-34</td>
								<td>Nature and total number <br />of critical concerns</td>
								<td>The Clorox board of directors regularly review and address a variety of key issues/opportunities through quarterly updates, strategy meetings and separate committee meetings. The company does not disclose the total number of concerns.&#160;</td>
								<td />
							</tr>
							<tr>
								<td>102-35</td>
								<td>Remuneration policies</td>
								<td><a href="https://investors.thecloroxcompany.com/investors/financial-information/sec-filings/default.aspx" target="_blank">Clorox Website: SEC Filings 2018 Clorox Proxy — See Compensation Discussion and Analysis, pages 34-62</a></td>
								<td />
							</tr>
							<tr>
								<td>102-36</td>
								<td>Process for determining remuneration </td>
								<td><a href="https://investors.thecloroxcompany.com/investors/financial-information/sec-filings/default.aspx" target="_blank">Clorox Website: SEC Filings 2018 Clorox Proxy — See Compensation Discussion and Analysis, pages 34-62</a></td>
								<td />
							</tr>
							<tr>
								<td>102-37</td>
								<td>Stakeholders’ involvement <br />in remuneration </td>
								<td><a href="https://investors.thecloroxcompany.com/investors/financial-information/sec-filings/default.aspx" target="_blank">Clorox Website: SEC Filings 2018 Clorox Proxy — See Compensation Discussion and Analysis, pages 34-62</a></td>
								<td />
							</tr>
							<tr>
								<td>102-38</td>
								<td>Annual total <br />compensation ratio</td>
								<td>Clorox does not disclose, although the company does point to CEO median pay ratio. </td>
								<td />
							</tr>
							<tr>
								<td>102-39</td>
								<td>Percentage increase in annual total compensation ratio</td>
								<td>Clorox does not disclose.</td>
								<td />
							</tr>
						</tbody>
					</table>
				</div>

				<div class="griSection">
					<div class="griSection__heading">Stakeholder Engagement</div>
					<table class="griTable">
						<tr class="hide">
							<th>DISCLOSURE Number</th>
							<th>Description</th>
							<th>Response</th>
							<th>UNGC PRINCIPLEs</th>
						</tr>	
						<tr>
							<td>102-40</td>
							<td>List of stakeholder groups</td>
							<td><a target="_blank" href="governance/">Corporate Governance</a> <br><a target="_blank" href="strategy/">2020 Strategy, Our Relationships</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/stakeholder-engagement/">Clorox Website: Stakeholder Engagement</a></td>
							<td></td>
						</tr>
						<tr>
							<td>102-41</td>
							<td>Collective bargaining agreements</td>
							<td>U.S.: 1.90%, International: 23.43%, Total Company: 8.97%</td>
							<td>Principle 3</td>
						</tr>
						<tr>
							<td>102-42</td>
							<td>Identifying and selecting stakeholders</td>
							<td><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/stakeholder-engagement/">Clorox Website: Stakeholder Engagement</a></td>
							<td></td>
						</tr>
						<tr>
							<td>102-43</td>
							<td>Approach to stakeholder engagement</td>
							<td><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/stakeholder-engagement/">Clorox Website: Stakeholder Engagement</a></td>
							<td></td>
						</tr>
						<tr>
							<td>102-44</td>
							<td>Key topics and concerns raised</td>
							<td><a target="_blank" href="materiality.php">Corporate Responsibility Priorities</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/stakeholder-engagement/">Clorox Website: Stakeholder Engagement</a></td>
							<td></td>
						</tr>
					</table>
				</div>

				<div class="griSection">
					<div class="griSection__heading">Reporting Practice</div>
					<table class="griTable">
						<tr class="hide">
							<th>DISCLOSURE Number</th>
							<th>Description</th>
							<th>Response</th>
							<th>UNGC PRINCIPLEs</th>
						</tr>
						<tr>
							<td>102-45</td>
							<td>Entities included in the consolidated financial statements</td>
							<td>10-K: Financial Information About Foreign and Domestic Operations — Notes to Consolidated Financial Statements in Exhibit 99.1</td>
							<td></td>
						</tr>
						<tr>
							<td>102-46</td>
							<td>Defining report content and topic Boundaries</td>
							<td><a target="_blank" href="about.php">About This Report</a></td>
							<td></td>
						</tr>
						<tr>
							<td>102-47</td>
							<td>List of material topics</td>
							<td><a target="_blank" href="materiality.php">Corporate Responsibility Priorities</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/stakeholder-engagement/">Clorox Website: Stakeholder Engagement</a></td>
							<td>UNGC Principles 1-10</td>
						</tr>
						<tr>
							<td>102-48</td>
							<td>Restatements of information</td>
							<td>10-K: Five-Year Financial Summary, page 66</td>
							<td></td>
						</tr>
						<tr>
							<td>102-49</td>
							<td>Changes in reporting</td>
							<td><a target="_blank" href="about.php">About This Report</a></td>
							<td></td>
						</tr>
						<tr>
							<td>102-50</td>
							<td>Reporting period</td>
							<td><a target="_blank" href="about.php">About This Report</a></td>
							<td></td>
						</tr>
						<tr>
							<td>102-51</td>
							<td>Date of most recent report</td>
							<td><a target="_blank" href="about.php">About This Report</a></td>
							<td></td>
						</tr>
						<tr>
							<td>102-52</td>
							<td>Reporting cycle</td>
							<td><a target="_blank" href="about.php">About This Report</a></td>
							<td></td>
						</tr>
						<tr>
							<td>102-53</td>
							<td>Contact point for questions regarding the report</td>
							<td><a href="mailto:corporate.communications@clorox.com">corporate.communications@clorox.com</a></td>
							<td></td>
						</tr>
						<tr>
							<td>102-54</td>
							<td>Claims of reporting in accordance with the GRI Standards</td>
							<td><a target="_blank" href="about.php">About This Report</a></td>
							<td></td>
						</tr>
						<tr>
							<td>102-55</td>
							<td>GRI content index</td>
							<td><a target="_blank" href="about.php">About This Report</a></td>
							<td></td>
						</tr>
						<tr>
							<td>102-56</td>
							<td>External assurance</td>
							<td><a target="_blank" href="about.php">About This Report</a> <br><a target="_blank" href="financials/#condensed">Report of Independent Registered Accounting Firm</a></td>
							<td></td>
						</tr>
					</table>
				</div>

				<div class="griSection">
					<div class="griSection__heading">GRI 200: Economic</div>

					<div class="griSubSection active">
						<div class="griSubSection__heading">GRI 201: Economic Performance</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="ceo-letter/">CEO Letter</a><br> <a target="_blank" href="strategy/">2020 Strategy</a> <br><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> <a target="_blank" href="materiality.php">Corporate Responsibility Priorities</a></td>
								<td></td>
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components</td>
								<td><a target="_blank" href="ceo-letter/">CEO Letter</a><br> <a target="_blank" href="strategy/">2020 Strategy</a> <br><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> 10-K: Part I, Item 1 — Overview of Business, page 1; Part II, Item 7 — Management’s Discussion and Analysis of Financial Condition and Results of Operations, page 24</td>
								<td></td>
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="ceo-letter/">CEO Letter</a><br> <a target="_blank" href="strategy/">2020 Strategy</a> <br><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> 10-K: Part II, Item 7 — Management’s Discussion and Analysis of Financial Condition and Results of Operations</td>
								<td></td>
							</tr>
							<tr>
								<td>201-1</td>
								<td>Direct economic value generated and distributed</td>
								<td><a target="_blank" href="scorecard/">2018 Scorecard</a> </td>
								<td>Principles 7-9</td>
							</tr>
							<tr>
								<td>201-2</td>
								<td>Financial implications and other risks and opportunities due to climate change</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/commitments-and-progress/">Clorox Website: Commitments and Progress — <br>Message from the CEO</a> <br>10-K: Risk Factors, pages 6-19</td>
								<td></td>
							</tr>
							<tr>
								<td>201-3</td>
								<td>Defined benefit plan obligations and other retirement plans</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/careers/working-at-clorox/">Clorox Website: Working at Clorox — Benefits & Perks</a></td>
								<td></td>
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 205: Anti-corruption</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Clorox and Business Partner<br> Codes of Conduct</a></td>
								<td>Principle 10</td>
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Clorox and Business Partner<br> Codes of Conduct</a></td>
								<td>Principle 10</td>
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Clorox and Business Partner<br> Codes of Conduct</a></td>
								<td>Principle 10</td>
							</tr>
							<tr>
								<td>205-2</td>
								<td>Communication and training about anti-corruption policies and procedures</td>
								<td>100 percent of the company’s leaders and employees must go through anti-corruption training. 100 percent of the company’s suppliers must adhere to the Business Partner Code of Conduct, which addresses ethical business practices.<br> <a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Clorox and Business Partner<br> Codes of Conduct</a></td>
								<td>Principle 10</td>
							</tr>
						</table>
					</div>
				</div>

				<div class="griSection">
					<div class="griSection__heading">GRI 300: Environmental</div>

					<div class="griSubSection active">
						<div class="griSubSection__heading">GRI 301: Materials</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="strategy/">2020 Strategy Overview</a> <br><a target="_blank" href="strategy/growth.php">Strategy 4, Fund Growth, CR Highlights — Shrink our environmental footprint while we grow</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/commitments-and-progress/">Clorox Website: Commitments and Progress —<br> Message from the CEO</a> </td
								<td></td>
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components</td>
								<td><a target="_blank" href="strategy/">2020 Strategy Overview</a> <br><a target="_blank" href="strategy/growth.php">Strategy 4, Fund Growth, CR Highlights — Shrink our environmental footprint while we grow</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/commitments-and-progress/">Clorox Website: Commitments and Progress —<br> Message from the CEO</a> </td
								<td></td>
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="strategy/">2020 Strategy Overview</a> <br><a target="_blank" href="strategy/growth.php">Strategy 4, Fund Growth, CR Highlights — Shrink our environmental footprint while we grow</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/commitments-and-progress/">Clorox Website: Commitments and Progress —<br> Message from the CEO</a> </td
								<td></td>
							</tr>
							<tr>
								<td>301-2</td>
								<td>Recycled input materials used</td>
								<td>We do not currently report a total percentage of materials used that are recycled input materials.</td>
								<td>Principles 7-9</td>
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 302: Energy</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="strategy/growth.php">Strategy 4, Fund Growth, CR Highlights — Shrink our environmental footprint while we grow</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/commitments-and-progress/">Clorox Website: Commitments and Progress — <br>Message from the CEO</a> </td
								<td></td>
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components</td>
								<td><a target="_blank" href="strategy/growth.php">Strategy 4, Fund Growth, CR Highlights — Shrink our environmental footprint while we grow</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/commitments-and-progress/">Clorox Website: Commitments and Progress — <br>Message from the CEO</a> </td
								<td></td>
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="strategy/growth.php">Strategy 4, Fund Growth, CR Highlights — Shrink our environmental footprint while we grow</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/commitments-and-progress/">Clorox Website: Commitments and Progress — <br>Message from the CEO</a> </td
								<td></td>
							</tr>
							<tr>
								<td>302-4</td>
								<td>Reduction of energy consumption</td>
								<td><a target="_blank" href="strategy/">2020 Strategy Overview (Good Growth)</a> <br><a target="_blank" href="strategy/growth.php">Strategy 4, Fund Growth, CR Highlights — Shrink our environmental footprint while we grow</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/energy/">Clorox Website: Sustainability in Our Facilities — Energy</a></td>
								<td></td>
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 303: Water</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>

							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="strategy/growth.php">Water</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/water/">Clorox Website: Sustainability in our Facilities — Water</a></td>
								<td>Principles 7-9</td>
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components</td>
								<td><a target="_blank" href="strategy/growth.php">Water</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/water/">Clorox Website: Sustainability in our Facilities — Water</a></td>
								<td>Principles 7-9</td>
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="strategy/growth.php">Water</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/water/">Clorox Website: Sustainability in our Facilities — Water</a></td>
								<td>Principles 7-9</td>
							</tr>
							<tr>
								<td>303-1</td>
								<td>Water withdrawal by source</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/water/">Clorox Website: Sustainability in our Facilities — Water</a></td>
								<td></td>
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 305: Emissions</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="strategy/growth.php">Greenhouse Gas Emissions</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/ghg-emissions/">Clorox Website: Sustainability in our Facilities — GHG</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/commitments-and-progress/">Clorox Website: Commitments and Progress —<br> Message from the CEO</a> </td
								<td></td>
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components</td>
								<td><a target="_blank" href="strategy/growth.php">Greenhouse Gas Emissions</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/ghg-emissions/">Clorox Website: Sustainability in our Facilities — GHG</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/commitments-and-progress/">Clorox Website: Commitments and Progress —<br> Message from the CEO</a> </td
								<td></td>
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="strategy/growth.php">Greenhouse Gas Emissions</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/ghg-emissions/">Clorox Website: Sustainability in our Facilities — GHG</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/commitments-and-progress/">Clorox Website: Commitments and Progress —<br> Message from the CEO</a> </td
								<td></td>
							</tr>
							<tr>
								<td>305-1</td>
								<td>Direct (Scope 1) GHG emissions</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/ghg-emissions/">Clorox Website: Sustainability in our Facilities — GHG</a> <br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/commitments-and-progress/">Clorox Website: Commitments and Progress —<br> Message from the CEO</a> </td>
								<td></td>
							</tr>
							<tr>
								<td>305-5</td>
								<td>Reduction of GHG emissions</td>
								<td><a target="_blank" href="strategy/growth.php">GHG Emissions</a> <br><a target="_blank" href="scorecard/">2018 Scorecard</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/ghg-emissions/">Clorox Website: Sustainability in our Facilities — GHG</a> </td>
								<td></td>
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 306: Effluents and Waste</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="strategy/growth.php">Waste</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/waste/">Clorox Website: Sustainability in our Facilities — Waste</a></td>
								<td />
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="strategy/growth.php">Waste</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/waste/">Clorox Website: Sustainability in our Facilities — Waste</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/commitments-and-progress/">Clorox Website: Commitments and Progress — <br>Message from the CEO</a></td>
								<td />
							</tr>
							<tr>
								<td>103-3</td>
								<td>Waste by type and disposal method</td>
								<td><a target="_blank" href="strategy/growth.php">Waste</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/waste/">Clorox Website: Sustainability in our Facilities — Waste</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/commitments-and-progress/">Clorox Website: Commitments and Progress — <br>Message from the CEO</a></td>
								<td />
							</tr>
							<tr>
								<td>306-2</td>
								<td>Waste by type and <br />disposal method</td>
								<td><a target="_blank" href="strategy/growth.php">Waste</a> 
								<a target="_blank" href="scorecard/">2018 Scorecard</a> <br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/operations/footprint-reduction-summary/">Clorox Website: Footprint Reduction Summary — Waste</a><br> We report solid waste disposal, not hazardous waste disposal. The waste disposal method has been determined based on information provided by the waste disposal contractor. Each site reports its annual reuse, recycling, and disposal tonnages using information obtained from its recycling or waste disposal contractor to our corporate office, where it is reviewed and compiled.
									<table class="griSubTable">
										<tr>
											<th colspan="2">Materials (tons)</th>
										</tr>
										<tr>
											<td>Reuse</td>
											<td>41,719</td>
										</tr>
										<tr>
											<td>Recycle</td>
											<td>24,711</td>
										</tr>
										<tr>
											<td>Compost</td>
											<td>395</td>
										</tr>
										<tr>
											<td>Energy Recovery</td>
											<td>494</td>
										</tr>
										<tr>
											<td>Incineration</td>
											<td>—</td>
										</tr>
										<tr>
											<td>Deep Well</td>
											<td>—</td>
										</tr>
										<tr>
											<td>Landfill</td>
											<td>8,111</td>
										</tr>
										<tr>
											<td>On-Site Storage</td>
											<td>—</td>
										</tr>
										<tr>
											<td>Other</td>
											<td>—</td>
										</tr>
									</table>
								</td>
								<td />
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 307: Environmental Compliance</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td>10-K: Risk Factors, pages 6-19</td>
								<td />
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/">Clorox Website: Environmental Sustainability</a></td>
								<td />
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/">Clorox Website: Environmental Sustainability</a></td>
								<td />
							</tr>
							<tr>
								<td>307-1</td>
								<td>Non-compliance with <br />environmental laws <br />and regulations</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Clorox and Business Partner<br> Codes of Conduct</a></td>
								<td />
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 308: Supplier Environmental Assessment</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/supply-chain/">Clorox Website: Supply Chain — Responsible Sourcing</a></td>
								<td>Principles 7-9</td>
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/supply-chain/">Clorox Website: Supply Chain — Responsible Sourcing</a>
									<a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Clorox Business Partner <br />Codes of Conduct</a></td>
								<td>Principles 7-9</td>
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/supply-chain/">Clorox Website: Supply Chain — Responsible Sourcing</a>
									<a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Clorox Business Partner <br />Codes of Conduct</a></td>
								<td>Principles 7-9</td>
							</tr>
							<tr>
								<td>308-1</td>
								<td>New suppliers that were screened using <br />environmental criteria</td>
								<td>Clorox does not track percentage of new suppliers screened using environmental data. The vast majority of new suppliers are informed/expected to adhere to our environmental commitments/practices in our Business Partner Code of Conduct. Clorox has a scorecard tracking the environmental practices of our top 100 suppliers (by spend).</td>
								<td />
							</tr>
							<tr>
								<td>308-2</td>
								<td>Negative environmental <br />impacts in the supply chain and actions taken</td>
								<td>The company assesses the sustainability performance of its top 100 suppliers, which represent the majority of supplier spend. 100 percent of suppliers, including new suppliers, must adhere to the company’s Business Partner Code of Conduct, which addresses sustainability expectations.<br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/supply-chain/supplier-footprint/">Clorox Website: Supply Chain — Supplier <br />Environmental Footprint Score Card</a></td>
								<td />
							</tr>
						</table>
					</div>
				</div>

				<div class="griSection">
					<div class="griSection__heading">GRI 400: Social</div>

					<div class="griSubSection active">
						<div class="griSubSection__heading">GRI 401: Employment</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="strategy/people.php">Engage Our People</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/">Clorox Website: Our People</a><br><a target="_blank"a href="https://www.thecloroxcompany.com/careers/about/">Clorox Website: Careers</a></td>
								<td />
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="strategy/people.php">Engage Our People</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/">Clorox Website: Our People</a><br><a target="_blank"a href="https://www.thecloroxcompany.com/wp-content/uploads/2018/04/NI-42537_CORP_CodeOfConduct2018_External_ENG.pdf">Clorox Website: Clorox Code of Conduct</a></td>
								<td />
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="strategy/people.php">Engage Our People</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/">Clorox Website: Our People</a></td>
								<td />
							</tr>
							<tr>
								<td>401-2</td>
								<td>Benefits provided to full-time employees that are not provided to temporary or part-time employees</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/careers/working-at-clorox/">Clorox Website: Working at Clorox — Benefits &amp; Perks </a></td>
								<td />
							</tr>
						</table>
					</div>
					
					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 403: Occupational Health and Safety</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="strategy/people.php">Engage Our People — Workplace Safety</a> <br><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> <a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/workplace-safety/">Clorox Website: Workplace Safety</a></td>
								<td />
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="strategy/people.php">Engage Our People — Workplace Safety</a> <br><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> <a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/workplace-safety/">Clorox Website: Workplace Safety</a></td>
								<td />
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="strategy/people.php">Engage Our People — Workplace Safety</a> <br><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> <a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/workplace-safety/">Clorox Website: Workplace Safety</a></td>
								<td />
							</tr>
							<tr>
								<td>403-2</td>
								<td>Types of injury and rates of injury, occupational diseases, lost days, and absenteeism, and number of work-related fatalities</td>
								<td><a target="_blank" href="scorecard/people.php">Workplace Safety</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/workplace-safety/">Clorox Website: Workplace Safety</a><br> We track the RIR and LTIR* (lost-time incident rate) for Clorox employees plus supervised workers. LTIR is reported internally on a monthly basis. We follow OSHA 1904 Rules for defining injuries as “reportable” and labor hours to track. The rate calculation is that used by the Bureau of Labor Statistics and OSHA for comparison across industries.</td>
								<td />
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 404: Training and Education</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/">Clorox Website: Our People</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/wp-content/uploads/2018/04/NI-42537_CORP_CodeOfConduct2018_External_ENG.pdf">Clorox Website: Clorox Code of Conduct</a></td>
								<td />
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/">Clorox Website: Our People</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/wp-content/uploads/2018/04/NI-42537_CORP_CodeOfConduct2018_External_ENG.pdf">Clorox Website: Clorox Code of Conduct</a></td>
								<td />
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/">Clorox Website: Our People</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/wp-content/uploads/2018/04/NI-42537_CORP_CodeOfConduct2018_External_ENG.pdf">Clorox Website: Clorox Code of Conduct</a></td>
								<td />
							</tr>
							<tr>
								<td>404-2</td>
								<td>Programs for upgrading employee skills and transition assistance programs</td>
								<td><a target="_blank" href="ceo-letter/">CEO Letter</a><br> <a target="_blank" href="strategy/people.php">Engage Our People</a><br><br>The company’s MyLearning program offers extensive internal and external courses to support professional development and capability- and leadership-building needs.</td>
								<td />
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 405: Diversity and Equal Opportunity</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="strategy/people.php">Engage Our People — Diversity</a> <br><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> <a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/inclusion-diversity/">Clorox Website: Inclusion &amp; Diversity</a></td>
								<td>Principle 6</td>
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components</td>
								<td><a target="_blank" href="strategy/people.php">Engage Our People — Diversity</a> <br><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> <a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/inclusion-diversity/">Clorox Website: Inclusion &amp; Diversity</a></td>
								<td />
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="strategy/people.php">Engage Our People — Diversity</a> <br><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> <a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/inclusion-diversity/">Clorox Website: Inclusion &amp; Diversity</a></td>
								<td />
							</tr>
							<tr>
								<td>405-1</td>
								<td>Diversity of governance bodies and employees</td>
								<td><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> <a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/inclusion-diversity/">Clorox Website: Inclusion &amp; Diversity</a></td>
								<td />
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 406: Non-discrimination</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/inclusion-diversity/">Clorox Website: Inclusion &amp; Diversity</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Codes of Conduct</a></td>
								<td>Principle 6</td>
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/inclusion-diversity/">Clorox Website: Inclusion &amp; Diversity</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Codes of Conduct</a></td>
								<td />
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/our-people/inclusion-diversity/">Clorox Website: Inclusion &amp; Diversity</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Codes of Conduct</a></td>
								<td />
							</tr>
							<tr>
								<td>406-1</td>
								<td>Incidents of discrimination and corrective actions taken</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Codes of Conduct</a></td>
								<td />
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 408: Child Labor</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Codes of Conduct</a></td>
								<td>Principles 1-5</td>
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Codes of Conduct</a></td>
								<td>Principles 1-6</td>
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Codes of Conduct</a></td>
								<td>Principles 1-7</td>
							</tr>
							<tr>
								<td>408-1</td>
								<td>Operations and suppliers at significant risk for incidents of child labor</td>
								<td>Suppliers must comply with Clorox’s policy on employment of young people where the minimum age of employment shall not be less than the greater of (a) the age of completion of compulsory schooling or (b) 15 years of age (or 14, where the local law of the country permits). Additionally, workers under age 18 should not perform any hazardous work.</td>
								<td>Principles 1-8</td>
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 409: Forced or Compulsory Labor</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Codes of Conduct</a></td>
								<td />
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Codes of Conduct</a></td>
								<td />
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Codes of Conduct</a></td>
								<td />
							</tr>
							<tr>
								<td>409-1</td>
								<td>Operations and suppliers at significant risk for incidents of forced or compulsory labor</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">
									Clorox Website: Codes of Conduct</a> <br>
									Adherence to our Business Partner Code of Conduct — which articulates our expectations regarding human rights and labor, health and safety, the environment, and business conduct and ethics — is required of our suppliers, with certification taking place on a regular basis. This code precludes the use of forced, bonded, or indentured labor or prison labor. As an additional safeguard, the company’s Global Strategic Sourcing organization implemented a monitoring program last year using web-crawl technology to monitor all global direct material suppliers for any activities or incidents that would pose risk to the Clorox supply chain. Through an alert system, buyers are notified of any significant findings for appropriate action and/or follow-up. GSS also began annual risk assessments of global suppliers this year based on location, scale, industry and audit history to determine those suppliers at highest risk for social compliance issues, including forced labor and human trafficking. The risk assessment allows us to determine which suppliers should be selected for third-party audits to verify compliance with all principles and standards of the Clorox Business Partner Code of Conduct.
								</td>
								<td />
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 412: Human Rights Assessment</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Codes of Conduct</a></td>
								<td />
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Codes of Conduct</a></td>
								<td />
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Codes of Conduct</a></td>
								<td />
							</tr>
							<tr>
								<td>412-1</td>
								<td>Operations that have been subject to human rights reviews or impact assessments</td>
								<td>None of our operations has been subject to human rights reviews/assessments.</td>
								<td />
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 413: Local Communities</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="strategy/portfolio.php">Strategy 3</a> <br><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/social-impact/">Clorox Website: Social Impact</a></td>
								<td />
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="strategy/portfolio.php">Strategy 3</a> <br><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> <a target="_blank" href="materiality.php">Corporate Responsibility Priorities</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/social-impact/">Clorox Website: Social Impact</a></td>
								<td />
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="strategy/portfolio.php">Strategy 3, Safeguard Families Through Initiatives that Promote Health, Education and Safety — Community Support</a> <br><a target="_blank" href="scorecard/">2018 Scorecard</a> <br> <a target="_blank" href="materiality.php">Corporate Responsibility Priorities</a><br> <a target="_blank"a href="https://www.thecloroxcompany.com/corporate-responsibility/social-impact/">Clorox Website: Social Impact</a></td>
								<td />
							</tr>
							<tr>
								<td>413-1</td>
								<td>Operations with local community engagement, impact assessments, and development programs</td>
								<td><a target="_blank" href="strategy/portfolio.php">Strategy 3: Safeguard Families Through Initiatives that Promote Health, Education and Safety — Community Support</a> <br><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/social-impact/">Clorox Website: Social Impact</a></td>
								<td />
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 414: Supplier Social Assessment</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/supply-chain/">Clorox Website: Sustainability in Our Supply Chain</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/wp-content/uploads/clorox-business-partner-code-of-conduct.English.pdf">Clorox Website: Business Partner Code of Conduct</a></td>
								<td>Principles 1-6</td>
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/supply-chain/">Clorox Website: Sustainability in Our Supply Chain</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/wp-content/uploads/clorox-business-partner-code-of-conduct.English.pdf">Clorox Website: Business Partner Code of Conduct</a></td>
								<td>Principles 1-6</td>
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/environmental-sustainability/supply-chain/">Clorox Website: Sustainability in Our Supply Chain</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/wp-content/uploads/clorox-business-partner-code-of-conduct.English.pdf">Clorox Website: Business Partner Code of Conduct</a></td>
								<td>Principles 1-6</td>
							</tr>
							<tr>
								<td>414-1</td>
								<td>New suppliers that were screened using social criteria</td>
								<td>100 percent of all suppliers, including new suppliers, must adhere to our Business Partner Code of Conduct, which addresses labor practices.<br><br> We do not track percentage of new suppliers screened using labor practices criteria. The vast majority of new suppliers are informed and expected to adhere to our human rights and labor commitments through contract language requiring adherence to our Business Partner Code of Conduct. In the absence of a contract, there are other mechanisms to ensure compliance with labor practices criteria for significant purchases.</td>
								<td />
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 416: Customer Health and Safety</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/brands/what-were-made-of/">Clorox Website: What We’re Made Of</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/social-impact/">Clorox Website: Social Impact</a></td>
								<td>Principles 7-9</td>
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/brands/what-were-made-of/">Clorox Website: What We’re Made Of</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/social-impact/">Clorox Website: Social Impact</a></td>
								<td>Principles 7-9</td>
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/brands/what-were-made-of/">Clorox Website: What We’re Made Of</a><br> <a target="_blank" href="https://www.thecloroxcompany.com/corporate-responsibility/social-impact/">Clorox Website: Social Impact</a></td>
								<td>Principles 7-9</td>
							</tr>
							<tr>
								<td>416-1</td>
								<td>Assessment of the health and safety impacts of product and service categories</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/brands/what-were-made-of/">Clorox Website: What We’re Made of</a><br> The company assesses 100 percent of its products for human and environmental safety.</td>
								<td>Principles 7-9</td>
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 417: Marketing and Labeling</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td>Marketing Our Products ResponsiblyWe remain committed to providing information about our brands and products in a responsible and truthful manner, adhering to all laws and guidelines of the Federal Trade Commission and other relevant governing bodies. That means communicating the benefits, performance, and attributes of our products accurately and directly, with claims that are substantiated.<br><br> It’s also our policy to create and purchase advertising so we reach our target audiences with maximum efficiency, using advertisements and media that are consistent with the character and values of our company, while upholding relevant local laws and consumer privacy guidelines like the General Data Protection Regulation (GDPR).<br><br> All company products have the required labeling for safety and usage. Clorox was also the first major CPG company to voluntarily disclose the product ingredients used in our cleaning and disinfecting products in the U.S. and Canada: <a target="_blank" href="http://www.IngredientsInside.com">www.IngredientsInside.com</a>. <br><a href="https://www.thecloroxcompany.com/brands/innovation/" target="_blank">Clorox Website: All About Innovation</a></td>
								<td />
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/brands/innovation/">Clorox Website: Marketing our Products Responsibility</a><br> <a target="_blank" href="http://www.IngredientsInside.com">Clorox Website: Ingredients Inside</a></td>
								<td />
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/brands/innovation/">Clorox Website: Marketing our Products Responsibility</a><br> <a target="_blank" href="http://www.IngredientsInside.com">Clorox Website: Ingredients Inside</a></td>
								<td />
							</tr>
							<tr>
								<td>417-1</td>
								<td>Requirements for product and service information and labeling</td>
								<td>100 percent of our products adhere to the appropriate regulations related to safety, caution and usage labeling.<br> <a target="_blank" href="https://www.thecloroxcompany.com/brands/what-were-made-of/">Clorox Website: What We’re Made Of</a></td>
								<td />
							</tr>
							<tr>
								<td>417-3</td>
								<td>Incidents of non-compliance concerning marketing communications</td>
								<td>We did not have any incidents of noncompliance with regulations or voluntary codes with respect to marketing communications.</td>
								<td />
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 418: Customer Privacy</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/privacy/">Clorox Website: Privacy Policy</a></td>
								<td />
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/privacy/">Clorox Website: Privacy Policy</a></td>
								<td />
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/privacy/">Clorox Website: Privacy Policy</a></td>
								<td />
							</tr>
							<tr>
								<td>418-1</td>
								<td>Substantiated complaints concerning breaches of customer privacy and losses of customer data</td>
								<td>The company has not identified any complaints related to this matter.</td>
								<td>Principles 7-9</td>
							</tr>
						</table>
					</div>

					<div class="griSubSection">
						<div class="griSubSection__heading">GRI 419: Socioeconomic Compliance</div>

						<table class="griTable">
							<tr class="hide">
								<th>DISCLOSURE Number</th>
								<th>Description</th>
								<th>Response</th>
								<th>UNGC PRINCIPLEs</th>
							</tr>
							<tr>
								<td>103-1</td>
								<td>Explanation of the material topic and its Boundary</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Clorox Codes of Conduct </a></td>
								<td />
							</tr>
							<tr>
								<td>103-2</td>
								<td>The management approach and its components </td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Clorox Codes of Conduct </a></td>
								<td />
							</tr>
							<tr>
								<td>103-3</td>
								<td>Evaluation of the management approach</td>
								<td><a target="_blank" href="https://www.thecloroxcompany.com/who-we-are/corporate-governance/codes-of-conduct/">Clorox Website: Clorox Codes of Conduct </a></td>
								<td />
							</tr>
							<tr>
								<td>419-1</td>
								<td>Non-compliance with laws and regulations in the social and economic area</td>
								<td>Clorox has been compliant with all social and economic regulations. </td>
								<td />
							</tr>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="_js/jquery.fancybox.min.js"></script>
<script src="_js/jquery.mousewheel.js"></script>
<script src="_js/greensock/TimelineMax.min.js"></script>
<script src="_js/greensock/TweenMax.min.js"></script>
<script src="_js/ScrollMagic.js"></script>
<script src="_js/plugins/jquery.ScrollMagic.js"></script>
<script src="_js/plugins/debug.addIndicators.js"></script>
<script src="_js/greensock/plugins/DrawSVGPlugin.min.js"></script>
<script src="_js/plugins/animation.gsap.js"></script>
<script src="_js/jquery.cycle2.min.js"></script>
<script src="_js/main.js?v.2018.2"></script></body>
</html>
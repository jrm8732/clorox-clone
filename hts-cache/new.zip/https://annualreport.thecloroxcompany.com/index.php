<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=Edge"/>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="_images/global/shareImage.png?v.2018.1" />

<title>Clorox 2018 Integrated Annual Report</title>
<link rel="stylesheet" href="_css/main.css?v.2018.4">
<link rel="stylesheet" href="_js/jquery.fancybox.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	    <script src="//assets.adobedtm.com/cfd7100a02cbfa40b2c485d333da22f89ccabd9c/satelliteLib-e1a96af74edf26406b64b1c5cb0abedb7b5a6c6c.js"></script>
	</head>
<body class="homeBody">
<header>
	<div class="header__hamburger">
		<span>MENU</span>
		<div class="header__hamburger__bars">
			<div></div>
		</div>
	</div>

	<a class="logoWrap" href="index.php">
		<img class="header__logo" src="_images/global/logo.svg">
	</a>
    <div class="container container--header">
        <div class="row">
			<div class="header__links">
				<span class="ir">2018 Integrated Annual Report</span>
				<ul>
					<li><a class="header__links__resources" href="#">Resources</a></li>
					<li><a class="header__links__download" href="#">Download</a></li>
					<li><a class="header__links__search" href="#"><i class="fas fa-search"></i></a></li>
					<li class="socialLink facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="socialLink twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
					<li class="socialLink linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="socialLink"><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
				</ul>
			</div>

			<div class="headerSearch">
				<div class="headerSearch__relativeWrapper">
					<form action="search.php">
						<input class="headerSearch__input" type="text" class="search" name="q" id="tipue_search_input" autocomplete="off" placeholder="Search" required="">
						<span class="headerSearch__del">X</span>
					</form>
				</div>
			</div>

			<div class="headerResources">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="about.php">About This Report</a></li>
						<li><a href="materiality.php">Materiality Overview</a></li>
						<li><a href="gri.php">GRI Content Index</a></li>
						<li><a href="info.php">Stockholder Information</a></li>
						<li><a target="_blank" href="https://www.thecloroxcompany.com/">The Clorox Company</a></li>
					</ul>
				</div>
			</div>

			<div class="downloads">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="Clorox_2018_Integrated_Report.pdf?v10-11-2018" target="_blank">Full PDF</a></li>
						<li><a href="Clorox_2018_Executive_Summary_English.pdf" target="_blank">Executive Summary English</a></li>
						<li><a href="Clorox_2018_Executive_Summary_Spanish.pdf" target="_blank">Executive Summary Spanish</a></li>
					</ul>
				</div>
			</div>
        </div>
	</div>

	<nav class="mainNav">
		<div class="mainNav__box mainNav__box--1">
			<a class="mainNav__mainLink" href="ceo-letter/">CEO Letter</a>

			<img src="_images/global/nav1.png" class="mainNav__product mainNav__product--1">
		</div>

		<div class="mainNav__box mainNav__box--2">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="strategy/">2020 Strategy</a>

				<ul class="secondaryNav">
					<li><a href="strategy/people.php">Engage our People</a></li>
					<li><a href="strategy/value.php">Drive Superior Consumer Value</a></li>
					<li><a href="strategy/portfolio.php">Accelerate Portfolio Momentum</a></li>
					<li><a href="strategy/growth.php">Fund Growth</a></li>
				</ul>
			</div>

			<img src="_images/global/nav2.png" class="mainNav__product mainNav__product--2">
		</div>

		<div class="mainNav__box mainNav__box--3">
			<a class="mainNav__mainLink" href="innovation/">Innovation</a>

			<img src="_images/global/nav3.png" class="mainNav__product mainNav__product--3">
		</div>

		<div class="mainNav__box mainNav__box--4">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="scorecard/">Scorecard</a>

				<ul class="secondaryNav">
					<li><a href="scorecard/footprint.php">Global Footprint</a></li>
					<li><a href="scorecard/performance.php">Performance</a></li>
					<li><a href="scorecard/product.php">Product</a></li>
					<li><a href="scorecard/people.php">People</a></li>
					<li><a href="scorecard/community.php">Community</a></li>
					<li><a href="scorecard/planet.php">Planet</a></li>
				</ul>
			</div>

			<img src="_images/global/nav4.png" class="mainNav__product mainNav__product--4">
		</div>

		<div class="mainNav__box mainNav__box--5">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="recognitions/">Recognitions</a>

				<ul class="secondaryNav">
					<li><a href="recognitions/">Company Recognitions</a></li>
					<li><a href="recognitions/brand.php">Brand Recognitions</a></li>
				</ul>
			</div>
			<img src="_images/global/nav5.png" class="mainNav__product mainNav__product--5">
		</div>

		<div class="mainNav__box mainNav__box--6">
			<a class="mainNav__mainLink" href="financials/">Financials</a>

			<img src="_images/global/nav6.png" class="mainNav__product mainNav__product--6">
		</div>

		<div class="mainNav__box mainNav__box--7">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="governance/">Governance</a>

				<ul class="secondaryNav">
					<li><a href="governance/board.php">Board of Directors</a></li>
					<li><a href="governance/committee.php">Executive Committee</a></li>
				</ul>
			</div>

			<img src="_images/global/nav7.png" class="mainNav__product mainNav__product--7">
		</div>

		<div class="mainNav__box mainNav__box--mobile">
			<ul>
				<li class="facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li class="twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li class="linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
			</ul>
		</div>
	</nav>
</header>
<div class="preloader">
	<div class="loading">
		<img src="_images/global/logo.svg">
		<i class="fas fa-spinner fa-spin"></i>
	</div>
</div>

<div class="homeWrapper">
	<div class="scroll">
		<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 191.2 286.7" style="enable-background:new 0 0 191.2 286.7;" xml:space="preserve" class="scroll__image">
<path style="fill:#ffffff;" d="M95.6,0C42.9,0,0,42.9,0,95.5v95.7c0,52.7,42.9,95.5,95.6,95.5s95.6-42.8,95.6-95.5V95.5
	C191.1,42.8,148.3,0,95.6,0L95.6,0z M180.5,191.2c0,46.8-38.1,84.9-85,84.9c-46.8,0-84.9-38.1-84.9-84.9V95.5
	c0-46.8,38.1-84.9,84.9-84.9s85,38.1,85,84.9V191.2z"/>
<path style="fill:#ffffff;" d="M95.6,31.8c-2.9,0-5.3,2.4-5.3,5.3v48.1c0,2.9,2.4,5.3,5.3,5.3c2.9,0,5.3-2.4,5.3-5.3V37.1
	C100.9,34.2,98.5,31.8,95.6,31.8L95.6,31.8z"/>
</svg>
		<span class="scroll__text">Scroll or use arrows on your keypad to move forward through the experience.</span>
	</div>

	<div class="surfaceClickWrapper">
		<div class="surfaceClick surfaceClick--up">
			<i class="fas fa-angle-up"></i>
		</div>
		<div class="surfaceClick surfaceClick--down">
			<i class="fas fa-angle-down"></i>
		</div>
	</div>
    <div class="scene scene--1">
        <div class="scene--1__products">
            <h2 class="scene--1__text"><span class="textWrap">What’s in a</span><br><span class="large textWrap">Brand?</span></h2>

            <img src="_images/home/scene1/image1.png" class="scene--1__product--1">
			<img src="_images/home/scene1/image2.png" class="scene--1__product--2">
			<img src="_images/home/scene1/mobile.png" class='scene--1__mobile'>
		</div>
		
		<div class="scroll scroll--mobile">
			<span class="scroll__text">Scroll <i class="fas fa-angle-down"></i></span>
		</div>
	</div>
	
	<div class="scene scene--2">		
		<h2 class="scene--2__text textWrap">EVERYTHING.</h2>

		<img src="_images/home/scene2/wave.png" class="scene--2__wave">

		<img src="_images/home/scene2/product1.jpg" class="scene--2__product scene--2__product--1">
		<img src="_images/home/scene2/product2.jpg" class="scene--2__product scene--2__product--2">
		<img src="_images/home/scene2/product3.jpg" class="scene--2__product scene--2__product--3">
		<img src="_images/home/scene2/product4.jpg" class="scene--2__product scene--2__product--4">
		<img src="_images/home/scene2/product5.png" class="scene--2__product scene--2__product--5">
		<img src="_images/home/scene2/product6.jpg" class="scene--2__product scene--2__product--6">

		<img src="_images/home/scene2/product5.jpg" class="placerProduct">
	</div>

	<div class="scene scene--3">
		<div class="mobileScene mobileScene--1">
			<div class="scene--3__productWrap">
				<img src="_images/home/scene3/product1.png" class="scene--3__product scene--3__product--2">
				<img src="_images/home/scene3/product1.png" class="scene--3__product scene--3__product--5">
				<img src="_images/home/scene3/product1.png" class="scene--3__product scene--3__product--4">
				<img src="_images/home/scene3/product1.png" class="scene--3__product scene--3__product--3">
			</div>

			<img src="_images/home/scene3/mobile.png" class="scene3MobileProducts">

			<div class="scene--3-1__textWrap">
				<div class="valueText">
					<h2 class="scene--3__text--1 textWrap">value</h2>
					<h3 class="scene--3__text--2">What puts our brands on top?</h3>
				</div>

				<div class="valueText--2">
					<p class="scene--3__text--3">Products people want or need at the right price. It’s no wonder a growing number of consumers say our brands are superior to the competition’s, based on price, perception and the products themselves.</p>
					<h3 class="scene--3__text--4">That’s the strength<br> of our unique and<br> differentiated portfolio.</h3>
				</div>
			</div>
		</div>

		<div class="mobileScene mobileScene--2">
			<div class="mobileScene--2__text">
				<h3 class="scene--3__text--5 textWrap">innovation</h3>
				<h3 class="scene--3__text--6">How do you inspire consumer loyalty?</h3>

				<div class="innovationText">
					<p class="scene--3__text--7"><span class="large">One bright idea after another.</span> Like how we reinvent our Clorox<sup>&reg;</sup> brand beyond classic bleach. Creating the Clorox Scentiva<sup>&reg;</sup> line of cleaners boasting experiential fragrances. Stepping up the performance of bleach through the power of Cloromax<sup>&reg;</sup>. That same zest for innovation permeates everything we do — from breakthroughs in technology and operational processes to pioneering work in our communities.</p>
					<h3 class="scene--3__text--8">That’s the way Clorox<br>people and brands stay<br>ahead of the competition.</h3>
				</div>
			</div>

			<img src="_images/home/scene3/image2.png" class="scene--3__image">
		</div>

		<div class="mobileScene mobileScene--3">
			

			<h3 class="scene--4__text--1 textWrap">leadership</h3>
			<h3 class="scene--4__text--2">What drives it?</h3>

			<div class="leadershipText">
				<p class="scene--4__text--3">Investing in our people and promoting an inclusive culture where diverse teams are empowered to take bold actions to drive growth. Building trust by adhering to our values, protecting our planet and supporting our communities. A portfolio of purpose-driven brands in new and adjacent categories.</p>
				<h3 class="scene--4__text--4">The result?<br><span class="large">Good Growth<sup>TM</sup> that is profitable,<br>sustainable and responsible.</span></h3>
			</div>
		</div>

		<div class="mobileScene mobileScene--4">
			<img src="_images/home/scene4/waves.png" class="scene--4__wave">
			<div class="introLetterContent">
				<span class="letterHero__ceoName letterHero__ceoName--intro">Benno Dorer<br> Chair and Chief Executive Officer</span>
				
				<div class="letterHero__text letterHero__text--intro">
					<h1>Letter To Stakeholders</h1>
					<h2>What’s in a <br> <span class="textWrap">Brand?</span></h2>
					<p>Everything we need to be <br>fundamentally strong <br>through every type <br>of business environment.</p>

					<a href="ceo-letter" class="introButton">LEARN MORE</a>
				</div>
				<img src="_images/home/scene4/ceo.png" alt="" class="letterHero__ceo letterHero__ceo--intro">
			</div>

			<div class="scene scene--4"></div>
		</div>
	</div>

	
</div>


<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="_js/jquery.fancybox.min.js"></script>
<script src="_js/jquery.mousewheel.js"></script>
<script src="_js/greensock/TimelineMax.min.js"></script>
<script src="_js/greensock/TweenMax.min.js"></script>
<script src="_js/ScrollMagic.js"></script>
<script src="_js/plugins/jquery.ScrollMagic.js"></script>
<script src="_js/plugins/debug.addIndicators.js"></script>
<script src="_js/greensock/plugins/DrawSVGPlugin.min.js"></script>
<script src="_js/plugins/animation.gsap.js"></script>
<script src="_js/jquery.cycle2.min.js"></script>
<script src="_js/main.js?v.2018.2"></script><script src="_js/home.js"></script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=Edge"/>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="../_images/global/shareImage.png?v.2018.1" />

<title>Clorox 2018 Integrated Annual Report</title>
<link rel="stylesheet" href="../_css/main.css?v.2018.4">
<link rel="stylesheet" href="../_js/jquery.fancybox.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	    <script src="//assets.adobedtm.com/cfd7100a02cbfa40b2c485d333da22f89ccabd9c/satelliteLib-e1a96af74edf26406b64b1c5cb0abedb7b5a6c6c.js"></script>
	</head>
<body class="brandRecognitions">
<header>
	<div class="header__hamburger">
		<span>MENU</span>
		<div class="header__hamburger__bars">
			<div></div>
		</div>
	</div>

	<a class="logoWrap" href="../index.php">
		<img class="header__logo" src="../_images/global/logo.svg">
	</a>
    <div class="container container--header">
        <div class="row">
			<div class="header__links">
				<span class="ir">2018 Integrated Annual Report</span>
				<ul>
					<li><a class="header__links__resources" href="#">Resources</a></li>
					<li><a class="header__links__download" href="#">Download</a></li>
					<li><a class="header__links__search" href="#"><i class="fas fa-search"></i></a></li>
					<li class="socialLink facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="socialLink twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
					<li class="socialLink linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="socialLink"><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
				</ul>
			</div>

			<div class="headerSearch">
				<div class="headerSearch__relativeWrapper">
					<form action="../search.php">
						<input class="headerSearch__input" type="text" class="search" name="q" id="tipue_search_input" autocomplete="off" placeholder="Search" required="">
						<span class="headerSearch__del">X</span>
					</form>
				</div>
			</div>

			<div class="headerResources">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../about.php">About This Report</a></li>
						<li><a href="../materiality.php">Materiality Overview</a></li>
						<li><a href="../gri.php">GRI Content Index</a></li>
						<li><a href="../info.php">Stockholder Information</a></li>
						<li><a target="_blank" href="https://www.thecloroxcompany.com/">The Clorox Company</a></li>
					</ul>
				</div>
			</div>

			<div class="downloads">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../Clorox_2018_Integrated_Report.pdf?v10-11-2018" target="_blank">Full PDF</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_English.pdf" target="_blank">Executive Summary English</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_Spanish.pdf" target="_blank">Executive Summary Spanish</a></li>
					</ul>
				</div>
			</div>
        </div>
	</div>

	<nav class="mainNav">
		<div class="mainNav__box mainNav__box--1">
			<a class="mainNav__mainLink" href="../ceo-letter/">CEO Letter</a>

			<img src="../_images/global/nav1.png" class="mainNav__product mainNav__product--1">
		</div>

		<div class="mainNav__box mainNav__box--2">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../strategy/">2020 Strategy</a>

				<ul class="secondaryNav">
					<li><a href="../strategy/people.php">Engage our People</a></li>
					<li><a href="../strategy/value.php">Drive Superior Consumer Value</a></li>
					<li><a href="../strategy/portfolio.php">Accelerate Portfolio Momentum</a></li>
					<li><a href="../strategy/growth.php">Fund Growth</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav2.png" class="mainNav__product mainNav__product--2">
		</div>

		<div class="mainNav__box mainNav__box--3">
			<a class="mainNav__mainLink" href="../innovation/">Innovation</a>

			<img src="../_images/global/nav3.png" class="mainNav__product mainNav__product--3">
		</div>

		<div class="mainNav__box mainNav__box--4">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../scorecard/">Scorecard</a>

				<ul class="secondaryNav">
					<li><a href="../scorecard/footprint.php">Global Footprint</a></li>
					<li><a href="../scorecard/performance.php">Performance</a></li>
					<li><a href="../scorecard/product.php">Product</a></li>
					<li><a href="../scorecard/people.php">People</a></li>
					<li><a href="../scorecard/community.php">Community</a></li>
					<li><a href="../scorecard/planet.php">Planet</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav4.png" class="mainNav__product mainNav__product--4">
		</div>

		<div class="mainNav__box mainNav__box--5">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../recognitions/">Recognitions</a>

				<ul class="secondaryNav">
					<li><a href="../recognitions/">Company Recognitions</a></li>
					<li><a href="../recognitions/brand.php">Brand Recognitions</a></li>
				</ul>
			</div>
			<img src="../_images/global/nav5.png" class="mainNav__product mainNav__product--5">
		</div>

		<div class="mainNav__box mainNav__box--6">
			<a class="mainNav__mainLink" href="../financials/">Financials</a>

			<img src="../_images/global/nav6.png" class="mainNav__product mainNav__product--6">
		</div>

		<div class="mainNav__box mainNav__box--7">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../governance/">Governance</a>

				<ul class="secondaryNav">
					<li><a href="../governance/board.php">Board of Directors</a></li>
					<li><a href="../governance/committee.php">Executive Committee</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav7.png" class="mainNav__product mainNav__product--7">
		</div>

		<div class="mainNav__box mainNav__box--mobile">
			<ul>
				<li class="facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li class="twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li class="linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
			</ul>
		</div>
	</nav>
</header>
<div class="interiorWrapper interiorWrapper--brandRecognitions">
	<div class="container">
		<div class="row">
			<div class="hero">
				<h1 class="pageTitle pageTitle--visible">Brand Recognitions</h1>
				<h2 class="sectionSubHeading centered margin-bottom-50">Because of our value, innovation and leadership, our brands were recognized around the globe for their products and marketing campaigns.</h2>
			</div>
		</div>

		<div class="row">
			<div class="recogs__wrapper centered">
				<div class="recogs recogs--row1">
					<div class="recogsLineMobile"></div>
					<h3 class="recogs__brand recogs__brand--orange">AYUDIN</h3>
					<span class="recogsCopy recogsCopy--brands recogsCopy--lOrange">YouTube TOP 3<br> Leaderboard,<br> April 2018</span>
					<span class="recogsCopy recogsCopy--location recogsCopy--orange">(Floor Cloth Ayudin,<br> Argentina)</span>
				</div>

				<div class="recogs recogs--row1">
					<div class="recogsLineMobile"></div>
					<img src="../_images/recognitions/brands/renewlife/logo2.png" alt="" class="brandsRecogs__logo brandsRecogs__logo--12">
					<div class="recogsInline__wrapper">
						<h3 class="recogs__brand recogs__brand--dBlue">RENEWLIFE</h3>
						<span class="recogsCopy recogsCopy--brands recogsCopy--lBlue">2018 Rated No.1<br> Probiotic Brand in<br> Consumer Satisfaction</span>
						<span class="recogsCopy recogsCopy--location recogsCopy--lBlue">ConsumerLab.com</span>
					</div>
				</div>

				<div class="recogs recogs--row1">
					<div class="recogsLineMobile"></div>
					<img src="../_images/recognitions/brands/burts-bees/logo7.png" class="brandsRecogs__logo">
					<div class="recogsInline__wrapper">
						<h3 class="recogs__brand recogs__brand--dGreen">BURT’S BEES</h3>
						<span class="recogsCopy recogsCopy--brands recogsCopy--mGreen">2017 WWD Prestige <br>Product of the Year</span>
						<span class="recogsCopy recogsCopy--location recogsCopy--dGreen">(Burt’s Bees Beauty)</span>
					</div>
				</div>
			</div>

			<div class="recogs__wrapper centered">
				<div class="recogs recogs--row2">
					<div class="recogsLineMobile"></div>
					<h3 class="recogs__brand recogs__brand--lBlue">CLOROX</h3>
					<span class="recogsCopy recogsCopy--brands recogsCopy--dBlue">No. 2 Ranking</span>
					<span class="recogsCopy recogsCopy--location recogsCopy--lBlue">Digital Genius, <br>2018 L2 Digital Report</span>
				</div>

				<div class="recogs recogs--row2">
					<div class="recogsLineMobile"></div>
					<h3 class="recogs__brand recogs__brand--dGreen">BURT’S BEES</h3>
					<span class="recogsCopy recogsCopy--brands recogsCopy--mGreen">No. 1 Brand in U.S.</span>
					<span class="recogsCopy recogsCopy--location recogsCopy--dGreen">2018 Union for Ethical <br>Biotrade Biodivesity <br>Barometer</span>
					<p class="footnote">Award is based on a survey of U.S.<br> consumers conducted by IPSOS on<br> behalf of UEBT. It is not an opinion<br> of or based on an assessment by UEBT.</p>
				</div>

				<div class="recogs recogs--row2">
					<div class="recogsLineMobile"></div>
					<img src="../_images/recognitions/brands/clorox/logo2.png" alt="" class="brandsRecogs__logo brandsRecogs__logo--8">
					<div class="recogsInline__wrapper">
						<h3 class="recogs__brand recogs__brand--lBlue">CLOROX</h3>
						<span class="recogsCopy recogsCopy--brands recogsCopy--dBlue">Good Housekeeping <br>Research Institute <br>2018</span>
						<span class="recogsCopy recogsCopy--location recogsCopy--lBlue">(Clorox<sup>®</sup> Scentiva <br>Multi-Surface Spray)</span>
					</div>
				</div>
			</div>

			<div class="recogs__wrapper centered">
				<div class="recogs recogs--row3">
					<div class="recogsLineMobile"></div>
					<img src="../_images/recognitions/brands/brita/image1.png" alt="" class="brandsRecogs__logo">
					<div class="recogsInline__wrapper">
						<h3 class="recogs__brand recogs__brand--dGreen">BRITA</h3>
						<span class="recogsCopy recogsCopy--brands recogsCopy--mGreen">Outstanding Merchandising <br>Achievement Award</span>
						<span class="recogsCopy recogsCopy--location recogsCopy--dGreen">General Merchandise, <br>Semipermanent – Gold Award, <br>2018 Shop! Association<br> (Brita Stream Target End Cap)</span>
					</div>
				</div>

				<div class="recogs recogs--row3">
					<div class="recogsLineMobile"></div>
					<h3 class="recogs__brand recogs__brand--lBlue">CLOROX PROFESSIONAL</h3>
					<span class="recogsCopy recogsCopy--brands recogsCopy--dBlue">2017 ISSA<br> Innovation of the<br> Year Award</span>
					<span class="recogsCopy recogsCopy--location recogsCopy--lBlue">(Clorox<sup>®</sup> Total<br> 360<sup>®</sup> System)</span>
				</div>

				<div class="recogs recogs--row3">
					<div class="recogsLineMobile"></div>
					<h3 class="recogs__brand recogs__brand--orange">CLOROX</h3>
					<span class="recogsCopy recogsCopy--brands recogsCopy--lOrange">Cannes Bronze Lion<br> for Brand Experience<br> and Activation</span>
					<span class="recogsCopy recogsCopy--location recogsCopy--orange">(Clorox<sup>®</sup> Concentrated <br>Bleach, Puerto Rico)</span>
				</div>
			</div>

			<div class="recogs__wrapper centered">
				<div class="recogs recogs--row4 padding-top-40">
					<div class="recogsLineMobile"></div>
					<h3 class="recogs__brand recogs__brand--orange">BRITA</h3>
					<span class="recogsCopy recogsCopy--brands recogsCopy--lOrange">2018 Leveraging Digital <br>Marketing Team</span>
					<span class="recogsCopy recogsCopy--location recogsCopy--orange">Large Company Winner,<br> Marketers That<br> Matter Awards</span>
				</div>
				
				<div class="recogs recogs--row4 padding-top-40">
					<div class="recogsLineMobile"></div>
					<img src="../_images/recognitions/brands/burts-bees/logo6.png" class="brandsRecogs__logo">
					<div class="recogsInline__wrapper">
						<h3 class="recogs__brand recogs__brand--mGreen">BURT’S BEES</h3>
						<span class="recogsCopy recogsCopy--brands recogsCopy--mGreen"><span>WINNER</span> <br>Champion for <br>Sustainability 2018, <br>Vogue Beauty <br>Awards</span>
						<span class="recogsCopy recogsCopy--location recogsCopy--mGreen">(U.K.)</span>
					</div>
				</div>

				<div class="recogs recogs--row4">
					<div class="recogsLineMobile"></div>
					<img src="../_images/recognitions/brands/glad/logo1.png" alt="" class="brandsRecogs__logo brandsRecogs__logo--10">
					<h3 class="recogs__brand recogs__brand--mBlue">GLAD</h3>
					<span class="recogsCopy recogsCopy--brands recogsCopy--dBlue">Cannes Bronze Lion<br> for Brand Experience<br> and Activation</span>
					<span class="recogsCopy recogsCopy--location recogsCopy--mBlue">(Glad Forceflex Plus <br>Advanced Protection)</span>
				</div>
			</div>

			<div class="recogs__wrapper centered">
				<div class="recogs recogs--row5">
					<div class="recogsLineMobile"></div>
					<h3 class="recogs__brand recogs__brand--dGreen">POETT</h3>
					<span class="recogsCopy recogsCopy--brands recogsCopy--mGreen">Lápiz de Oro 2017, <br>Editorial Dossier</span>
					<span class="recogsCopy recogsCopy--location recogsCopy--dGreen">(Poett® Fraganza,<br> Argentina)</span>
				</div>

				<div class="recogs recogs--row5">
					<div class="recogsLineMobile"></div>
					<h3 class="recogs__brand recogs__brand--lOrange">GLAD</h3>
					<span class="recogsCopy recogsCopy--brands recogsCopy--orange">National Leading<br> Enterprise in Quality of<br> Household Products,<br> 2015-18</span>
					<span class="recogsCopy recogsCopy--location recogsCopy--lOrange">(Mainland China)</span>
				</div>

				<div class="recogs recogs--row5 padding-top-40">
					<div class="recogsLineMobile"></div>
					<img src="../_images/recognitions/brands/renewlife/logo1.png" alt="" class="brandsRecogs__logo brandsRecogs__logo--11">
					<div class="recogsInline__wrapper">
						<h3 class="recogs__brand recogs__brand--orange">RENEWLIFE</h3>
						<span class="recogsCopy recogsCopy--brands recogsCopy--lOrange">2018 Vity Award, <br>Vitamin Retailer</span>
						<span class="recogsCopy recogsCopy--location recogsCopy--orange">(RenewLife 3-Day Cleanse)</span>
					</div>
				</div>
			</div>
		</div>

	
		<div class="row row--brandsLink">
			<a href="index.php"><img src="../_images/recognitions/company/linkIcon.svg" alt="">View our company recognitions</a>
		</div>
	</div>
</div>
<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="../_js/jquery.fancybox.min.js"></script>
<script src="../_js/jquery.mousewheel.js"></script>
<script src="../_js/greensock/TimelineMax.min.js"></script>
<script src="../_js/greensock/TweenMax.min.js"></script>
<script src="../_js/ScrollMagic.js"></script>
<script src="../_js/plugins/jquery.ScrollMagic.js"></script>
<script src="../_js/plugins/debug.addIndicators.js"></script>
<script src="../_js/greensock/plugins/DrawSVGPlugin.min.js"></script>
<script src="../_js/plugins/animation.gsap.js"></script>
<script src="../_js/jquery.cycle2.min.js"></script>
<script src="../_js/main.js?v.2018.2"></script><script>recogs();</script>
</body>
</html>
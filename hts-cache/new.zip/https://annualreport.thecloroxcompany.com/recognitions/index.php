<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=Edge"/>
<meta charset="UTF-8"><script type="text/javascript">window.NREUM||(NREUM={}),__nr_require=function(e,n,t){function r(t){if(!n[t]){var o=n[t]={exports:{}};e[t][0].call(o.exports,function(n){var o=e[t][1][n];return r(o||n)},o,o.exports)}return n[t].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<t.length;o++)r(t[o]);return r}({1:[function(e,n,t){function r(){}function o(e,n,t){return function(){return i(e,[c.now()].concat(u(arguments)),n?null:this,t),n?void 0:this}}var i=e("handle"),a=e(3),u=e(4),f=e("ee").get("tracer"),c=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],d="api-",l=d+"ixn-";a(p,function(e,n){s[n]=o(d+n,!0,"api")}),s.addPageAction=o(d+"addPageAction",!0),s.setCurrentRouteName=o(d+"routeName",!0),n.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,n){var t={},r=this,o="function"==typeof n;return i(l+"tracer",[c.now(),e,t],r),function(){if(f.emit((o?"":"no-")+"fn-start",[c.now(),r,o],t),o)try{return n.apply(this,arguments)}catch(e){throw f.emit("fn-err",[arguments,this,e],t),e}finally{f.emit("fn-end",[c.now()],t)}}}};a("actionText,setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,n){m[n]=o(l+n)}),newrelic.noticeError=function(e,n){"string"==typeof e&&(e=new Error(e)),i("err",[e,c.now(),!1,n])}},{}],2:[function(e,n,t){function r(e,n){if(!o)return!1;if(e!==o)return!1;if(!n)return!0;if(!i)return!1;for(var t=i.split("."),r=n.split("."),a=0;a<r.length;a++)if(r[a]!==t[a])return!1;return!0}var o=null,i=null,a=/Version\/(\S+)\s+Safari/;if(navigator.userAgent){var u=navigator.userAgent,f=u.match(a);f&&u.indexOf("Chrome")===-1&&u.indexOf("Chromium")===-1&&(o="Safari",i=f[1])}n.exports={agent:o,version:i,match:r}},{}],3:[function(e,n,t){function r(e,n){var t=[],r="",i=0;for(r in e)o.call(e,r)&&(t[i]=n(r,e[r]),i+=1);return t}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],4:[function(e,n,t){function r(e,n,t){n||(n=0),"undefined"==typeof t&&(t=e?e.length:0);for(var r=-1,o=t-n||0,i=Array(o<0?0:o);++r<o;)i[r]=e[n+r];return i}n.exports=r},{}],5:[function(e,n,t){n.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,n,t){function r(){}function o(e){function n(e){return e&&e instanceof r?e:e?f(e,u,i):i()}function t(t,r,o,i){if(!d.aborted||i){e&&e(t,r,o);for(var a=n(o),u=v(t),f=u.length,c=0;c<f;c++)u[c].apply(a,r);var p=s[y[t]];return p&&p.push([b,t,r,a]),a}}function l(e,n){h[e]=v(e).concat(n)}function m(e,n){var t=h[e];if(t)for(var r=0;r<t.length;r++)t[r]===n&&t.splice(r,1)}function v(e){return h[e]||[]}function g(e){return p[e]=p[e]||o(t)}function w(e,n){c(e,function(e,t){n=n||"feature",y[t]=n,n in s||(s[n]=[])})}var h={},y={},b={on:l,addEventListener:l,removeEventListener:m,emit:t,get:g,listeners:v,context:n,buffer:w,abort:a,aborted:!1};return b}function i(){return new r}function a(){(s.api||s.feature)&&(d.aborted=!0,s=d.backlog={})}var u="nr@context",f=e("gos"),c=e(3),s={},p={},d=n.exports=o();d.backlog=s},{}],gos:[function(e,n,t){function r(e,n,t){if(o.call(e,n))return e[n];var r=t();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,n,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return e[n]=r,r}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],handle:[function(e,n,t){function r(e,n,t,r){o.buffer([e],r),o.emit(e,n,t)}var o=e("ee").get("handle");n.exports=r,r.ee=o},{}],id:[function(e,n,t){function r(e){var n=typeof e;return!e||"object"!==n&&"function"!==n?-1:e===window?0:a(e,i,function(){return o++})}var o=1,i="nr@id",a=e("gos");n.exports=r},{}],loader:[function(e,n,t){function r(){if(!E++){var e=x.info=NREUM.info,n=l.getElementsByTagName("script")[0];if(setTimeout(s.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&n))return s.abort();c(y,function(n,t){e[n]||(e[n]=t)}),f("mark",["onload",a()+x.offset],null,"api");var t=l.createElement("script");t.src="https://"+e.agent,n.parentNode.insertBefore(t,n)}}function o(){"complete"===l.readyState&&i()}function i(){f("mark",["domContent",a()+x.offset],null,"api")}function a(){return O.exists&&performance.now?Math.round(performance.now()):(u=Math.max((new Date).getTime(),u))-x.offset}var u=(new Date).getTime(),f=e("handle"),c=e(3),s=e("ee"),p=e(2),d=window,l=d.document,m="addEventListener",v="attachEvent",g=d.XMLHttpRequest,w=g&&g.prototype;NREUM.o={ST:setTimeout,SI:d.setImmediate,CT:clearTimeout,XHR:g,REQ:d.Request,EV:d.Event,PR:d.Promise,MO:d.MutationObserver};var h=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1118.min.js"},b=g&&w&&w[m]&&!/CriOS/.test(navigator.userAgent),x=n.exports={offset:u,now:a,origin:h,features:{},xhrWrappable:b,userAgent:p};e(1),l[m]?(l[m]("DOMContentLoaded",i,!1),d[m]("load",r,!1)):(l[v]("onreadystatechange",o),d[v]("onload",r)),f("mark",["firstbyte",u],null,"api");var E=0,O=e(5)},{}]},{},["loader"]);</script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="../_images/global/shareImage.png?v.2018.1" />

<title>Clorox 2018 Integrated Annual Report</title>
<link rel="stylesheet" href="../_css/main.css?v.2018.4">
<link rel="stylesheet" href="../_js/jquery.fancybox.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	    <script src="//assets.adobedtm.com/cfd7100a02cbfa40b2c485d333da22f89ccabd9c/satelliteLib-e1a96af74edf26406b64b1c5cb0abedb7b5a6c6c.js"></script>
	</head>
<body class="companyRecognitions">
<header>
	<div class="header__hamburger">
		<span>MENU</span>
		<div class="header__hamburger__bars">
			<div></div>
		</div>
	</div>

	<a class="logoWrap" href="../index.php">
		<img class="header__logo" src="../_images/global/logo.svg">
	</a>
    <div class="container container--header">
        <div class="row">
			<div class="header__links">
				<span class="ir">2018 Integrated Annual Report</span>
				<ul>
					<li><a class="header__links__resources" href="#">Resources</a></li>
					<li><a class="header__links__download" href="#">Download</a></li>
					<li><a class="header__links__search" href="#"><i class="fas fa-search"></i></a></li>
					<li class="socialLink facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="socialLink twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
					<li class="socialLink linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="socialLink"><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
				</ul>
			</div>

			<div class="headerSearch">
				<div class="headerSearch__relativeWrapper">
					<form action="../search.php">
						<input class="headerSearch__input" type="text" class="search" name="q" id="tipue_search_input" autocomplete="off" placeholder="Search" required="">
						<span class="headerSearch__del">X</span>
					</form>
				</div>
			</div>

			<div class="headerResources">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../about.php">About This Report</a></li>
						<li><a href="../materiality.php">Materiality Overview</a></li>
						<li><a href="../gri.php">GRI Content Index</a></li>
						<li><a href="../info.php">Stockholder Information</a></li>
						<li><a target="_blank" href="https://www.thecloroxcompany.com/">The Clorox Company</a></li>
					</ul>
				</div>
			</div>

			<div class="downloads">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../Clorox_2018_Integrated_Report.pdf?v10-11-2018" target="_blank">Full PDF</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_English.pdf" target="_blank">Executive Summary English</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_Spanish.pdf" target="_blank">Executive Summary Spanish</a></li>
					</ul>
				</div>
			</div>
        </div>
	</div>

	<nav class="mainNav">
		<div class="mainNav__box mainNav__box--1">
			<a class="mainNav__mainLink" href="../ceo-letter/">CEO Letter</a>

			<img src="../_images/global/nav1.png" class="mainNav__product mainNav__product--1">
		</div>

		<div class="mainNav__box mainNav__box--2">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../strategy/">2020 Strategy</a>

				<ul class="secondaryNav">
					<li><a href="../strategy/people.php">Engage our People</a></li>
					<li><a href="../strategy/value.php">Drive Superior Consumer Value</a></li>
					<li><a href="../strategy/portfolio.php">Accelerate Portfolio Momentum</a></li>
					<li><a href="../strategy/growth.php">Fund Growth</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav2.png" class="mainNav__product mainNav__product--2">
		</div>

		<div class="mainNav__box mainNav__box--3">
			<a class="mainNav__mainLink" href="../innovation/">Innovation</a>

			<img src="../_images/global/nav3.png" class="mainNav__product mainNav__product--3">
		</div>

		<div class="mainNav__box mainNav__box--4">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../scorecard/">Scorecard</a>

				<ul class="secondaryNav">
					<li><a href="../scorecard/footprint.php">Global Footprint</a></li>
					<li><a href="../scorecard/performance.php">Performance</a></li>
					<li><a href="../scorecard/product.php">Product</a></li>
					<li><a href="../scorecard/people.php">People</a></li>
					<li><a href="../scorecard/community.php">Community</a></li>
					<li><a href="../scorecard/planet.php">Planet</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav4.png" class="mainNav__product mainNav__product--4">
		</div>

		<div class="mainNav__box mainNav__box--5">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../recognitions/">Recognitions</a>

				<ul class="secondaryNav">
					<li><a href="../recognitions/">Company Recognitions</a></li>
					<li><a href="../recognitions/brand.php">Brand Recognitions</a></li>
				</ul>
			</div>
			<img src="../_images/global/nav5.png" class="mainNav__product mainNav__product--5">
		</div>

		<div class="mainNav__box mainNav__box--6">
			<a class="mainNav__mainLink" href="../financials/">Financials</a>

			<img src="../_images/global/nav6.png" class="mainNav__product mainNav__product--6">
		</div>

		<div class="mainNav__box mainNav__box--7">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../governance/">Governance</a>

				<ul class="secondaryNav">
					<li><a href="../governance/board.php">Board of Directors</a></li>
					<li><a href="../governance/committee.php">Executive Committee</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav7.png" class="mainNav__product mainNav__product--7">
		</div>

		<div class="mainNav__box mainNav__box--mobile">
			<ul>
				<li class="facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li class="twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li class="linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
			</ul>
		</div>
	</nav>
</header>
<div class="interiorWrapper interiorWrapper--companyRecognitions">
	<div class="container">
		<div class="row">
			<div class="hero">
				<h1 class="pageTitle pageTitle--visible">Company Recognitions</h1>
				<h2 class="sectionSubHeading centered margin-bottom-50">The company brand was broadly recognized for its business and corporate responsibility<br class="spaceReplace">achievements in fiscal year 2018.</h2>
			</div>
		</div>
		<div class="row">
			<div class="recogs__wrapper centered">
				<div class="recogs recogs--third recogs--company1">
					<div class="recogsLineMobile"></div>
					<img src="../_images/recognitions/company/logo1.png" alt="" class="companyRecogs__logo companyRecogs__logo--1">
					<div class="recogsInline__wrapper">
						<span class="recogsCopy recogsCopy--med recogsCopy--lBlue"><strong>No. 15</strong> <br>Ranking</span>
					</div>
				</div>
				<div class="recogs recogs--third recogs--company2">
					<div class="recogsLineMobile"></div>
					<span class="recogsCopy recogsCopy--small recogsCopy--orange"><span>2018</span> <br><strong>Best of the best<br> list of top<br> employers</strong></span>
					<span class="recogs__source recogs__source--lOrange">—Hispanic Network Magazine</span>
				</div>
				<div class="recogs recogs--third recogs--company3">
					<div class="recogsLineMobile"></div>
					<img src="../_images/recognitions/company/logo2.png" alt="" class="companyRecogs__logo companyRecogs__logo--2">
					<div class="recogsInline__wrapper">
						<span class="recogsCopy recogsCopy--large recogsCopy--lBlue">No. 15</span>
						<span class="recogsCopy recogsCopy--small recogsCopy--mBlue"><strong>U.S. RepTrack<sup>&reg;</sup> <br>Top 100 List</strong></span>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="recogs__wrapper centered">
				<div class="recogs recogs--fourth recogs--company4">
					<div class="recogsLineMobile"></div>
					<span class="recogsCopy recogsCopy--small recogsCopy--dBlue"><strong>2017 Thomson <br>Reuters Diversity <br>and Inclusion <br>Index:</strong></span>
					<span class="recogsCopy recogsCopy--large recogsCopy--lBlue">No. 28</span>
					<span class="recogsCopy recogsCopy--location recogsCopy--dBlue">(among top 100 most<br> diverse and inclusive<br> organizations globally)</span>
				</div>
				<div class="recogs recogs--fourth recogs--company5">
					<div class="recogsLineMobile"></div>
					<span class="recogsCopy recogsCopy--large recogsCopy--mGreen">No. 77</span>
					<div class="recogsCopy recogsCopy--small recogsCopy--dGreen"><strong>World’s Most <br>Innovative Companies</strong></div>
					<span class="recogsCopy recogsCopy--location recogsCopy--mGreen">(among 100 ranked companies)</span>
					<span class="recogs__source recogs__source--mGreen">—Forbes</span>
				</div>
				<div class="recogs recogs--fourth recogs--company6">
					<div class="recogsLineMobile"></div>
					<span class="recogsCopy recogsCopy--small recogsCopy--lBlue"><strong>Clean Industry <br>Certification</strong></span>
					<span class="recogsCopy recogsCopy--location recogsCopy--mBlue">(Clorox Mexico)</span>
					<span class="recogs__source recogs__source--lBlue">–PROFEPA (Mexican <br>Environmental Authority)</span>
				</div>
				<div class="recogs recogs--fourth recogs--company7">
					<div class="recogsLineMobile"></div>
					<img class="companyRecogs__logo companyRecogs__logo--3" src="../_images/recognitions/company/logo3.png" alt="">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="recogs__wrapper centered">
				<div class="recogs recogs--fourth recogs--company8">
					<div class="recogsLineMobile"></div>
					<img src="../_images/recognitions/company/logo4.png" alt="" class="companyRecogs__logo companyRecogs__logo--4">
					<span class="recogsCopy recogsCopy--large recogsCopy--lGreen">No. 20 Ranking</span>
					<span class="recogsCopy recogsCopy--small recogsCopy--dGreen"><strong>100 Best Corporate Citizens 2018</strong></span>
					<span class="recogs__source recogs__source--mGreen">—CR Magazine</span>
				</div>
				<div class="recogs recogs--fourth recogs--company9">
					<div class="recogsLineMobile"></div>
					<img src="../_images/recognitions/company/logo5.svg" alt="" class="companyRecogs__logo companyRecogs__logo--5">
					<span class="recogsCopy recogsCopy--med recogsCopy--lBlue centered"><strong>No. 36</strong> <br>Ranking</span>
					<span class="recogsCopy recogsCopy--location recogsCopy--dBlue">(among top 100 of<br>1,000 companies<br>analyzed)</span>
				</div>
				<div class="recogs recogs--fourth recogs--company10">
					<div class="recogsLineMobile"></div>
					<img src="../_images/recognitions/company/logo6.svg" alt="" class="companyRecogs__logo companyRecogs__logo--6">
					<span class="recogsCopy recogsCopy--scores recogsCopy--dBlue"><strong>Perfect <br>Scores <br>Since 2006</strong></span>
				</div>
				<div class="recogs recogs--fourth recogs--company15">
					<div class="recogsLineMobile"></div>
					<span class="recogsCopy recogsCopy--large recogsCopy--mGreen">No. 207</span>
					<span class="recogsCopy recogsCopy--small recogsCopy--lGreen">2017 global 2000:</span>
					<span class="recogsCopy recogsCopy--location2 recogsCopy--dGreen">Top Regarded<br> Companies</span>
					<span class="recogsCopy recogsCopy--location recogsCopy--dGreen">(among 250<br> ranked global<br> public companies)</span>
					<span class="recogs__source recogs__source--dGreen">—Forbes</span>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="recogs__wrapper centered recogs__wrapper--last">
				<div class="recogs recogs--fourth recogs--company11">
					<div class="recogsLineMobile"></div>
					<span class="recogsCopy recogsCopy--small recogsCopy--dBlue">50 out front list</span>
					<span class="recogsCopy recogsCopy--large recogsCopy--lBlue">No. 5 <br>Ranking</span>
					<span class="recogsCopy recogsCopy--small recogsCopy--dBlue"><strong>best places for women and diverse managers to work</strong></span>
					<span class="recogs__source recogs__source--lBlue">—Diversity MBA Magazine</span>
				</div>
				<div class="recogs recogs--fourth recogs--company12">
					<div class="recogsLineMobile"></div>
					<span class="recogsCopy recogsCopy--small recogsCopy--lOrange">2017 silver level <br>and platinum level <br>process safety <br>performance </span>
					<span class="recogsCopy recogsCopy--location recogsCopy--orange">(Caguas, Puerto Rico, <br>Plant)</span>
					<span class="recogs__source recogs__source--orange">—The Chlorine Institute</span>
				</div>
				<div class="recogs recogs--fourth recogs--company13">
					<div class="recogsLineMobile"></div>
					<img src="../_images/recognitions/company/logo7.svg" alt="" class="companyRecogs__logo companyRecogs__logo--7">
					<span class="recogsCopy recogsCopy--med recogsCopy--dBlue"><strong>No. 9</strong> <br>Ranking</span>
				</div>
				<div class="recogs recogs--fourth recogs--company14">
					<div class="recogsLineMobile"></div>
					<span class="recogsCopy recogsCopy--large recogsCopy--mGreen">No. 178</span>
					<span class="recogsCopy recogsCopy--small recogsCopy--lGreen">2017 global 2000:</span>
					<span class="recogsCopy recogsCopy--location2 recogsCopy--dGreen">World’s Best Employers</span>
					<span class="recogsCopy recogsCopy--location recogsCopy--dGreen">(among 500 ranked<br> global public companies)</span>
					<span class="recogs__source recogs__source--mGreen">—Forbes</span>
				</div>
			</div>
		</div>
		<div class="row row--brandsLink">
			<a href="brand.php"><img src="../_images/recognitions/company/linkIcon.svg" alt="">View our brand recognitions</a>
		</div>
	</div>
</div>

<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="../_js/jquery.fancybox.min.js"></script>
<script src="../_js/jquery.mousewheel.js"></script>
<script src="../_js/greensock/TimelineMax.min.js"></script>
<script src="../_js/greensock/TweenMax.min.js"></script>
<script src="../_js/ScrollMagic.js"></script>
<script src="../_js/plugins/jquery.ScrollMagic.js"></script>
<script src="../_js/plugins/debug.addIndicators.js"></script>
<script src="../_js/greensock/plugins/DrawSVGPlugin.min.js"></script>
<script src="../_js/plugins/animation.gsap.js"></script>
<script src="../_js/jquery.cycle2.min.js"></script>
<script src="../_js/main.js?v.2018.2"></script><script>recogs();</script>
<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"90a95d8474","applicationID":"2526212","transactionName":"MgRaYxZVDBIDW0BbWQtObUUNGxAEAVdTXF8RCFdZFxsLDwZdTBxGDRE=","queueTime":0,"applicationTime":0,"atts":"HkNZFV5PHxw=","errorBeacon":"bam.nr-data.net","agent":""}</script></body>
</html>
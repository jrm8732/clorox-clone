<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=Edge"/>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="../_images/global/shareImage.png?v.2018.1" />

<title>Clorox 2018 Integrated Annual Report</title>
<link rel="stylesheet" href="../_css/main.css?v.2018.4">
<link rel="stylesheet" href="../_js/jquery.fancybox.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	    <script src="//assets.adobedtm.com/cfd7100a02cbfa40b2c485d333da22f89ccabd9c/satelliteLib-e1a96af74edf26406b64b1c5cb0abedb7b5a6c6c.js"></script>
	</head>
<body class="scorecardInterior">
<header>
	<div class="header__hamburger">
		<span>MENU</span>
		<div class="header__hamburger__bars">
			<div></div>
		</div>
	</div>

	<a class="logoWrap" href="../index.php">
		<img class="header__logo" src="../_images/global/logo.svg">
	</a>
    <div class="container container--header">
        <div class="row">
			<div class="header__links">
				<span class="ir">2018 Integrated Annual Report</span>
				<ul>
					<li><a class="header__links__resources" href="#">Resources</a></li>
					<li><a class="header__links__download" href="#">Download</a></li>
					<li><a class="header__links__search" href="#"><i class="fas fa-search"></i></a></li>
					<li class="socialLink facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="socialLink twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
					<li class="socialLink linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="socialLink"><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
				</ul>
			</div>

			<div class="headerSearch">
				<div class="headerSearch__relativeWrapper">
					<form action="../search.php">
						<input class="headerSearch__input" type="text" class="search" name="q" id="tipue_search_input" autocomplete="off" placeholder="Search" required="">
						<span class="headerSearch__del">X</span>
					</form>
				</div>
			</div>

			<div class="headerResources">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../about.php">About This Report</a></li>
						<li><a href="../materiality.php">Materiality Overview</a></li>
						<li><a href="../gri.php">GRI Content Index</a></li>
						<li><a href="../info.php">Stockholder Information</a></li>
						<li><a target="_blank" href="https://www.thecloroxcompany.com/">The Clorox Company</a></li>
					</ul>
				</div>
			</div>

			<div class="downloads">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../Clorox_2018_Integrated_Report.pdf?v10-11-2018" target="_blank">Full PDF</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_English.pdf" target="_blank">Executive Summary English</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_Spanish.pdf" target="_blank">Executive Summary Spanish</a></li>
					</ul>
				</div>
			</div>
        </div>
	</div>

	<nav class="mainNav">
		<div class="mainNav__box mainNav__box--1">
			<a class="mainNav__mainLink" href="../ceo-letter/">CEO Letter</a>

			<img src="../_images/global/nav1.png" class="mainNav__product mainNav__product--1">
		</div>

		<div class="mainNav__box mainNav__box--2">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../strategy/">2020 Strategy</a>

				<ul class="secondaryNav">
					<li><a href="../strategy/people.php">Engage our People</a></li>
					<li><a href="../strategy/value.php">Drive Superior Consumer Value</a></li>
					<li><a href="../strategy/portfolio.php">Accelerate Portfolio Momentum</a></li>
					<li><a href="../strategy/growth.php">Fund Growth</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav2.png" class="mainNav__product mainNav__product--2">
		</div>

		<div class="mainNav__box mainNav__box--3">
			<a class="mainNav__mainLink" href="../innovation/">Innovation</a>

			<img src="../_images/global/nav3.png" class="mainNav__product mainNav__product--3">
		</div>

		<div class="mainNav__box mainNav__box--4">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../scorecard/">Scorecard</a>

				<ul class="secondaryNav">
					<li><a href="../scorecard/footprint.php">Global Footprint</a></li>
					<li><a href="../scorecard/performance.php">Performance</a></li>
					<li><a href="../scorecard/product.php">Product</a></li>
					<li><a href="../scorecard/people.php">People</a></li>
					<li><a href="../scorecard/community.php">Community</a></li>
					<li><a href="../scorecard/planet.php">Planet</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav4.png" class="mainNav__product mainNav__product--4">
		</div>

		<div class="mainNav__box mainNav__box--5">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../recognitions/">Recognitions</a>

				<ul class="secondaryNav">
					<li><a href="../recognitions/">Company Recognitions</a></li>
					<li><a href="../recognitions/brand.php">Brand Recognitions</a></li>
				</ul>
			</div>
			<img src="../_images/global/nav5.png" class="mainNav__product mainNav__product--5">
		</div>

		<div class="mainNav__box mainNav__box--6">
			<a class="mainNav__mainLink" href="../financials/">Financials</a>

			<img src="../_images/global/nav6.png" class="mainNav__product mainNav__product--6">
		</div>

		<div class="mainNav__box mainNav__box--7">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../governance/">Governance</a>

				<ul class="secondaryNav">
					<li><a href="../governance/board.php">Board of Directors</a></li>
					<li><a href="../governance/committee.php">Executive Committee</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav7.png" class="mainNav__product mainNav__product--7">
		</div>

		<div class="mainNav__box mainNav__box--mobile">
			<ul>
				<li class="facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li class="twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li class="linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
			</ul>
		</div>
	</nav>
</header>
<div class="interiorWrapper interiorWrapper--scorecard interiorWrapper--scorecard--secondary">
	<div class="container">
		<div class="row">
			<h1 class="scorecardHeading scorecardHeading--small">2018 Scorecard</h1>
        </div>
        
        <div class="row">
            <div class="scorecardWrap">
                <div class="scoreRow">
                    <div class="scorecardTitleWrap">
                        <h1 class="heading heading--performance">community</h1>
                        <p class="scorecardText">Safeguarding families through<br> initiatives that promote health,<br> education and safety.</p>
                    </div>

                    <div class="shelf shelf--community--1">
                        <div class="shelf__wrap">
							<div class="scorecardStat scorecardStat--community padding-bottom-20">
								<div class="scorecardStat__num scorecardStat__num--dGreen">$2.5M<sup>1</sup></div>
								<div class="scorecardStat__text scorecardStat__text--green"><span class="small">Or</span> 101,170 Employee<br> Volunteer Hours <span class="small"> in CY 2017</span></div>
							</div>

							<img src="../_images/scorecard/community/image1.png" class="scorecardStat scorecardStat--image2">
						</div>
                    </div>
                </div>

                <div class="scoreRow">
                    <div class="shelf shelf--community--2">
                        <div class="shelf__wrap">
							<div class="scorecardStat scorecardStat--community">
								<div class="scorecardStat__num scorecardStat__num--dGreen">$4.6M</div>
								<span class="scorecardStat__text scorecardStat__text--green">Foundation and<br> Corporate Community<br> Cash Grants<sup>2</sup></span>
							</div>

							<div class="scorecardStat scorecardStat--community">
								<div class="scorecardStat__num scorecardStat__num--dGreen">$14.4M</div>
								<span class="scorecardStat__text scorecardStat__text--green">U.S.CORPORATE<br>PRODUCT DONATIONS <img src="../_images/scorecard/global/a.svg" class="aNote"></span>
							</div>

							<div class="scorecardStat scorecardStat--community">
								<div class="scorecardStat__num scorecardStat__num--dGreen">$673K</div>
								<span class="scorecardStat__text scorecardStat__text--green">U.S.CAUSE-MARKETING<br>CONTRIBUTIONS</span>
							</div>

							<div class="scorecardStat scorecardStat--community">
								<div class="scorecardStat__num scorecardStat__num--dGreen">$19.7M</div>
								<span class="scorecardStat__goal scorecardStat__goal--community">TOTAL<br>IMPACT</span>
							</div>
						</div>
                    </div>
                </div>
            </div>
        </div>
		<div class="row">
			<div class="content footnoteLinkWrap">
				<a href="#footnotes" data-fancybox>View Footnotes</a>
			</div>
		</div>
	</div>
	<a href="people.php"><img src="../_images/scorecard/global/left.svg" class="scorecardLeft"></a>
    <a href="planet.php"><img src="../_images/scorecard/global/right.svg" class="scorecardRight"></a>
</div>

<div id="footnotes" class="scorecard__footnotesWrap">
	<div class="container">
		<div class="row">
			<div class="footnotesWrapper">
				<ol class="footnotesList">
					<li>Financial equivalent of 101,170 volunteer hours, calculated at $24.69 per hour, based on the 2017 U.S. value of volunteer time from IndependentSector.org. Less than 5 percent of these hours are by employees outside the U.S., but all are calculated using the U.S. average rate.</li>
					<li>This metric is based on an updated methodology to better reflect the amount directly benefiting community organizations we support.</li>
				</ol>
			</div>
		</div>
	</div>
</div>
<div class="subnav subnav--scorecard">
	<div class="container">
		<div class="row">
			<ul class="subNav__items">
				<li><a href="index.php">2018<br> Scorecard</a></li>
				<li><a href="footprint.php">global<br> footprint</a></li>
				<li class="single"><a href="performance.php">performance</a></li>
				<li class="single"><a href="product.php">product</a></li>
				<li class="single"><a href="people.php">people</a></li>
				<li class="single"><a href="community.php">community</a></li>
				<li class="single"><a href="planet.php">planet</a></li>
			</ul>
		</div>
	</div>
</div>
<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="../_js/jquery.fancybox.min.js"></script>
<script src="../_js/jquery.mousewheel.js"></script>
<script src="../_js/greensock/TimelineMax.min.js"></script>
<script src="../_js/greensock/TweenMax.min.js"></script>
<script src="../_js/ScrollMagic.js"></script>
<script src="../_js/plugins/jquery.ScrollMagic.js"></script>
<script src="../_js/plugins/debug.addIndicators.js"></script>
<script src="../_js/greensock/plugins/DrawSVGPlugin.min.js"></script>
<script src="../_js/plugins/animation.gsap.js"></script>
<script src="../_js/jquery.cycle2.min.js"></script>
<script src="../_js/main.js?v.2018.2"></script><script src="../_js/scorecard.js"></script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=Edge"/>
<meta charset="UTF-8"><script type="text/javascript">window.NREUM||(NREUM={}),__nr_require=function(e,n,t){function r(t){if(!n[t]){var o=n[t]={exports:{}};e[t][0].call(o.exports,function(n){var o=e[t][1][n];return r(o||n)},o,o.exports)}return n[t].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<t.length;o++)r(t[o]);return r}({1:[function(e,n,t){function r(){}function o(e,n,t){return function(){return i(e,[c.now()].concat(u(arguments)),n?null:this,t),n?void 0:this}}var i=e("handle"),a=e(3),u=e(4),f=e("ee").get("tracer"),c=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],d="api-",l=d+"ixn-";a(p,function(e,n){s[n]=o(d+n,!0,"api")}),s.addPageAction=o(d+"addPageAction",!0),s.setCurrentRouteName=o(d+"routeName",!0),n.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,n){var t={},r=this,o="function"==typeof n;return i(l+"tracer",[c.now(),e,t],r),function(){if(f.emit((o?"":"no-")+"fn-start",[c.now(),r,o],t),o)try{return n.apply(this,arguments)}catch(e){throw f.emit("fn-err",[arguments,this,e],t),e}finally{f.emit("fn-end",[c.now()],t)}}}};a("actionText,setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,n){m[n]=o(l+n)}),newrelic.noticeError=function(e,n){"string"==typeof e&&(e=new Error(e)),i("err",[e,c.now(),!1,n])}},{}],2:[function(e,n,t){function r(e,n){if(!o)return!1;if(e!==o)return!1;if(!n)return!0;if(!i)return!1;for(var t=i.split("."),r=n.split("."),a=0;a<r.length;a++)if(r[a]!==t[a])return!1;return!0}var o=null,i=null,a=/Version\/(\S+)\s+Safari/;if(navigator.userAgent){var u=navigator.userAgent,f=u.match(a);f&&u.indexOf("Chrome")===-1&&u.indexOf("Chromium")===-1&&(o="Safari",i=f[1])}n.exports={agent:o,version:i,match:r}},{}],3:[function(e,n,t){function r(e,n){var t=[],r="",i=0;for(r in e)o.call(e,r)&&(t[i]=n(r,e[r]),i+=1);return t}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],4:[function(e,n,t){function r(e,n,t){n||(n=0),"undefined"==typeof t&&(t=e?e.length:0);for(var r=-1,o=t-n||0,i=Array(o<0?0:o);++r<o;)i[r]=e[n+r];return i}n.exports=r},{}],5:[function(e,n,t){n.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,n,t){function r(){}function o(e){function n(e){return e&&e instanceof r?e:e?f(e,u,i):i()}function t(t,r,o,i){if(!d.aborted||i){e&&e(t,r,o);for(var a=n(o),u=v(t),f=u.length,c=0;c<f;c++)u[c].apply(a,r);var p=s[y[t]];return p&&p.push([b,t,r,a]),a}}function l(e,n){h[e]=v(e).concat(n)}function m(e,n){var t=h[e];if(t)for(var r=0;r<t.length;r++)t[r]===n&&t.splice(r,1)}function v(e){return h[e]||[]}function g(e){return p[e]=p[e]||o(t)}function w(e,n){c(e,function(e,t){n=n||"feature",y[t]=n,n in s||(s[n]=[])})}var h={},y={},b={on:l,addEventListener:l,removeEventListener:m,emit:t,get:g,listeners:v,context:n,buffer:w,abort:a,aborted:!1};return b}function i(){return new r}function a(){(s.api||s.feature)&&(d.aborted=!0,s=d.backlog={})}var u="nr@context",f=e("gos"),c=e(3),s={},p={},d=n.exports=o();d.backlog=s},{}],gos:[function(e,n,t){function r(e,n,t){if(o.call(e,n))return e[n];var r=t();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,n,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return e[n]=r,r}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],handle:[function(e,n,t){function r(e,n,t,r){o.buffer([e],r),o.emit(e,n,t)}var o=e("ee").get("handle");n.exports=r,r.ee=o},{}],id:[function(e,n,t){function r(e){var n=typeof e;return!e||"object"!==n&&"function"!==n?-1:e===window?0:a(e,i,function(){return o++})}var o=1,i="nr@id",a=e("gos");n.exports=r},{}],loader:[function(e,n,t){function r(){if(!E++){var e=x.info=NREUM.info,n=l.getElementsByTagName("script")[0];if(setTimeout(s.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&n))return s.abort();c(y,function(n,t){e[n]||(e[n]=t)}),f("mark",["onload",a()+x.offset],null,"api");var t=l.createElement("script");t.src="https://"+e.agent,n.parentNode.insertBefore(t,n)}}function o(){"complete"===l.readyState&&i()}function i(){f("mark",["domContent",a()+x.offset],null,"api")}function a(){return O.exists&&performance.now?Math.round(performance.now()):(u=Math.max((new Date).getTime(),u))-x.offset}var u=(new Date).getTime(),f=e("handle"),c=e(3),s=e("ee"),p=e(2),d=window,l=d.document,m="addEventListener",v="attachEvent",g=d.XMLHttpRequest,w=g&&g.prototype;NREUM.o={ST:setTimeout,SI:d.setImmediate,CT:clearTimeout,XHR:g,REQ:d.Request,EV:d.Event,PR:d.Promise,MO:d.MutationObserver};var h=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1118.min.js"},b=g&&w&&w[m]&&!/CriOS/.test(navigator.userAgent),x=n.exports={offset:u,now:a,origin:h,features:{},xhrWrappable:b,userAgent:p};e(1),l[m]?(l[m]("DOMContentLoaded",i,!1),d[m]("load",r,!1)):(l[v]("onreadystatechange",o),d[v]("onload",r)),f("mark",["firstbyte",u],null,"api");var E=0,O=e(5)},{}]},{},["loader"]);</script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="../_images/global/shareImage.png?v.2018.1" />

<title>Clorox 2018 Integrated Annual Report</title>
<link rel="stylesheet" href="../_css/main.css?v.2018.4">
<link rel="stylesheet" href="../_js/jquery.fancybox.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	    <script src="//assets.adobedtm.com/cfd7100a02cbfa40b2c485d333da22f89ccabd9c/satelliteLib-e1a96af74edf26406b64b1c5cb0abedb7b5a6c6c.js"></script>
	</head>
<body>
<header>
	<div class="header__hamburger">
		<span>MENU</span>
		<div class="header__hamburger__bars">
			<div></div>
		</div>
	</div>

	<a class="logoWrap" href="../index.php">
		<img class="header__logo" src="../_images/global/logo.svg">
	</a>
    <div class="container container--header">
        <div class="row">
			<div class="header__links">
				<span class="ir">2018 Integrated Annual Report</span>
				<ul>
					<li><a class="header__links__resources" href="#">Resources</a></li>
					<li><a class="header__links__download" href="#">Download</a></li>
					<li><a class="header__links__search" href="#"><i class="fas fa-search"></i></a></li>
					<li class="socialLink facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="socialLink twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
					<li class="socialLink linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="socialLink"><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
				</ul>
			</div>

			<div class="headerSearch">
				<div class="headerSearch__relativeWrapper">
					<form action="../search.php">
						<input class="headerSearch__input" type="text" class="search" name="q" id="tipue_search_input" autocomplete="off" placeholder="Search" required="">
						<span class="headerSearch__del">X</span>
					</form>
				</div>
			</div>

			<div class="headerResources">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../about.php">About This Report</a></li>
						<li><a href="../materiality.php">Materiality Overview</a></li>
						<li><a href="../gri.php">GRI Content Index</a></li>
						<li><a href="../info.php">Stockholder Information</a></li>
						<li><a target="_blank" href="https://www.thecloroxcompany.com/">The Clorox Company</a></li>
					</ul>
				</div>
			</div>

			<div class="downloads">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../Clorox_2018_Integrated_Report.pdf?v10-11-2018" target="_blank">Full PDF</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_English.pdf" target="_blank">Executive Summary English</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_Spanish.pdf" target="_blank">Executive Summary Spanish</a></li>
					</ul>
				</div>
			</div>
        </div>
	</div>

	<nav class="mainNav">
		<div class="mainNav__box mainNav__box--1">
			<a class="mainNav__mainLink" href="../ceo-letter/">CEO Letter</a>

			<img src="../_images/global/nav1.png" class="mainNav__product mainNav__product--1">
		</div>

		<div class="mainNav__box mainNav__box--2">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../strategy/">2020 Strategy</a>

				<ul class="secondaryNav">
					<li><a href="../strategy/people.php">Engage our People</a></li>
					<li><a href="../strategy/value.php">Drive Superior Consumer Value</a></li>
					<li><a href="../strategy/portfolio.php">Accelerate Portfolio Momentum</a></li>
					<li><a href="../strategy/growth.php">Fund Growth</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav2.png" class="mainNav__product mainNav__product--2">
		</div>

		<div class="mainNav__box mainNav__box--3">
			<a class="mainNav__mainLink" href="../innovation/">Innovation</a>

			<img src="../_images/global/nav3.png" class="mainNav__product mainNav__product--3">
		</div>

		<div class="mainNav__box mainNav__box--4">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../scorecard/">Scorecard</a>

				<ul class="secondaryNav">
					<li><a href="../scorecard/footprint.php">Global Footprint</a></li>
					<li><a href="../scorecard/performance.php">Performance</a></li>
					<li><a href="../scorecard/product.php">Product</a></li>
					<li><a href="../scorecard/people.php">People</a></li>
					<li><a href="../scorecard/community.php">Community</a></li>
					<li><a href="../scorecard/planet.php">Planet</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav4.png" class="mainNav__product mainNav__product--4">
		</div>

		<div class="mainNav__box mainNav__box--5">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../recognitions/">Recognitions</a>

				<ul class="secondaryNav">
					<li><a href="../recognitions/">Company Recognitions</a></li>
					<li><a href="../recognitions/brand.php">Brand Recognitions</a></li>
				</ul>
			</div>
			<img src="../_images/global/nav5.png" class="mainNav__product mainNav__product--5">
		</div>

		<div class="mainNav__box mainNav__box--6">
			<a class="mainNav__mainLink" href="../financials/">Financials</a>

			<img src="../_images/global/nav6.png" class="mainNav__product mainNav__product--6">
		</div>

		<div class="mainNav__box mainNav__box--7">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../governance/">Governance</a>

				<ul class="secondaryNav">
					<li><a href="../governance/board.php">Board of Directors</a></li>
					<li><a href="../governance/committee.php">Executive Committee</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav7.png" class="mainNav__product mainNav__product--7">
		</div>

		<div class="mainNav__box mainNav__box--mobile">
			<ul>
				<li class="facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li class="twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li class="linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
			</ul>
		</div>
	</nav>
</header>
<div class="interiorWrapper interiorWrapper--scorecard">
	<div class="container">
		<div class="row">
			<h1 class="scorecardHeading">2018 Scorecard</h1>
		</div>

		<div class="row">
			<div class="scorecardLandingLeft">
				<div class="calloutNum calloutNum--lOrange">$6.1B</div>
				<div class="calloutTextLarge calloutText--orange">NET SALES</div>

				<div class="calloutNum calloutNum--lOrange margin-top-20">25+</div>
				<div class="calloutTextLarge calloutTextLarge--light calloutText--orange">Country/Territory<br> Operations</div>

				<div class="calloutNum calloutNum--lOrange margin-top-20">8,700+</div>
				<div class="calloutTextLarge calloutText--orange">EMPLOYEES</div>

				<div class="calloutNum calloutNum--lOrange margin-top-20">100+</div>
				<div class="calloutTextLarge calloutTextLarge--light calloutText--orange">Markets Around<br> the World</div>
			</div>
			<div class="scorecardLandingRight">
				<h1 class="heading margin-bottom-40">sales by segment<sup>1,2</sup></h1>

				<div class="row">
					<div class="scorecardLandingChart scorecardLandingChart--1">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 249.4 249.4" enable-background="new 0 0 249.4 249.4" xml:space="preserve" class="scorecardLandingChart__chart scorecardLandingChart__chart--1">
<g id="Layer_1">
	<g>
		<g>
			<g>
				<g>
					<path fill="#E6E7E8" d="M124.7,124.7l105.7,66.1C194,249.2,117,266.9,58.6,230.4S-17.5,117,19,58.6C42.3,21.2,80.6,0,124.7,0
						V124.7z"/>
				</g>
			</g>
			<g>
				<g>
					<path fill="#005CB9" d="M124.7,124.7V0c68.9,0,124.7,55.8,124.7,124.7c0,24.8-5.8,45.1-18.9,66.1L124.7,124.7z"/>
				</g>
			</g>
		</g>
		<g>
			<g>
			</g>
			<g>
			</g>
		</g>
	</g>
	<circle fill="#FFFFFF" cx="125.4" cy="123.5" r="111.4"/>
	<g class="scorecardLandingChart__text">
		<path fill="#005CB9" d="M78.8,161.3c-0.1,2.2-0.7,3.9-1.9,5.1S74.1,168,72,168c-2.2,0-3.9-0.7-5.1-2.2c-1.2-1.5-1.8-3.5-1.8-6.2
			v-3.3c0-2.7,0.6-4.7,1.8-6.2s2.9-2.2,5.1-2.2c2.1,0,3.7,0.6,4.8,1.8c1.1,1.2,1.7,2.9,1.9,5.1h-4c0-1.4-0.2-2.3-0.6-2.8
			c-0.4-0.5-1.1-0.8-2.1-0.8c-1.1,0-1.8,0.4-2.2,1.1s-0.7,2-0.7,3.6v3.7c0,1.9,0.2,3.3,0.7,4c0.4,0.7,1.2,1.1,2.2,1.1
			c1,0,1.8-0.3,2.1-0.8c0.4-0.5,0.6-1.4,0.7-2.7H78.8z"/>
		<path fill="#005CB9" d="M86.1,164.5h6.9v3.3H82.2v-19.5h3.9V164.5z"/>
		<path fill="#005CB9" d="M106.4,159.3h-6.1v5.2h7.3v3.3H96.3v-19.5h11.2v3.3h-7.2v4.6h6.1V159.3z"/>
		<path fill="#005CB9" d="M120,163.8h-5.4l-1,4h-4.2l6.1-19.5h3.6l6.1,19.5h-4.2L120,163.8z M115.5,160.5h3.6l-1.8-7L115.5,160.5z"
			/>
		<path fill="#005CB9" d="M141.7,167.8h-3.9L132,155v12.8H128v-19.5h3.9l5.8,12.8v-12.8h3.9V167.8z"/>
		<path fill="#005CB9" d="M149.9,167.8H146v-19.5h3.9V167.8z"/>
		<path fill="#005CB9" d="M167.8,167.8h-3.9l-5.8-12.8v12.8h-3.9v-19.5h3.9l5.8,12.8v-12.8h3.9V167.8z"/>
		<path fill="#005CB9" d="M185.2,165.5c-0.8,0.8-1.7,1.4-2.8,1.9s-2.3,0.6-3.6,0.6c-2.2,0-4-0.7-5.2-2.1c-1.2-1.4-1.9-3.4-1.9-6.1
			v-3.5c0-2.7,0.6-4.8,1.8-6.2s2.9-2.2,5.1-2.2c2.1,0,3.7,0.5,4.8,1.6c1.1,1,1.7,2.7,1.9,4.9h-3.8c-0.1-1.2-0.4-2.1-0.8-2.5
			s-1.1-0.7-1.9-0.7c-1.1,0-1.8,0.4-2.3,1.2c-0.5,0.8-0.7,2-0.8,3.7v3.5c0,1.8,0.3,3.1,0.8,3.9c0.5,0.8,1.4,1.2,2.6,1.2
			c0.8,0,1.4-0.2,1.9-0.5l0.3-0.2v-3.6h-2.8v-3h6.7V165.5z"/>
		<path fill="#005CB9" d="M72.3,102h4.5c3.4,0,6.1-1.1,8.2-3.2c2.1-2.1,3.1-5,3.1-8.5c0-3.9-0.9-6.9-2.7-9.1
			c-1.8-2.1-4.4-3.2-7.7-3.2c-3.2,0-5.8,1.1-7.8,3.4c-2,2.3-3,5.3-3,9h-4.6c0-3.2,0.6-6,1.9-8.5c1.3-2.5,3.1-4.5,5.5-6
			s5-2.2,7.9-2.2c4.5,0,8.2,1.5,10.9,4.4c2.7,3,4.1,7.1,4.1,12.4c0,3-0.8,5.7-2.3,8.2c-1.6,2.4-3.7,4.2-6.3,5.4c3,1,5.4,2.8,7.1,5.3
			c1.7,2.5,2.5,5.6,2.5,9.3c0,5.3-1.4,9.5-4.3,12.6c-2.9,3.1-6.7,4.7-11.4,4.7c-3,0-5.8-0.7-8.3-2.1c-2.5-1.4-4.5-3.4-5.8-6
			c-1.4-2.6-2.1-5.6-2.1-9.1h4.6c0,3.8,1.1,6.8,3.2,9.3c2.1,2.4,4.9,3.6,8.4,3.6c3.5,0,6.3-1.1,8.2-3.3c2-2.2,2.9-5.4,2.9-9.5
			c0-4-1-7-3.1-9.2c-2.1-2.1-5.1-3.2-9.2-3.2h-4.5V102z"/>
		<path fill="#005CB9" d="M130.3,115.5h7.8v4.3h-7.8v15.2h-4.6v-15.2h-23.8v-3l23.4-42.4h5V115.5z M107.5,115.5h18.3v-34l-1.7,3.4
			L107.5,115.5z"/>
		<path fill="#005CB9" d="M144.9,86.2c0-3.6,0.9-6.6,2.8-8.9c1.9-2.4,4.3-3.6,7.2-3.6c2.9,0,5.3,1.2,7.2,3.6
			c1.9,2.4,2.8,5.4,2.8,9.2v3c0,3.5-0.9,6.5-2.8,8.9c-1.9,2.4-4.3,3.6-7.2,3.6c-2.9,0-5.3-1.2-7.2-3.5c-1.9-2.3-2.9-5.4-2.9-9.2
			V86.2z M148.6,89.4c0,2.5,0.6,4.6,1.7,6.3c1.2,1.7,2.7,2.5,4.7,2.5c1.9,0,3.5-0.8,4.6-2.5s1.7-3.8,1.7-6.5v-3
			c0-2.5-0.6-4.6-1.7-6.3c-1.2-1.7-2.7-2.5-4.7-2.5c-1.9,0-3.5,0.8-4.6,2.5c-1.2,1.7-1.7,3.8-1.7,6.4V89.4z M156.3,130.1l-2.8-2
			l24.8-47.3l2.8,2L156.3,130.1z M170.3,120.2c0-3.6,0.9-6.5,2.8-8.9c1.9-2.4,4.3-3.6,7.2-3.6c2.9,0,5.3,1.2,7.2,3.5
			c1.9,2.3,2.9,5.4,2.9,9.3v3c0,3.6-1,6.6-2.9,9c-1.9,2.3-4.3,3.5-7.2,3.5c-2.9,0-5.3-1.2-7.2-3.5c-1.9-2.3-2.9-5.4-2.9-9.2V120.2z
			 M174,123.5c0,2.5,0.6,4.6,1.7,6.3c1.2,1.7,2.7,2.5,4.7,2.5c1.9,0,3.5-0.8,4.6-2.5c1.1-1.7,1.7-3.8,1.7-6.5v-3
			c0-2.6-0.6-4.7-1.7-6.3c-1.2-1.6-2.7-2.4-4.7-2.4c-1.9,0-3.5,0.8-4.6,2.4s-1.7,3.8-1.7,6.6V123.5z"/>
	</g>
</g>
<g id="mask">
	<circle class="mask" fill="none" stroke="#FFFFFF" stroke-width="40" stroke-miterlimit="10" cx="124.7" cy="122.7" r="107.5"/>
</g>
</svg>
						<div class="scorecardLandingBox scorecardLandingBox--1">
							<div class="left"></div>
							<div class="top"></div>
							<div class="right"></div>
							<div class="bot"></div>
							<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 47.602 20.362" enable-background="new 0 0 47.602 20.362" xml:space="preserve" class="chartLine">
	<polyline fill="none" stroke="#005CB9" stroke-width="1" points="0.098,20.285 15.944,0.125 47.602,0.125 "/>
</svg>
							<div class="scorecardLandingBox__title scorecardLandingBox__title--1">19% HOME CARE</div>
							<span class="scorecardLandingBox__products">(Clorox  |  Pine-Sol  |  Tilex  |  Formula 409  |  Liquid-Plumr)</span>

							<div class="scorecardLandingBox__title scorecardLandingBox__title--1">9% LAUNDRY</div>
							<span class="scorecardLandingBox__products">(Clorox | Clorox 2)</span>

							<div class="scorecardLandingBox__title scorecardLandingBox__title--1">6% PROFESSIONAL PRODUCTS</div>
							<span class="scorecardLandingBox__products">(Clorox Healthcare | Clorox Commercial Solutions)</span>
							
						</div>
					</div>

					<div class="scorecardLandingChart scorecardLandingChart--2">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 249.4 249.4" enable-background="new 0 0 249.4 249.4" xml:space="preserve" class="scorecardLandingChart__chart scorecardLandingChart__chart--2">
<g id="Layer_1">
	<g>
		<g>
			<g>
				<g>
					<path fill="#E6E7E8" d="M125,125L234,64.5c33.4,60.2,11.6,136.1-48.6,169.5S49.3,245.7,15.9,185.4S4.3,49.3,64.5,15.9
						C83.8,5.3,102.9,0.3,125,0.3V125z"/>
				</g>
			</g>
			<g>
				<g>
					<path fill="#005CB9" d="M125,125V0.3c46.8,0,86.4,23.3,109.1,64.2L125,125z"/>
				</g>
			</g>
		</g>
		<g>
			<g>
			</g>
			<g>
			</g>
		</g>
	</g>
	<circle fill="#FFFFFF" cx="125.1" cy="124.8" r="111.4"/>
	<g class="scorecardLandingChart__text">
		<path fill="#005CB9" d="M69.5,164.5h6.9v3.3H65.6v-19.5h3.9V164.5z"/>
		<path fill="#005CB9" d="M83.8,167.8h-3.9v-19.5h3.9V167.8z"/>
		<path fill="#005CB9" d="M98.1,159.8H92v8h-3.9v-19.5h10.8v3.3H92v5h6.1V159.8z"/>
		<path fill="#005CB9" d="M112.2,159.3H106v5.2h7.3v3.3h-11.2v-19.5h11.2v3.3H106v4.6h6.1V159.3z"/>
		<path fill="#005CB9" d="M124.8,162.6c0-0.8-0.2-1.4-0.6-1.8c-0.4-0.4-1.1-0.8-2.2-1.3c-2-0.7-3.4-1.6-4.2-2.6
			c-0.9-1-1.3-2.2-1.3-3.5c0-1.6,0.6-3,1.7-4c1.2-1,2.6-1.5,4.4-1.5c1.2,0,2.3,0.3,3.2,0.8c0.9,0.5,1.7,1.2,2.2,2.1
			c0.5,0.9,0.8,2,0.8,3.1h-3.9c0-0.9-0.2-1.6-0.6-2.1s-1-0.7-1.7-0.7c-0.7,0-1.2,0.2-1.6,0.6c-0.4,0.4-0.6,1-0.6,1.6
			c0,0.5,0.2,1,0.6,1.5s1.2,0.9,2.3,1.3c1.9,0.7,3.3,1.5,4.2,2.5c0.9,1,1.3,2.3,1.3,3.8c0,1.7-0.5,3-1.6,4c-1.1,1-2.6,1.4-4.4,1.4
			c-1.3,0-2.4-0.3-3.4-0.8s-1.8-1.3-2.4-2.2c-0.6-1-0.9-2.1-0.9-3.4h4c0,1.1,0.2,1.9,0.7,2.5c0.4,0.5,1.2,0.8,2.1,0.8
			C124.1,164.8,124.8,164.1,124.8,162.6z"/>
		<path fill="#005CB9" d="M145,151.5h-4.8v16.2h-4v-16.2h-4.7v-3.3H145V151.5z"/>
		<path fill="#005CB9" d="M154.1,157l2.9-8.8h4.3l-5.2,12.4v7.1h-4v-7.1l-5.2-12.4h4.3L154.1,157z"/>
		<path fill="#005CB9" d="M168,164.5h6.9v3.3H164v-19.5h3.9V164.5z"/>
		<path fill="#005CB9" d="M188.2,159.3h-6.1v5.2h7.3v3.3h-11.2v-19.5h11.2v3.3h-7.2v4.6h6.1V159.3z"/>

		<path fill="#005CB9" d="M82.8,135.1h-4.7V80.6l-13.7,6.1V82L82,74.3h0.8V135.1z"/>
		<path fill="#005CB9" d="M136,77.4l-21.6,57.6h-4.8l21.5-56.2h-28.7v-4.3H136V77.4z"/>
		<path fill="#005CB9" d="M144.9,86.2c0-3.6,0.9-6.6,2.8-8.9c1.9-2.4,4.3-3.6,7.2-3.6c2.9,0,5.3,1.2,7.2,3.6
			c1.9,2.4,2.8,5.4,2.8,9.2v3c0,3.5-0.9,6.5-2.8,8.9c-1.9,2.4-4.3,3.6-7.2,3.6c-2.9,0-5.3-1.2-7.2-3.5c-1.9-2.3-2.9-5.4-2.9-9.2
			V86.2z M148.6,89.4c0,2.5,0.6,4.6,1.7,6.3c1.2,1.7,2.7,2.5,4.7,2.5c1.9,0,3.5-0.8,4.6-2.5s1.7-3.8,1.7-6.5v-3
			c0-2.5-0.6-4.6-1.7-6.3c-1.2-1.7-2.7-2.5-4.7-2.5c-1.9,0-3.5,0.8-4.6,2.5c-1.2,1.7-1.7,3.8-1.7,6.4V89.4z M156.3,130.1l-2.8-2
			l24.8-47.3l2.8,2L156.3,130.1z M170.3,120.2c0-3.6,0.9-6.5,2.8-8.9c1.9-2.4,4.3-3.6,7.2-3.6c2.9,0,5.3,1.2,7.2,3.5
			c1.9,2.3,2.9,5.4,2.9,9.3v3c0,3.6-1,6.6-2.9,9c-1.9,2.3-4.3,3.5-7.2,3.5c-2.9,0-5.3-1.2-7.2-3.5c-1.9-2.3-2.9-5.4-2.9-9.2V120.2z
			 M174,123.5c0,2.5,0.6,4.6,1.7,6.3c1.2,1.7,2.7,2.5,4.7,2.5c1.9,0,3.5-0.8,4.6-2.5c1.1-1.7,1.7-3.8,1.7-6.5v-3
			c0-2.6-0.6-4.7-1.7-6.3c-1.2-1.6-2.7-2.4-4.7-2.4c-1.9,0-3.5,0.8-4.6,2.4s-1.7,3.8-1.7,6.6V123.5z"/>
	</g>
</g>
<g id="mask">
	<circle class="mask" fill="none" stroke="#FFFFFF" stroke-width="40" stroke-miterlimit="10" cx="124.7" cy="122.7" r="107.5"/>
</g>
</svg>
						<div class="scorecardLandingBox scorecardLandingBox--4">
							<div class="left"></div>
							<div class="top"></div>
							<div class="right"></div>
							<div class="bot"></div>
							<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 47.602 20.362" enable-background="new 0 0 47.602 20.362" xml:space="preserve" class="chartLine">
	<polyline fill="none" stroke="#005CB9" stroke-width="1" points="0.098,20.285 15.944,0.125 47.602,0.125 "/>
</svg>
							<div class="scorecardLandingBox__title scorecardLandingBox__title--4">9% FOOD PRODUCTS</div>
							<span class="scorecardLandingBox__products">(Hidden Valley | Soy Voy | KC Masterpiece)</span>

							<div class="scorecardLandingBox__title scorecardLandingBox__title--4">4% NATURAL PERSONAL CARE</div>
							<span class="scorecardLandingBox__products">(Burt’s Bees)</span>
							
							<div class="scorecardLandingBox__title scorecardLandingBox__title--4">3% WATER FILTRATION</div>
							<span class="scorecardLandingBox__products">(Brita)</span>

							<div class="scorecardLandingBox__title scorecardLandingBox__title--4">1% Dietary Supplements<sup>3</sup></div>
							<span class="scorecardLandingBox__products">(Rainbow Light  |  Natural Vitality  |  Neocell)</span>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="scorecardLandingChart scorecardLandingChart--3">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 249.4 249.4" enable-background="new 0 0 249.4 249.4" xml:space="preserve" class="scorecardLandingChart__chart scorecardLandingChart__chart--3">
<g id="Layer_1">
	<g>
		<g>
			<g>
				<g>
					<path fill="#E6E7E8" d="M125.5,125l110.1,58.5c-32.3,60.8-107.8,83.9-168.6,51.6S-16.9,127.3,15.4,66.5
						c22-41.3,63.3-66.2,110.1-66.2V125z"/>
				</g>
			</g>
			<g>
				<g>
					<path fill="#005CB9" d="M125.5,125V0.3c68.9,0,124.7,55.8,124.7,124.7c0,22-4.2,39.1-14.6,58.5L125.5,125z"/>
				</g>
			</g>
		</g>
		<g>
			<g>
			</g>
			<g>
			</g>
		</g>
	</g>
	<circle fill="#FFFFFF" cx="124.6" cy="125.8" r="111.4"/>
	<g class="scorecardLandingChart__text">
		<path fill="#005CB9" d="M69.3,167.8h-3.9v-8.4h-5.8v8.4h-3.9v-19.5h3.9v7.9h5.8v-7.9h3.9V167.8z"/>
		<path fill="#005CB9" d="M87.1,159.8c0,2.6-0.6,4.7-1.9,6.1c-1.2,1.4-3,2.2-5.2,2.2c-2.2,0-3.9-0.7-5.2-2.2c-1.3-1.4-1.9-3.4-1.9-6
			v-3.3c0-2.7,0.6-4.8,1.9-6.3c1.2-1.5,3-2.3,5.2-2.3c2.2,0,3.9,0.7,5.1,2.2c1.3,1.5,1.9,3.6,1.9,6.2V159.8z M83.2,156.5
			c0-1.8-0.3-3.1-0.8-3.9c-0.5-0.9-1.3-1.3-2.3-1.3c-1,0-1.8,0.4-2.3,1.2c-0.5,0.8-0.8,2.1-0.8,3.8v3.5c0,1.7,0.3,3,0.8,3.8
			c0.5,0.8,1.3,1.2,2.4,1.2c1,0,1.8-0.4,2.3-1.2c0.5-0.8,0.8-2,0.8-3.7V156.5z"/>
		<path fill="#005CB9" d="M103.6,148.2v13.5c0,2-0.6,3.6-1.7,4.7s-2.7,1.6-4.7,1.6c-2.1,0-3.7-0.5-4.8-1.6c-1.1-1.1-1.7-2.7-1.7-4.7
			v-13.4h4v13.4c0,1.1,0.2,1.9,0.5,2.4s1,0.7,1.9,0.7c0.9,0,1.6-0.2,1.9-0.7s0.5-1.2,0.5-2.3v-13.5H103.6z"/>
		<path fill="#005CB9" d="M115.8,162.6c0-0.8-0.2-1.4-0.6-1.8c-0.4-0.4-1.1-0.8-2.2-1.3c-2-0.7-3.4-1.6-4.2-2.6
			c-0.9-1-1.3-2.2-1.3-3.5c0-1.6,0.6-3,1.8-4c1.2-1,2.6-1.5,4.4-1.5c1.2,0,2.3,0.3,3.2,0.8c0.9,0.5,1.7,1.2,2.2,2.1s0.8,2,0.8,3.1
			h-3.9c0-0.9-0.2-1.6-0.6-2.1s-1-0.7-1.7-0.7c-0.7,0-1.2,0.2-1.6,0.6s-0.6,1-0.6,1.6c0,0.5,0.2,1,0.6,1.5c0.4,0.4,1.2,0.9,2.3,1.3
			c1.9,0.7,3.3,1.5,4.2,2.5c0.9,1,1.3,2.3,1.3,3.8c0,1.7-0.5,3-1.6,4c-1.1,1-2.6,1.4-4.4,1.4c-1.3,0-2.4-0.3-3.4-0.8
			s-1.8-1.3-2.4-2.2c-0.6-1-0.9-2.1-0.9-3.4h4c0,1.1,0.2,1.9,0.7,2.5c0.4,0.5,1.2,0.8,2.1,0.8C115.1,164.8,115.8,164.1,115.8,162.6z
			"/>
		<path fill="#005CB9" d="M133.4,159.3h-6.1v5.2h7.3v3.3h-11.2v-19.5h11.2v3.3h-7.2v4.6h6.1V159.3z"/>
		<path fill="#005CB9" d="M151.5,167.8h-3.9v-8.4h-5.8v8.4h-3.9v-19.5h3.9v7.9h5.8v-7.9h3.9V167.8z"/>
		<path fill="#005CB9" d="M169.4,159.8c0,2.6-0.6,4.7-1.9,6.1s-3,2.2-5.2,2.2c-2.2,0-3.9-0.7-5.2-2.2c-1.3-1.4-1.9-3.4-1.9-6v-3.3
			c0-2.7,0.6-4.8,1.9-6.3c1.2-1.5,3-2.3,5.2-2.3c2.2,0,3.9,0.7,5.1,2.2c1.3,1.5,1.9,3.6,1.9,6.2V159.8z M165.4,156.5
			c0-1.8-0.3-3.1-0.8-3.9c-0.5-0.9-1.3-1.3-2.3-1.3c-1,0-1.8,0.4-2.3,1.2c-0.5,0.8-0.8,2.1-0.8,3.8v3.5c0,1.7,0.3,3,0.8,3.8
			c0.5,0.8,1.3,1.2,2.4,1.2c1,0,1.8-0.4,2.3-1.2s0.8-2,0.8-3.7V156.5z"/>
		<path fill="#005CB9" d="M177.1,164.5h6.9v3.3h-10.9v-19.5h3.9V164.5z"/>
		<path fill="#005CB9" d="M187.3,167.8v-19.5h5.2c2.3,0,4.1,0.7,5.5,2.2s2,3.4,2.1,6v3.2c0,2.6-0.7,4.6-2,6s-3.2,2.2-5.6,2.2H187.3z
			 M191.2,151.5v13h1.2c1.3,0,2.2-0.3,2.8-1c0.5-0.7,0.8-1.9,0.8-3.6v-3.4c0-1.8-0.3-3.1-0.8-3.8s-1.4-1.1-2.6-1.1H191.2z"/>
			 		<path fill="#005CB9" d="M72.3,102h4.5c3.4,0,6.1-1.1,8.2-3.2c2.1-2.1,3.1-5,3.1-8.5c0-3.9-0.9-6.9-2.7-9.1
			c-1.8-2.1-4.4-3.2-7.7-3.2c-3.2,0-5.8,1.1-7.8,3.4c-2,2.3-3,5.3-3,9h-4.6c0-3.2,0.6-6,1.9-8.5c1.3-2.5,3.1-4.5,5.5-6
			s5-2.2,7.9-2.2c4.5,0,8.2,1.5,10.9,4.4c2.7,3,4.1,7.1,4.1,12.4c0,3-0.8,5.7-2.3,8.2c-1.6,2.4-3.7,4.2-6.3,5.4c3,1,5.4,2.8,7.1,5.3
			c1.7,2.5,2.5,5.6,2.5,9.3c0,5.3-1.4,9.5-4.3,12.6c-2.9,3.1-6.7,4.7-11.4,4.7c-3,0-5.8-0.7-8.3-2.1c-2.5-1.4-4.5-3.4-5.8-6
			c-1.4-2.6-2.1-5.6-2.1-9.1h4.6c0,3.8,1.1,6.8,3.2,9.3c2.1,2.4,4.9,3.6,8.4,3.6c3.5,0,6.3-1.1,8.2-3.3c2-2.2,2.9-5.4,2.9-9.5
			c0-4-1-7-3.1-9.2c-2.1-2.1-5.1-3.2-9.2-3.2h-4.5V102z"/>
		<path fill="#005CB9" d="M136.5,135.1h-32.1v-4l17.2-23.2c2.9-4,4.9-7.2,6-9.8c1.1-2.6,1.7-5.2,1.7-7.7c0-3.8-0.9-6.8-2.7-9
			c-1.8-2.2-4.3-3.3-7.5-3.3c-3.4,0-6.1,1.3-8.2,3.9c-2,2.6-3,6-3,10.1h-4.6c0-5.3,1.5-9.6,4.4-13.1c2.9-3.5,6.7-5.2,11.4-5.2
			c4.6,0,8.2,1.4,10.9,4.3c2.7,2.9,4,6.9,4,12c0,4.9-2.2,10.5-6.6,17l-2.7,3.8l-14.8,20h26.5V135.1z"/>
		<path fill="#005CB9" d="M144.9,86.2c0-3.6,0.9-6.6,2.8-8.9c1.9-2.4,4.3-3.6,7.2-3.6c2.9,0,5.3,1.2,7.2,3.6
			c1.9,2.4,2.8,5.4,2.8,9.2v3c0,3.5-0.9,6.5-2.8,8.9c-1.9,2.4-4.3,3.6-7.2,3.6c-2.9,0-5.3-1.2-7.2-3.5c-1.9-2.3-2.9-5.4-2.9-9.2
			V86.2z M148.6,89.4c0,2.5,0.6,4.6,1.7,6.3c1.2,1.7,2.7,2.5,4.7,2.5c1.9,0,3.5-0.8,4.6-2.5s1.7-3.8,1.7-6.5v-3
			c0-2.5-0.6-4.6-1.7-6.3c-1.2-1.7-2.7-2.5-4.7-2.5c-1.9,0-3.5,0.8-4.6,2.5c-1.2,1.7-1.7,3.8-1.7,6.4V89.4z M156.3,130.1l-2.8-2
			l24.8-47.3l2.8,2L156.3,130.1z M170.3,120.2c0-3.6,0.9-6.5,2.8-8.9c1.9-2.4,4.3-3.6,7.2-3.6c2.9,0,5.3,1.2,7.2,3.5
			c1.9,2.3,2.9,5.4,2.9,9.3v3c0,3.6-1,6.6-2.9,9c-1.9,2.3-4.3,3.5-7.2,3.5c-2.9,0-5.3-1.2-7.2-3.5c-1.9-2.3-2.9-5.4-2.9-9.2V120.2z
			 M174,123.5c0,2.5,0.6,4.6,1.7,6.3c1.2,1.7,2.7,2.5,4.7,2.5c1.9,0,3.5-0.8,4.6-2.5c1.1-1.7,1.7-3.8,1.7-6.5v-3
			c0-2.6-0.6-4.7-1.7-6.3c-1.2-1.6-2.7-2.4-4.7-2.4c-1.9,0-3.5,0.8-4.6,2.4s-1.7,3.8-1.7,6.6V123.5z"/>
	</g>
	<g>

	</g>
</g>
<g id="mask">
	<circle class="mask" fill="none" stroke="#FFFFFF" stroke-width="40" stroke-miterlimit="10" cx="124.7" cy="122.7" r="107.5"/>
</g>
</svg>
						<div class="scorecardLandingBox scorecardLandingBox--3">
							<div class="left"></div>
							<div class="top"></div>
							<div class="right"></div>
							<div class="bot"></div>
							<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 47.602 20.362" enable-background="new 0 0 47.602 20.362" xml:space="preserve" class="chartLine">
	<polyline fill="none" stroke="#005CB9" stroke-width="1" points="0.098,20.285 15.944,0.125 47.602,0.125 "/>
</svg>
							<div class="scorecardLandingBox__title scorecardLandingBox__title--3">14% BAGS, WRAPS, CONTAINERS</div>
							<span class="scorecardLandingBox__products">(Glad)</span>

							<div class="scorecardLandingBox__title scorecardLandingBox__title--3">9% CHARCOAL</div>
							<span class="scorecardLandingBox__products">(Kingsford | Match Light)</span>

							<div class="scorecardLandingBox__title scorecardLandingBox__title--3">7% CAT LITTER</div>

							<span class="scorecardLandingBox__products">(Fresh Step | Scoop Away)</span>

							<div class="scorecardLandingBox__title scorecardLandingBox__title--3">2% Digestive Health</div>
							<span class="scorecardLandingBox__products">(RenewLife)</span>
						</div>
					</div>

					<div class="scorecardLandingChart scorecardLandingChart--4">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 249.4 249.4" enable-background="new 0 0 249.4 249.4" xml:space="preserve" class="scorecardLandingChart__chart scorecardLandingChart__chart--4">
<g id="Layer_1">
	<g>
		<g>
			<g>
				<g>
					<path fill="#E6E7E8" d="M125,125L234,64.5c33.4,60.2,11.6,136.1-48.6,169.5S49.3,245.7,15.9,185.4S4.3,49.3,64.5,15.9
						C83.8,5.3,102.9,0.3,125,0.3V125z"/>
				</g>
			</g>
			<g>
				<g>
					<path fill="#005CB9" d="M125,125V0.3c46.8,0,86.4,23.3,109.1,64.2L125,125z"/>
				</g>
			</g>
		</g>
		<g>
			<g>
			</g>
			<g>
			</g>
		</g>
	</g>
	<circle fill="#FFFFFF" cx="125.1" cy="124.8" r="111.4"/>
	<g class="scorecardLandingChart__text">
		<path fill="#005CB9" d="M33.7,167.8h-3.9v-19.5h3.9V167.8z"/>
		<path fill="#005CB9" d="M51.6,167.8h-3.9L41.9,155v12.8H38v-19.5h3.9l5.8,12.8v-12.8h3.9V167.8z"/>
		<path fill="#005CB9" d="M68.4,151.5h-4.8v16.2h-4v-16.2h-4.7v-3.3h13.5V151.5z"/>
		<path fill="#005CB9" d="M81.7,159.3h-6.1v5.2h7.3v3.3H71.6v-19.5h11.2v3.3h-7.2v4.6h6.1V159.3z"/>
		<path fill="#005CB9" d="M92,160.6h-2v7.1h-3.9v-19.5h6.3c2,0,3.5,0.5,4.6,1.5c1.1,1,1.6,2.5,1.6,4.4c0,2.6-0.9,4.4-2.8,5.4l3.4,8
			v0.2h-4.2L92,160.6z M90,157.3h2.2c0.8,0,1.4-0.3,1.8-0.8c0.4-0.5,0.6-1.2,0.6-2.1c0-2-0.8-2.9-2.3-2.9H90V157.3z"/>
		<path fill="#005CB9" d="M115.9,167.8h-3.9l-5.8-12.8v12.8h-3.9v-19.5h3.9l5.8,12.8v-12.8h3.9V167.8z"/>
		<path fill="#005CB9" d="M129.3,163.8h-5.4l-1,4h-4.2l6.1-19.5h3.6l6.1,19.5h-4.2L129.3,163.8z M124.8,160.5h3.6l-1.8-7
			L124.8,160.5z"/>
		<path fill="#005CB9" d="M150,151.5h-4.8v16.2h-4v-16.2h-4.7v-3.3H150V151.5z"/>
		<path fill="#005CB9" d="M157.3,167.8h-3.9v-19.5h3.9V167.8z"/>
		<path fill="#005CB9" d="M175.4,159.8c0,2.6-0.6,4.7-1.9,6.1s-3,2.2-5.2,2.2c-2.2,0-3.9-0.7-5.2-2.2c-1.3-1.4-1.9-3.4-1.9-6v-3.3
			c0-2.7,0.6-4.8,1.9-6.3c1.2-1.5,3-2.3,5.2-2.3c2.2,0,3.9,0.7,5.1,2.2c1.3,1.5,1.9,3.6,1.9,6.2V159.8z M171.4,156.5
			c0-1.8-0.3-3.1-0.8-3.9c-0.5-0.9-1.3-1.3-2.3-1.3c-1,0-1.8,0.4-2.3,1.2c-0.5,0.8-0.8,2.1-0.8,3.8v3.5c0,1.7,0.3,3,0.8,3.8
			c0.5,0.8,1.3,1.2,2.4,1.2c1,0,1.8-0.4,2.3-1.2s0.8-2,0.8-3.7V156.5z"/>
		<path fill="#005CB9" d="M192.8,167.8h-3.9l-5.8-12.8v12.8h-3.9v-19.5h3.9l5.8,12.8v-12.8h3.9V167.8z"/>
		<path fill="#005CB9" d="M206.3,163.8h-5.4l-1,4h-4.2l6.1-19.5h3.6l6.1,19.5h-4.2L206.3,163.8z M201.7,160.5h3.6l-1.8-7
			L201.7,160.5z"/>
		<path fill="#005CB9" d="M218.2,164.5h6.9v3.3h-10.9v-19.5h3.9V164.5z"/>

		<path fill="#005CB9" d="M82.8,135.1h-4.7V80.6l-13.7,6.1V82L82,74.3h0.8V135.1z"/>
		<path fill="#005CB9" d="M136,77.4l-21.6,57.6h-4.8l21.5-56.2h-28.7v-4.3H136V77.4z"/>
		<path fill="#005CB9" d="M144.9,86.2c0-3.6,0.9-6.6,2.8-8.9c1.9-2.4,4.3-3.6,7.2-3.6c2.9,0,5.3,1.2,7.2,3.6
			c1.9,2.4,2.8,5.4,2.8,9.2v3c0,3.5-0.9,6.5-2.8,8.9c-1.9,2.4-4.3,3.6-7.2,3.6c-2.9,0-5.3-1.2-7.2-3.5c-1.9-2.3-2.9-5.4-2.9-9.2
			V86.2z M148.6,89.4c0,2.5,0.6,4.6,1.7,6.3c1.2,1.7,2.7,2.5,4.7,2.5c1.9,0,3.5-0.8,4.6-2.5s1.7-3.8,1.7-6.5v-3
			c0-2.5-0.6-4.6-1.7-6.3c-1.2-1.7-2.7-2.5-4.7-2.5c-1.9,0-3.5,0.8-4.6,2.5c-1.2,1.7-1.7,3.8-1.7,6.4V89.4z M156.3,130.1l-2.8-2
			l24.8-47.3l2.8,2L156.3,130.1z M170.3,120.2c0-3.6,0.9-6.5,2.8-8.9c1.9-2.4,4.3-3.6,7.2-3.6c2.9,0,5.3,1.2,7.2,3.5
			c1.9,2.3,2.9,5.4,2.9,9.3v3c0,3.6-1,6.6-2.9,9c-1.9,2.3-4.3,3.5-7.2,3.5c-2.9,0-5.3-1.2-7.2-3.5c-1.9-2.3-2.9-5.4-2.9-9.2V120.2z
			 M174,123.5c0,2.5,0.6,4.6,1.7,6.3c1.2,1.7,2.7,2.5,4.7,2.5c1.9,0,3.5-0.8,4.6-2.5c1.1-1.7,1.7-3.8,1.7-6.5v-3
			c0-2.6-0.6-4.7-1.7-6.3c-1.2-1.6-2.7-2.4-4.7-2.4c-1.9,0-3.5,0.8-4.6,2.4s-1.7,3.8-1.7,6.6V123.5z"/>
	</g>
</g>
<g id="mask">
	<circle class="mask" fill="none" stroke="#FFFFFF" stroke-width="40" stroke-miterlimit="10" cx="124.7" cy="122.7" r="107.5"/>
</g>
</svg>
						<div class="scorecardLandingBox scorecardLandingBox--2">
							<div class="left"></div>
							<div class="top"></div>
							<div class="right"></div>
							<div class="bot"></div>
							<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 47.602 20.362" enable-background="new 0 0 47.602 20.362" xml:space="preserve" class="chartLine">
	<polyline fill="none" stroke="#005CB9" stroke-width="1" points="0.098,20.285 15.944,0.125 47.602,0.125 "/>
</svg>
							<div class="scorecardLandingBox__title scorecardLandingBox__title--2">8% LATIN AMERICA</div>
							<div class="scorecardLandingBox__title scorecardLandingBox__title--2">4% CANADA</div>
							<div class="scorecardLandingBox__title scorecardLandingBox__title--2">3% REST OF WORLD</div>
							<div class="scorecardLandingBox__title scorecardLandingBox__title--2">2% AUSTRALIA/NEW ZEALAND</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
		<p class="footnote floatRight margin-top-80 scorecardNote">1 All brands are registered trademarks of The Clorox Company.<br> 2 All percentages represent rounded numbers.<br> 3 Reflects results following April 2018 Nutranext acquisition. This family of brands is expected to contribute approximately 3 points of sales in FY19.</p>
		</div>
	</div>

	<a href="planet.php"><img src="../_images/scorecard/global/left.svg" class="scorecardLeft"></a>
	<a href="footprint.php"><img src="../_images/scorecard/global/right.svg" class="scorecardRight"></a>
</div>
<div class="landingFooter"><div class="subnav subnav--scorecard">
	<div class="container">
		<div class="row">
			<ul class="subNav__items">
				<li><a href="index.php">2018<br> Scorecard</a></li>
				<li><a href="footprint.php">global<br> footprint</a></li>
				<li class="single"><a href="performance.php">performance</a></li>
				<li class="single"><a href="product.php">product</a></li>
				<li class="single"><a href="people.php">people</a></li>
				<li class="single"><a href="community.php">community</a></li>
				<li class="single"><a href="planet.php">planet</a></li>
			</ul>
		</div>
	</div>
</div></div>

<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="../_js/jquery.fancybox.min.js"></script>
<script src="../_js/jquery.mousewheel.js"></script>
<script src="../_js/greensock/TimelineMax.min.js"></script>
<script src="../_js/greensock/TweenMax.min.js"></script>
<script src="../_js/ScrollMagic.js"></script>
<script src="../_js/plugins/jquery.ScrollMagic.js"></script>
<script src="../_js/plugins/debug.addIndicators.js"></script>
<script src="../_js/greensock/plugins/DrawSVGPlugin.min.js"></script>
<script src="../_js/plugins/animation.gsap.js"></script>
<script src="../_js/jquery.cycle2.min.js"></script>
<script src="../_js/main.js?v.2018.2"></script><script src="../_js/scorecard.js"></script>
<script>scorecard_landing();</script>
<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"90a95d8474","applicationID":"2526212","transactionName":"MgRaYxZVDBIDW0BbWQtObUUNGxECDUpRUVcXBRdeClAHGUxIXEI=","queueTime":0,"applicationTime":1,"atts":"HkNZFV5PHxw=","errorBeacon":"bam.nr-data.net","agent":""}</script></body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=Edge"/>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="../_images/global/shareImage.png?v.2018.1" />

<title>Clorox 2018 Integrated Annual Report</title>
<link rel="stylesheet" href="../_css/main.css?v.2018.4">
<link rel="stylesheet" href="../_js/jquery.fancybox.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	    <script src="//assets.adobedtm.com/cfd7100a02cbfa40b2c485d333da22f89ccabd9c/satelliteLib-e1a96af74edf26406b64b1c5cb0abedb7b5a6c6c.js"></script>
	</head>
<body class="scorecardInterior">
<header>
	<div class="header__hamburger">
		<span>MENU</span>
		<div class="header__hamburger__bars">
			<div></div>
		</div>
	</div>

	<a class="logoWrap" href="../index.php">
		<img class="header__logo" src="../_images/global/logo.svg">
	</a>
    <div class="container container--header">
        <div class="row">
			<div class="header__links">
				<span class="ir">2018 Integrated Annual Report</span>
				<ul>
					<li><a class="header__links__resources" href="#">Resources</a></li>
					<li><a class="header__links__download" href="#">Download</a></li>
					<li><a class="header__links__search" href="#"><i class="fas fa-search"></i></a></li>
					<li class="socialLink facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="socialLink twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
					<li class="socialLink linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="socialLink"><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
				</ul>
			</div>

			<div class="headerSearch">
				<div class="headerSearch__relativeWrapper">
					<form action="../search.php">
						<input class="headerSearch__input" type="text" class="search" name="q" id="tipue_search_input" autocomplete="off" placeholder="Search" required="">
						<span class="headerSearch__del">X</span>
					</form>
				</div>
			</div>

			<div class="headerResources">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../about.php">About This Report</a></li>
						<li><a href="../materiality.php">Materiality Overview</a></li>
						<li><a href="../gri.php">GRI Content Index</a></li>
						<li><a href="../info.php">Stockholder Information</a></li>
						<li><a target="_blank" href="https://www.thecloroxcompany.com/">The Clorox Company</a></li>
					</ul>
				</div>
			</div>

			<div class="downloads">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../Clorox_2018_Integrated_Report.pdf?v10-11-2018" target="_blank">Full PDF</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_English.pdf" target="_blank">Executive Summary English</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_Spanish.pdf" target="_blank">Executive Summary Spanish</a></li>
					</ul>
				</div>
			</div>
        </div>
	</div>

	<nav class="mainNav">
		<div class="mainNav__box mainNav__box--1">
			<a class="mainNav__mainLink" href="../ceo-letter/">CEO Letter</a>

			<img src="../_images/global/nav1.png" class="mainNav__product mainNav__product--1">
		</div>

		<div class="mainNav__box mainNav__box--2">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../strategy/">2020 Strategy</a>

				<ul class="secondaryNav">
					<li><a href="../strategy/people.php">Engage our People</a></li>
					<li><a href="../strategy/value.php">Drive Superior Consumer Value</a></li>
					<li><a href="../strategy/portfolio.php">Accelerate Portfolio Momentum</a></li>
					<li><a href="../strategy/growth.php">Fund Growth</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav2.png" class="mainNav__product mainNav__product--2">
		</div>

		<div class="mainNav__box mainNav__box--3">
			<a class="mainNav__mainLink" href="../innovation/">Innovation</a>

			<img src="../_images/global/nav3.png" class="mainNav__product mainNav__product--3">
		</div>

		<div class="mainNav__box mainNav__box--4">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../scorecard/">Scorecard</a>

				<ul class="secondaryNav">
					<li><a href="../scorecard/footprint.php">Global Footprint</a></li>
					<li><a href="../scorecard/performance.php">Performance</a></li>
					<li><a href="../scorecard/product.php">Product</a></li>
					<li><a href="../scorecard/people.php">People</a></li>
					<li><a href="../scorecard/community.php">Community</a></li>
					<li><a href="../scorecard/planet.php">Planet</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav4.png" class="mainNav__product mainNav__product--4">
		</div>

		<div class="mainNav__box mainNav__box--5">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../recognitions/">Recognitions</a>

				<ul class="secondaryNav">
					<li><a href="../recognitions/">Company Recognitions</a></li>
					<li><a href="../recognitions/brand.php">Brand Recognitions</a></li>
				</ul>
			</div>
			<img src="../_images/global/nav5.png" class="mainNav__product mainNav__product--5">
		</div>

		<div class="mainNav__box mainNav__box--6">
			<a class="mainNav__mainLink" href="../financials/">Financials</a>

			<img src="../_images/global/nav6.png" class="mainNav__product mainNav__product--6">
		</div>

		<div class="mainNav__box mainNav__box--7">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../governance/">Governance</a>

				<ul class="secondaryNav">
					<li><a href="../governance/board.php">Board of Directors</a></li>
					<li><a href="../governance/committee.php">Executive Committee</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav7.png" class="mainNav__product mainNav__product--7">
		</div>

		<div class="mainNav__box mainNav__box--mobile">
			<ul>
				<li class="facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li class="twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li class="linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
			</ul>
		</div>
	</nav>
</header>
<div class="interiorWrapper interiorWrapper--scorecard interiorWrapper--scorecard--secondary">
	<div class="container">
		<div class="row">
			<h1 class="scorecardHeading scorecardHeading--small">2018 Scorecard</h1>
        </div>
        
        <div class="row">
            <div class="scorecardWrap">
                <div class="scoreRow">
                    <div class="peopleScorecardLeft">
                        <h1 class="heading heading--performance">People</h1>
                        <p class="scorecardText">Promoting diversity, opportunity and respectful treatment for all people who touch our business.</p>

                        <div class="shelf shelf--people--1">
                            <div class="shelf__wrap">
								<div class="scorecardStat scorecardStat--people">
									<div class="scorecardStat__title scorecardStat__title--orange">BEST-IN-CLASS<br> EMPLOYEE ENGAGEMENT<sup>1</sup></div>
									<div class="scorecardStat__num scorecardStat__num--orange">88%</div>
									<div class="scorecardStat__text scorecardStat__text--orange">Employee Engagement <img src="../_images/scorecard/global/a.svg" class="aNote"><br><span class="small">(vs. 81% for Consumer Goods Companies, 86% for Global High-Performance Companies) </span></div>
								</div>
							</div>
                        </div>

                        <div class="shelf shelf--people--1">
                            <div class="shelf__wrap">
								<div class="scorecardStat scorecardStat--people">
									<div class="scorecardStat__title scorecardStat__title--orange">WORLD-CLASS<br> WORKPLACE SAFETY<sup>2</sup></div>
									<div class="scorecardStat__num scorecardStat__num--orange">0.82</div>
									<div class="scorecardStat__text scorecardStat__text--orange">Recordable Incident Rate <img src="../_images/scorecard/global/a.svg" class="aNote"><br><span class="small">(vs. World-Class Level &lt;1.0)<br></span></div>
								</div>
							</div>
                        </div>
                    </div>

                    <div class="peopleScorecardRight">
                        <div class="shelf shelf--people--2">
                            <div class="shelf__wrap">
								<h3 class="scorecardStat__title scorecardStat__title--orange margin-bottom-30">DIVERSITY AS A BUSINESS STRENGTH IN THE WORKFORCE</h3>

								<div class="scorecardStat scorecardStat--people">
									<div class="scorecardStat__title scorecardStat__title--orange margin-bottom-20">ETHNIC MINORITIES (U.S.)</div>
									<div class="scorecardStat__num scorecardStat__num--orange">28%</div>
									<div class="scorecardStat__text scorecardStat__text--orange">Nonproduction Managers <img src="../_images/scorecard/global/a.svg" class="aNote"><br><span class="small">(vs. 30% U.S. Census Bureau)<sup>3</sup> <img src="../_images/scorecard/global/a.svg" class="aNote"></span></div>

									<div class="scorecardStat__num scorecardStat__num--orange margin-top-10">32%</div>
									<div class="scorecardStat__text scorecardStat__text--orange">NONPRODUCTION EMPLOYEES <img src="../_images/scorecard/global/a.svg" class="aNote"><br><span class="small">(vs. 33% U.S. Census Bureau)<sup>3</sup> <img src="../_images/scorecard/global/a.svg" class="aNote"></span></div>
								</div>

								<div class="scorecardStat scorecardStat--people">
									<div class="scorecardStat__title scorecardStat__title--orange margin-bottom-20">WOMEN (GLOBAL)</div>
									<div class="scorecardStat__num scorecardStat__num--orange">43%</div>
									<div class="scorecardStat__text scorecardStat__text--orange">NONPRODUCTION MANAGERS <img src="../_images/scorecard/global/a.svg" class="aNote"><br>&nbsp;</div>

									<div class="scorecardStat__num scorecardStat__num--orange margin-top-10">51%</div>
									<div class="scorecardStat__text scorecardStat__text--orange">NONPRODUCTION EMPLOYEES <img src="../_images/scorecard/global/a.svg" class="aNote"><br>&nbsp;</div>
								</div>

								<img src="../_images/scorecard/people/image1.png" class="scorecardStat scorecardStat--image">
							</div>
                        </div>

                        <div class="shelf shelf--people--3">
							<div class="shelf__wrap">
								<h3 class="scorecardStat__title scorecardStat__title--left scorecardStat__title--orange margin-bottom-30">DIVERSITY AS A BUSINESS STRENGTH IN CORPORATE GOVERNANCE</h3>

								<div class="scorecardStat scorecardStat--people">
									<div class="scorecardStat__num scorecardStat__num--orange">33%</div>
									<span class="scorecardStat__text scorecardStat__text--orange">MINORITY BOARD MEMBERS <img src="../_images/scorecard/global/a.svg" class="aNote"><br><span class="small">(vs. 14% Fortune 500 Average)<sup>4</sup></span></span>
								</div>

								<div class="scorecardStat scorecardStat--people">
									<div class="scorecardStat__num scorecardStat__num--orange">33%</div>
									<span class="scorecardStat__text scorecardStat__text--orange">FEMALE BOARD MEMBERS <img src="../_images/scorecard/global/a.svg" class="aNote"><br><span class="small">(vs. 20% Fortune 500 Average)<sup>4</sup></span></span>
								</div>

								<div class="scorecardStat scorecardStat--people">
									<div class="scorecardStat__num scorecardStat__num--orange">33%</div>
									<span class="scorecardStat__text scorecardStat__text--orange">FEMALE CLOROX EXECUTIVE<br>COMMITTEE MEMBERS <img src="../_images/scorecard/global/a.svg" class="aNote"></span>
								</div>
							</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<div class="row">
			<div class="content footnoteLinkWrap">
				<a href="#footnotes" data-fancybox>View Footnotes</a>
			</div>
		</div>
	</div>

	<a href="product.php"><img src="../_images/scorecard/global/left.svg" class="scorecardLeft"></a>
    <a href="community.php"><img src="../_images/scorecard/global/right.svg" class="scorecardRight"></a>
</div>

<div id="footnotes" class="scorecard__footnotesWrap">
	<div class="container">
		<div class="row">
			<div class="footnotesWrapper">
			<ol class="footnotesList">
				<li>The FY18 engagement survey was open for three weeks, during which time 83 percent of eligible Clorox employees completed the survey (6,350 of 7,611). The Willis Towers Watson Global High-Performance Norm is based on responses from 409,521 employees (weighted N-size of 140,136) at 24 companies. Companies qualify for the norm by meeting two criteria: 1) superior financial performance, defined by a net profit margin and/or return on invested capital that exceeds industry averages; and 2) superior human resources practices, defined by employee opinion scores near the top among the most financially successful companies surveyed by Willis Towers Watson. The Willis Towers Watson Global Fast-Moving Consumer Goods Norm is comprised of employee survey results from a cross-section of organizations that produce fast-moving consumer goods, based on responses from 823,964 employees (weighted N-size of 146,652) at 68 companies.</li>
				<li>Based on corporate benchmarking by Clorox, we consider a recordable incident rate of 1.0 or less to be world-class. Our FY18 RIR of 0.82 means that for every 100 Clorox employees, we averaged less than one reportable incident during the past year. According to the latest available data from the U.S. Bureau of Labor Statistics, the average RIR for goods-producing manufacturing companies is 3.6. The criteria used to determine RIR follows the U.S. Department of Labor’s Occupational Safety and Health Administration guidelines and is applied globally.</li>
				<li>U.S. Census Bureau benchmark metrics are based on the U.S. Census Bureau’s Equal Employment Opportunity (EEO) Tabulation 2006-2010, American Community Survey 5-year dataset. The benchmarks are modeled using Clorox’s workforce as of June 30, 2018. The calculations utilize weighted averages by U.S. Census job code and apply approximate workforce location assumptions based on Clorox’s historical workforce locations and headcount trends.</li>
				<li>“Missing Pieces Report: The 2016 Board Diversity Census of Women and Minorities on Fortune 500 Boards,” Deloitte and the Alliance for Board Diversity, 2017.</li>
			</ol>
			</div>
		</div>
	</div>
</div>
<div class="subnav subnav--scorecard">
	<div class="container">
		<div class="row">
			<ul class="subNav__items">
				<li><a href="index.php">2018<br> Scorecard</a></li>
				<li><a href="footprint.php">global<br> footprint</a></li>
				<li class="single"><a href="performance.php">performance</a></li>
				<li class="single"><a href="product.php">product</a></li>
				<li class="single"><a href="people.php">people</a></li>
				<li class="single"><a href="community.php">community</a></li>
				<li class="single"><a href="planet.php">planet</a></li>
			</ul>
		</div>
	</div>
</div>
<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="../_js/jquery.fancybox.min.js"></script>
<script src="../_js/jquery.mousewheel.js"></script>
<script src="../_js/greensock/TimelineMax.min.js"></script>
<script src="../_js/greensock/TweenMax.min.js"></script>
<script src="../_js/ScrollMagic.js"></script>
<script src="../_js/plugins/jquery.ScrollMagic.js"></script>
<script src="../_js/plugins/debug.addIndicators.js"></script>
<script src="../_js/greensock/plugins/DrawSVGPlugin.min.js"></script>
<script src="../_js/plugins/animation.gsap.js"></script>
<script src="../_js/jquery.cycle2.min.js"></script>
<script src="../_js/main.js?v.2018.2"></script><script src="../_js/scorecard.js"></script>
<script>footprint();</script>
</body>
</html>
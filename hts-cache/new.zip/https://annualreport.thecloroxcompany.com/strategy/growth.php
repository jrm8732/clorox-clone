<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=Edge"/>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="../_images/global/shareImage.png?v.2018.1" />

<title>Clorox 2018 Integrated Annual Report</title>
<link rel="stylesheet" href="../_css/main.css?v.2018.4">
<link rel="stylesheet" href="../_js/jquery.fancybox.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	    <script src="//assets.adobedtm.com/cfd7100a02cbfa40b2c485d333da22f89ccabd9c/satelliteLib-e1a96af74edf26406b64b1c5cb0abedb7b5a6c6c.js"></script>
	</head>
<body class="strategyGrowth">
<header>
	<div class="header__hamburger">
		<span>MENU</span>
		<div class="header__hamburger__bars">
			<div></div>
		</div>
	</div>

	<a class="logoWrap" href="../index.php">
		<img class="header__logo" src="../_images/global/logo.svg">
	</a>
    <div class="container container--header">
        <div class="row">
			<div class="header__links">
				<span class="ir">2018 Integrated Annual Report</span>
				<ul>
					<li><a class="header__links__resources" href="#">Resources</a></li>
					<li><a class="header__links__download" href="#">Download</a></li>
					<li><a class="header__links__search" href="#"><i class="fas fa-search"></i></a></li>
					<li class="socialLink facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="socialLink twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
					<li class="socialLink linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="socialLink"><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
				</ul>
			</div>

			<div class="headerSearch">
				<div class="headerSearch__relativeWrapper">
					<form action="../search.php">
						<input class="headerSearch__input" type="text" class="search" name="q" id="tipue_search_input" autocomplete="off" placeholder="Search" required="">
						<span class="headerSearch__del">X</span>
					</form>
				</div>
			</div>

			<div class="headerResources">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../about.php">About This Report</a></li>
						<li><a href="../materiality.php">Materiality Overview</a></li>
						<li><a href="../gri.php">GRI Content Index</a></li>
						<li><a href="../info.php">Stockholder Information</a></li>
						<li><a target="_blank" href="https://www.thecloroxcompany.com/">The Clorox Company</a></li>
					</ul>
				</div>
			</div>

			<div class="downloads">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../Clorox_2018_Integrated_Report.pdf?v10-11-2018" target="_blank">Full PDF</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_English.pdf" target="_blank">Executive Summary English</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_Spanish.pdf" target="_blank">Executive Summary Spanish</a></li>
					</ul>
				</div>
			</div>
        </div>
	</div>

	<nav class="mainNav">
		<div class="mainNav__box mainNav__box--1">
			<a class="mainNav__mainLink" href="../ceo-letter/">CEO Letter</a>

			<img src="../_images/global/nav1.png" class="mainNav__product mainNav__product--1">
		</div>

		<div class="mainNav__box mainNav__box--2">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../strategy/">2020 Strategy</a>

				<ul class="secondaryNav">
					<li><a href="../strategy/people.php">Engage our People</a></li>
					<li><a href="../strategy/value.php">Drive Superior Consumer Value</a></li>
					<li><a href="../strategy/portfolio.php">Accelerate Portfolio Momentum</a></li>
					<li><a href="../strategy/growth.php">Fund Growth</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav2.png" class="mainNav__product mainNav__product--2">
		</div>

		<div class="mainNav__box mainNav__box--3">
			<a class="mainNav__mainLink" href="../innovation/">Innovation</a>

			<img src="../_images/global/nav3.png" class="mainNav__product mainNav__product--3">
		</div>

		<div class="mainNav__box mainNav__box--4">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../scorecard/">Scorecard</a>

				<ul class="secondaryNav">
					<li><a href="../scorecard/footprint.php">Global Footprint</a></li>
					<li><a href="../scorecard/performance.php">Performance</a></li>
					<li><a href="../scorecard/product.php">Product</a></li>
					<li><a href="../scorecard/people.php">People</a></li>
					<li><a href="../scorecard/community.php">Community</a></li>
					<li><a href="../scorecard/planet.php">Planet</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav4.png" class="mainNav__product mainNav__product--4">
		</div>

		<div class="mainNav__box mainNav__box--5">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../recognitions/">Recognitions</a>

				<ul class="secondaryNav">
					<li><a href="../recognitions/">Company Recognitions</a></li>
					<li><a href="../recognitions/brand.php">Brand Recognitions</a></li>
				</ul>
			</div>
			<img src="../_images/global/nav5.png" class="mainNav__product mainNav__product--5">
		</div>

		<div class="mainNav__box mainNav__box--6">
			<a class="mainNav__mainLink" href="../financials/">Financials</a>

			<img src="../_images/global/nav6.png" class="mainNav__product mainNav__product--6">
		</div>

		<div class="mainNav__box mainNav__box--7">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../governance/">Governance</a>

				<ul class="secondaryNav">
					<li><a href="../governance/board.php">Board of Directors</a></li>
					<li><a href="../governance/committee.php">Executive Committee</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav7.png" class="mainNav__product mainNav__product--7">
		</div>

		<div class="mainNav__box mainNav__box--mobile">
			<ul>
				<li class="facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li class="twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li class="linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
			</ul>
		</div>
	</nav>
</header>
<div class="interiorWrapper">
	<div class="container">
		<div class="row">
			<div class="sectionBoxWrap">
				<div class="sectionBox">
					<div class="sectionName">Strategy</div>
					<div class="sectionNumber">04</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="hero">
				<h1 class="pageTitle">Fund Growth</h1>
				<img src="../_images/strategy/growth/hero.jpg">

				<div class="hero__whiteBar"></div>
			</div>
		</div>

		<div class="row">
			<div class="content content--start fade fade--up">
				<h1 class="heading">Business Highlights</h1>
				<h2 class="sectionSubHeading">Fund growth by reducing waste in our work, products and supply chain.</h2>
				<ul class="list">
				<li>Through a more flexible and responsive manufacturing process, we’ve been able to increase the number of production orders processed by 33 percent over the last three years. The Kingsford brand, for example, increased production capacity by 16.7 percent without additional capital investment.</li>
				<li>We simplified the planning process for rail car deliveries at our Spring Hill, Kansas, litter plant, resulting in improved rail carrier service and protecting against disruptions.</li>
				<li>By focusing on consumer needs, efficiency and process improvements, we continue to reduce the amount of time required to bring new innovations to market, launching approximately 70 percent of new products in 14 months or less.</li>
				<li>Enterprisewide initiatives, including investment in a new manufacturing process for our Glad ForceFlex Plus trash bags, changing to a consumer-preferred substrate for our Clorox disinfecting wipes, and a number of other administrative improvements, contributed to $113 million in cost savings.</li>
				<li>A redesign of our process, systems and data is enabling us to export U.S. professional products and bring them to global markets faster.</li>
				<li>We eliminated nearly 10,000 hours of effort in our international marketing processes, freeing up employees’ time to focus on building the business and better serving our consumers.</li>
				<li>Our Bogota, Colombia, plant upgraded its line equipment to increase production capacity of thick bleach and laundry products, cutting production time and increasing efficiency and flexibility based on demand. </li>
			</div>
			
			<div class="growthStatWrap--1 fade fade--left">
				<div class="growthCallout--1">
					<div class="calloutText calloutText--small calloutText--lGreen">ELIMINATED</div>
					<div class="calloutNum calloutNum--green">10,000</div>
					<div class="calloutText calloutText--green"><strong>HOURS OF EFFORT <br>IN INTERNATIONAL <br>MARKETING <br>PROCESSES</strong></div>
				</div>
			</div>
		</div>
	</div>
	<div class="growthWaveWrap growthWaveWrap--1"><img src="../_images/strategy/growth/wave.png"></div>
	<div class="container">
		<div class="row">
			<div class="growthCopy growthCopy--small fade fade--right">
				<ul class="list">
					<li>We made significant investments in our Glad brand’s manufacturing process and equipment to reduce resin in Glad ForceFlex Plus trash bags, resulting in a new patent-protected product offering greater value to consumers.</li>
					<li>We developed a world-class distribution center in Peru, upgrading more than 160,000 square feet of our existing facility to eliminate costs of external rental and freight services, increasing storage space and improving product quality through reduced handling.</li>
				</ul>
			</div>
			<div class="growthImage growthImage--right fade fade--up">
				<p class="caption">An operator at our Atlanta plant prepares cases of our Clorox Commercial Solutions toilet bowl cleaner for distribution.</p>
				<img src="../_images/strategy/growth/image2.jpg" alt="">
			</div>
		</div>
		<div class="row">
			<div class="growthImage growthImage--left fade fade--up">
				<img src="../_images/strategy/growth/image1.jpg" alt="">
				<p class="caption">Our Mexico plant and distribution center became certified as new zero-waste-to-landfill sites.</p>

				<div class="growthCallout--2 fade fade--right">
					<div class="calloutNum calloutNum--lOrange">5</div>
					<div class="calloutText calloutText--orange"><strong>NEW SITES <br>ACHIEVED <br>ZERO-WASTE-TO-<br>LANDFILL STATUS</strong></div>
				</div>
			</div>
			<div class="growthCopy growthCopy--right fade fade--left">
				<h3 class="heading">Corporate Responsibility Highlights</h3>
				<h4 class="sectionSubHeading">Shrink our environmental footprint while we grow.</h4>
				<ul class="list">
					<li>Five additional sites achieved zero-waste-to-landfill status — our Tlalnepantla (Mexico City) manufacturing site; Tultipark, Mexico, distribution center; Amherst, Virginia, plant; Willowbrook, Illinois, R&D facility; and Rogers, Arkansas, distribution center — bringing the total number of sites that have achieved this milestone during the current goal period to eight, two shy of the 2020 goal of 10 sites.</li>
					<li>Our plants in Bogota, Colombia, and Quilicura, Chile, developed a solution to manage industrial wastewater that’s sustainable and reduces costs. Rather than pump water used to flush residual product in the pipes and tanks to an internal wastewater treatment plant, they now reuse some rinsing water and eliminate rinse cycles in certain production sequences. With less wastewater requiring treatment, we saved $2 million per facility and lowered disposal costs. The plants also cut annual water use by nearly 10 million gallons.</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="growthWaveWrap growthWaveWrap--2"><img src="../_images/strategy/growth/wave.png"></div>
	<div class="container">
		<div class="row">
			<div class="growthCopy growthCopy--left fade fade--right">
				<ul class="list">
					<li>After a rigorous audit verifying compliance and validating best practices in environmental risk mitigation, our Tlalnepantla, Mexico, plant received the clean industry certification, the highest environmental recognition offered by Mexico’s environmental authority (PROFEPA).</li>
					<li>Using best practices shared from other plants, our Kingsford plant in Belle, Missouri, removed a concrete retaining wall and worn-out pavement, grinding the debris for reuse as a pavement sub-base in a new concrete expansion in front of the plant’s warehouses. This kept the material out of landfills, conserved resources by reducing the need for gravel mining and reduced the energy that would have been required to transport new material.</li>
				</ul>
			</div>
			<div class="growthImage growthImage--large fade fade--up">
				<img src="../_images/strategy/growth/image3.jpg?v2" alt="">
				<p class="caption caption--noMarginMobile">We began supporting a land-use planning initiative in Indonesia, part of our commitment to responsible sourcing of palm oil.</p>
			</div>
		</div>
		<div class="row">
			<div class="growthCopy fade fade--up">
				<ul class="list">
					<li>As part of our ongoing commitment to responsible sourcing of palm oil, we have begun to identify opportunities to improve environmental and social sustainability across our supply chain, with benefits extending to the broader industry. Working with our implementation partner, The Forest Trust, we began supporting Priority Areas for Transformation, a program focused on land-use planning in Indonesia that helps members and other participating stakeholders work together to bring sustainable economic growth while protecting a critical ecosystem.</li>
					<li>We reached out to our top 100 suppliers — representing approximately two-thirds of our spending — to participate in an annual survey disclosing their environmental practices, including measuring and setting goals as well as reporting on greenhouse gas emissions, energy and water use, and solid-waste-to-landfill. This survey enables us to track their progress and is part of a broader effort to improve the sustainability of our upstream supply chain.</li>
					<li>More than 99 percent of paper-based packaging we purchase is now made from recycled or certified sustainable fiber. This was one of our 2020 goals for product and packaging sustainability.</li>
				</ul>
			</div>
		</div>
	</div>

	<div class="stratScreen"></div>

	<div class="progressContent progressContent--4">
		<div class="progressTab">
			<h3 class="progressTab__title">Our Progress</h3>
			<div class="arrow"></div>
		</div>

		<ul class="progressContent--4__nav">
			<li class="active" data-tab="1">Overview</li>
			<li data-tab="2">Energy Use</li>
			<li data-tab="3">GHG Emissions</li>
			<li data-tab="4">Waste to Landfill</li>
			<li data-tab="5">Water Use</li>
		</ul>

		<div class="progressContent--4__tab progressContent--4__tab--1  active">

			<h2 class="progressContent__heading">We’re on track to deliver our 2020 goals</h2>

			<div class="progressContent--4__callout progressContent--4__callout--1">
				<img class="progressContent--4__target" src="../_images/strategy/growth/icon1.svg" alt="">
				<h4>2020 Goal</h4>
				<p>Reduce the environmental <br>impact of our operations <br>and improve the <br>sustainability of our <br>upstream supply chain.</p>
			</div>

			<p>As the sixth year of our footprint reduction goal period comes to a close, we’ve already exceeded our 2020 goals to reduce solid-waste-to-landfill, water use and greenhouse gas emissions and remain on target to reach our 2020 goals to lower energy use. Our facilities are not energy-intensive or water-intensive, making ongoing progress challenging now that we have already reduced energy and water use by 25 percent and 35 percent, respectively, per case of product sold, since establishing our first sustainability strategy in 2008. We continue to seek innovative ways to reduce our overall operational footprint while mitigating the impact of unexpected external challenges that are limiting our ability to recycle certain plastics in areas that have been reliable outlets in the past.</p>

			<img class="progressContent--4__image progressContent--4__image--1" src="../_images/strategy/growth/progress1b.jpg" alt="">
		</div>
		<div class="progressContent--4__tab progressContent--4__tab--2">
			<div class="progressContent--4__callout progressContent--4__callout--2">
				<img class="progressContent--4__target" src="../_images/strategy/growth/icon1.svg" alt="">
				<h4>2020 Goal</h4>
				<p>
					Reduce energy use by <br>
					<span><img class="progressContent--4__arrow" src="../_images/strategy/growth/arrow.svg" alt="">20%</span> <br>
					per case of product sold <br>versus a 2011 calendar <br>
					year baseline.
				</p>
				<h4>Results to Date</h4>
				<img class="progressContent--4__arrow" src="../_images/strategy/growth/arrow.svg" alt=""><span>17%</span>
			</div>

			<h2 class="progressContent__heading">Energy on Track to deliver 2020 Goal</h2>
			<p>We continue to make progress to reduce our energy use during this goal period. Based on our current data, we’ve now cut our energy use by 17 percent and are on track to achieve our 20 percent reduction goal by 2020. Some of the recent reductions in energy use on an intensity basis are due to an increase in product volume and the resulting efficiencies of scale.</p>
			<p>At this point in our progress, we’ve identified and implemented potential efficiencies in some of our most energy-intensive processes. To meet our 2020 goal, we continue to focus on site-specific efficiency improvements — such as installing LED lighting — identified through our Energy Audit Action Plan created a few years ago.</p>
			<img class="progressContent--4__image progressContent--4__image--3 margin-neg-left-100" src="../_images/strategy/growth/progress2.jpg" alt="">
			<div class="progressContent--4__chart progressContent--4__chart--1">
				<h4>Energy Use <br><span>(annual progress versus 2011 base year):</span></h4>
				<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="415.78" height="112.22" viewBox="0 0 415.78 112.22" class="growthChart growthChart--1">
  <defs>
    <clipPath id="clip-path1">
      <rect x="331.1" y="74.92" width="22.21" height="28.87" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path1-2">
      <rect x="116.47" y="41.44" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path1-3">
      <rect x="170.81" y="73.77" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path1-4">
      <rect x="225.81" y="77.77" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path1-5">
      <rect x="62.14" y="58.44" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path1-6">
      <rect x="6.47" y="56.77" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path1-7">
      <rect x="278.36" y="85.44" width="11.54" height="15" style="fill: none"/>
    </clipPath>
  </defs>
  <title>chart1</title>
  	<rect class="bar" x="19.96" y="10.65" width="16.29" height="42.75" style="fill: #82c341"/>
	  <rect class="bar" x="74.53" y="10.65" width="16.29" height="44.04" style="fill: #82c341"/>
	  <rect class="bar" x="129.1" y="10.65" width="16.29" height="27.21" style="fill: #82c341"/>
	  <rect class="bar" x="183.67" y="10.65" width="16.29" height="59.57" style="fill: #82c341"/>
	<rect class="bar" x="238.24" y="10.65" width="16.29" height="64.11" style="fill: #82c341"/>
	<rect class="bar" x="292.81" y="10.65" width="16.29" height="72.96" style="fill: #005cb9"/>
	
  <g>
    <g>
      <path d="M355,104v-3.67l7.27-14.13A11.32,11.32,0,0,0,363.48,81c0-1.68-.9-2.54-2.08-2.54s-2.16.82-2.16,2.5v1.87h-4.33V81.16a6.07,6.07,0,0,1,1.8-4.82,6.9,6.9,0,0,1,4.69-1.72,6.31,6.31,0,0,1,4.49,1.56,6.52,6.52,0,0,1,1.92,5,14.7,14.7,0,0,1-1.59,6.37l-6.58,12.58h8.17V104Z" style="fill: #929497"/>
      <path d="M382.31,102.64a6.66,6.66,0,0,1-4.62,1.71,6.74,6.74,0,0,1-4.65-1.71,6.1,6.1,0,0,1-1.84-4.82V81.16A6.09,6.09,0,0,1,373,76.34a6.75,6.75,0,0,1,4.65-1.72,6.67,6.67,0,0,1,4.62,1.72,6.12,6.12,0,0,1,1.83,4.82V97.82A6.13,6.13,0,0,1,382.31,102.64ZM379.82,81c0-1.68-.94-2.5-2.13-2.5s-2.16.82-2.16,2.5V98c0,1.68,1,2.49,2.16,2.49s2.13-.81,2.13-2.49Z" style="fill: #929497"/>
      <path d="M393,89.86c-2.77,0-5.18-1.68-5.18-4.9V79.53c0-3.23,2.41-4.91,5.18-4.91s5.19,1.68,5.19,4.91V85C398.15,88.18,395.74,89.86,393,89.86Zm1.64-10.25c0-1.27-.66-1.84-1.64-1.84s-1.67.57-1.67,1.84v5.26c0,1.27.69,1.84,1.67,1.84s1.64-.57,1.64-1.84ZM397.46,104h-3.35L404.23,75h3.35Zm11.18.33c-2.77,0-5.18-1.67-5.18-4.9V94c0-3.23,2.41-4.9,5.18-4.9s5.19,1.67,5.19,4.9v5.43C413.83,102.68,411.42,104.35,408.64,104.35Zm1.64-10.25c0-1.26-.66-1.84-1.64-1.84S407,92.84,407,94.1v5.27c0,1.27.65,1.84,1.63,1.84s1.64-.57,1.64-1.84Z" style="fill: #929497"/>
    </g>
    <g>
      <path d="M360.8,69a2.36,2.36,0,0,1-1.6.55,2.29,2.29,0,0,1-1.73-.68c-.74-.79-.82-1.7-.82-5.26s.08-4.48.82-5.26a2.29,2.29,0,0,1,1.73-.68,2.2,2.2,0,0,1,1.66.62,3,3,0,0,1,.75,2.17h-1a2.25,2.25,0,0,0-.46-1.54,1.46,1.46,0,0,0-2,0c-.47.58-.56,1.25-.56,4.66s.09,4.08.56,4.65a1.29,1.29,0,0,0,1,.43,1.25,1.25,0,0,0,1-.4,2.2,2.2,0,0,0,.46-1.53h1A3,3,0,0,1,360.8,69Z" style="fill: #929497"/>
      <path d="M365.34,64.58v4.86h-1V64.58l-2.05-6.76h1.07l1.45,5.32,1.47-5.32h1.06Z" style="fill: #929497"/>
      <path d="M368.26,69.44v-.77L371,62.31a6,6,0,0,0,.55-2.45c0-.92-.5-1.36-1.14-1.36s-1.16.44-1.16,1.36v.83h-.91v-.82a2,2,0,0,1,2.07-2.18,2.08,2.08,0,0,1,1.45.55,2.22,2.22,0,0,1,.61,1.67,7.4,7.4,0,0,1-.67,2.69l-2.6,6h3.27v.82Z" style="fill: #929497"/>
      <path d="M377.75,69a2.17,2.17,0,0,1-1.48.57A2.12,2.12,0,0,1,374.8,69a2.16,2.16,0,0,1-.59-1.65V59.91a2.16,2.16,0,0,1,.59-1.65,2.08,2.08,0,0,1,1.47-.57,2.12,2.12,0,0,1,1.48.57,2.16,2.16,0,0,1,.59,1.65v7.44A2.16,2.16,0,0,1,377.75,69Zm-.32-9.14c0-.92-.53-1.36-1.16-1.36s-1.15.44-1.15,1.36V67.4c0,.91.51,1.35,1.15,1.35s1.16-.44,1.16-1.35Z" style="fill: #929497"/>
    </g>
    <g>
      <path d="M387.65,70.36a2.89,2.89,0,0,1-2.35-1c-.9-1-.88-2.78-.88-5.16s0-4.15.88-5.17a2.89,2.89,0,0,1,2.35-1,3,3,0,0,1,2.16.82,3.71,3.71,0,0,1,.93,2.53h-1.9c0-.68-.17-1.63-1.19-1.63a1,1,0,0,0-.9.46c-.36.57-.43,1.8-.43,4s.07,3.43.43,4a1,1,0,0,0,.9.46c.81,0,1.19-.72,1.19-1.55V65.21h-1.19V63.65h3.09V67C390.74,69.19,389.45,70.36,387.65,70.36Z" style="fill: #929497"/>
      <path d="M397.73,69.34a3.21,3.21,0,0,1-4.69,0c-.91-1-.89-2.78-.89-5.16s0-4.15.89-5.17a3.21,3.21,0,0,1,4.69,0c.9,1,.88,2.79.88,5.17S398.63,68.32,397.73,69.34Zm-1.43-9.17a1,1,0,0,0-.92-.46,1,1,0,0,0-.9.46c-.36.57-.42,1.8-.42,4s.06,3.43.42,4a1,1,0,0,0,.9.46,1,1,0,0,0,.92-.46c.36-.58.41-1.8.41-4S396.66,60.74,396.3,60.17Z" style="fill: #929497"/>
      <path d="M405.17,70.23l-.49-2.4h-2.8l-.48,2.4h-2l3-12.11h1.85l2.94,12.11Zm-1.88-9.18-1,5.06h2.07Z" style="fill: #929497"/>
      <path d="M408.28,70.23V58.12h1.91V68.51h3.18v1.72Z" style="fill: #929497"/>
    </g>
    <g>
      <path d="M22.11,71.3V58l-2,1.8v-1l2-1.74h.76V71.3Z" style="fill: #80c241"/>
      <path d="M30.91,70.82a2.42,2.42,0,0,1-3.28,0,2.49,2.49,0,0,1-.66-1.9V59.44a2.49,2.49,0,0,1,.66-1.9,2.42,2.42,0,0,1,3.28,0,2.49,2.49,0,0,1,.66,1.9v9.48A2.49,2.49,0,0,1,30.91,70.82Zm-.1-11.42c0-1.22-.68-1.82-1.54-1.82s-1.54.6-1.54,1.82V69c0,1.22.68,1.82,1.54,1.82s1.54-.6,1.54-1.82Z" style="fill: #80c241"/>
      <path d="M35.65,64.38a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,35.65,64.38Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22ZM36.35,71.3h-.68l5-14.24h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,41.33,71.46Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #80c241"/>
    </g>
    <g>
      <path d="M25.85,7a1.21,1.21,0,0,1-.88.31,1.25,1.25,0,0,1-1-.41c-.39-.43-.41-1.08-.41-2.5s0-2.07.41-2.5a1.25,1.25,0,0,1,1-.41,1.21,1.21,0,0,1,.9.34,1.56,1.56,0,0,1,.41,1.13h-.69a1.11,1.11,0,0,0-.17-.65.55.55,0,0,0-.45-.2.54.54,0,0,0-.47.21c-.19.27-.23.73-.23,2.08s0,1.81.23,2.08a.55.55,0,0,0,.47.22.56.56,0,0,0,.45-.21,1.11,1.11,0,0,0,.18-.65h.69A1.61,1.61,0,0,1,25.85,7Z" style="fill: #82c341"/>
      <path d="M28.34,4.91V7.22h-.69V4.91l-1-3.39h.75L28,4l.64-2.44h.76Z" style="fill: #82c341"/>
      <path d="M30.78,7.22V2.28L30,3V2.21l.83-.69h.64v5.7Z" style="fill: #82c341"/>
      <path d="M32.85,7.22V6.67l1.39-2.95a2.54,2.54,0,0,0,.26-1.1c0-.38-.22-.58-.49-.58a.51.51,0,0,0-.5.58V3h-.64V2.64a1.15,1.15,0,0,1,.32-.88,1.2,1.2,0,0,1,.82-.3,1.16,1.16,0,0,1,.8.29,1.16,1.16,0,0,1,.33.89,3.31,3.31,0,0,1-.32,1.29l-1.28,2.7h1.6v.59Z" style="fill: #82c341"/>
    </g>
    
    <g>
      <path d="M298.44,6.32a1.21,1.21,0,0,1-.88.31,1.24,1.24,0,0,1-1-.4c-.39-.44-.41-1.08-.41-2.51s0-2.07.41-2.5a1.25,1.25,0,0,1,1-.41,1.21,1.21,0,0,1,.9.34,1.56,1.56,0,0,1,.41,1.13h-.69a1.13,1.13,0,0,0-.17-.65.55.55,0,0,0-.45-.2.57.57,0,0,0-.47.21c-.2.28-.24.73-.24,2.08s0,1.81.24,2.08a.55.55,0,0,0,.47.22.56.56,0,0,0,.45-.21,1.11,1.11,0,0,0,.18-.65h.69A1.59,1.59,0,0,1,298.44,6.32Z" style="fill: #005cb9"/>
      <path d="M300.93,4.27v2.3h-.69V4.27L299.19.88h.75l.64,2.43.64-2.43H302Z" style="fill: #005cb9"/>
      <path d="M303.37,6.57V1.64l-.84.68V1.56l.84-.68H304V6.57Z" style="fill: #005cb9"/>
      <path d="M306.25,6.57h-.65l1.5-5.11H306V2.3h-.63V.88h2.39v.53Z" style="fill: #005cb9"/>
    </g>
    <g>
      <path d="M294.14,100.12V86.77l-2,1.8v-1l2-1.74h.76v14.25Z" style="fill: #005cb9"/>
      <path d="M299.94,100.12h-.84l3.84-13.57h-3.3V89h-.76V85.87h4.86v.6Z" style="fill: #005cb9"/>
      <path d="M307.68,93.2a1.71,1.71,0,0,1-1.76-1.84V87.55a1.76,1.76,0,1,1,3.52,0v3.81A1.71,1.71,0,0,1,307.68,93.2Zm1.06-5.65c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.81c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.57h-.68l5-14.25h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,313.36,100.28Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #005cb9"/>
    </g>
    
    <g>
      <path d="M79.12,6.32a1.18,1.18,0,0,1-.88.31,1.22,1.22,0,0,1-1-.4c-.39-.44-.42-1.08-.42-2.51s0-2.07.42-2.5a1.37,1.37,0,0,1,1.88-.07,1.56,1.56,0,0,1,.4,1.13h-.68a1.06,1.06,0,0,0-.18-.65.52.52,0,0,0-.45-.2.56.56,0,0,0-.46.21c-.2.28-.24.73-.24,2.08s0,1.81.24,2.08a.54.54,0,0,0,.46.22.53.53,0,0,0,.45-.21,1,1,0,0,0,.19-.65h.68A1.59,1.59,0,0,1,79.12,6.32Z" style="fill: #82c341"/>
      <path d="M81.61,4.27v2.3h-.69V4.27l-1-3.39h.75l.64,2.43L81.91.88h.76Z" style="fill: #82c341"/>
      <path d="M84.05,6.57V1.64l-.83.68V1.56l.83-.68h.65V6.57Z" style="fill: #82c341"/>
      <path d="M88.05,6.33a1.17,1.17,0,0,1-.81.3,1.2,1.2,0,0,1-.82-.3,1.13,1.13,0,0,1-.33-.87V5.09h.65v.38c0,.39.22.58.5.58a.46.46,0,0,0,.35-.15,1.63,1.63,0,0,0,.17-1c0-.56,0-.8-.17-1a.43.43,0,0,0-.35-.16h-.31V3.27h.31a.42.42,0,0,0,.31-.13,1.27,1.27,0,0,0,.16-.82,1.29,1.29,0,0,0-.15-.79.39.39,0,0,0-.32-.13c-.27,0-.46.18-.46.56v.4h-.65V2a1.14,1.14,0,0,1,.31-.88,1.15,1.15,0,0,1,.8-.3A1.08,1.08,0,0,1,88,1.1a1.54,1.54,0,0,1,.33,1.18,1.86,1.86,0,0,1-.15.94.86.86,0,0,1-.31.32,1,1,0,0,1,.32.31A2,2,0,0,1,88.4,5C88.4,5.66,88.36,6,88.05,6.33Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M77.11,73V59.65l-2,1.8v-1l2-1.74h.76V73Z" style="fill: #80c241"/>
      <path d="M85.91,72.51a2.42,2.42,0,0,1-3.28,0,2.49,2.49,0,0,1-.66-1.9V61.13a2.49,2.49,0,0,1,.66-1.9,2.42,2.42,0,0,1,3.28,0,2.49,2.49,0,0,1,.66,1.9v9.48A2.49,2.49,0,0,1,85.91,72.51Zm-.1-11.42c0-1.22-.68-1.82-1.54-1.82s-1.54.6-1.54,1.82v9.56c0,1.22.68,1.82,1.54,1.82s1.54-.6,1.54-1.82Z" style="fill: #80c241"/>
      <path d="M90.65,66.07a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,90.65,66.07Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22ZM91.35,73h-.68l5-14.24h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,96.33,73.15Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #80c241"/>
    </g>
    
    <g>
      <path d="M133.2,6.32a1.18,1.18,0,0,1-.88.31,1.22,1.22,0,0,1-1-.4c-.4-.44-.42-1.08-.42-2.51s0-2.07.42-2.5a1.23,1.23,0,0,1,1-.41,1.21,1.21,0,0,1,.9.34,1.56,1.56,0,0,1,.41,1.13h-.69a1.06,1.06,0,0,0-.17-.65.54.54,0,0,0-.45-.2.55.55,0,0,0-.46.21c-.2.28-.24.73-.24,2.08s0,1.81.24,2.08a.53.53,0,0,0,.46.22.54.54,0,0,0,.45-.21,1,1,0,0,0,.18-.65h.69A1.59,1.59,0,0,1,133.2,6.32Z" style="fill: #82c341"/>
      <path d="M135.69,4.27v2.3H135V4.27L134,.88h.76l.64,2.43L136,.88h.76Z" style="fill: #82c341"/>
      <path d="M138.13,6.57V1.64l-.83.68V1.56l.83-.68h.65V6.57Z" style="fill: #82c341"/>
      <path d="M142.23,5.63v.94h-.65V5.63H140V5.05L141.5.88h.62l-1.41,4.17h.87V3.75h.65v1.3h.4v.58Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M134.32,56.08a2.37,2.37,0,0,1-3.28,0c-.62-.68-.74-1.41-.74-3.67a10.8,10.8,0,0,1,.58-4l2.22-6.1h.74l-2.28,6.26a1.91,1.91,0,0,1,1.28-.48,2,2,0,0,1,1.52.64c.52.56.7,1.06.7,3.66C135.06,54.67,134.94,55.4,134.32,56.08Zm-.56-6.87a1.55,1.55,0,0,0-2.16,0c-.46.48-.54,1.28-.54,3.2s.08,2.72.54,3.21a1.55,1.55,0,0,0,2.16,0c.46-.49.54-1.29.54-3.21S134.22,49.69,133.76,49.21Z" style="fill: #80c241"/>
      <path d="M139.06,49.65a1.71,1.71,0,0,1-1.76-1.84V44a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,139.06,49.65ZM140.12,44c0-.74-.36-1.22-1.06-1.22S138,43.27,138,44v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.57h-.68l5-14.25h.68Zm5,.16A1.71,1.71,0,0,1,143,54.9V51.09a1.76,1.76,0,1,1,3.52,0V54.9A1.71,1.71,0,0,1,144.74,56.74Zm1.06-5.65c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22V54.9c0,.73.36,1.22,1.06,1.22s1.06-.49,1.06-1.22Z" style="fill: #80c241"/>
    </g>
    
    <g>
      <path d="M188.44,6.32a1.21,1.21,0,0,1-.88.31,1.24,1.24,0,0,1-1-.4c-.39-.44-.41-1.08-.41-2.51s0-2.07.41-2.5a1.25,1.25,0,0,1,1-.41,1.21,1.21,0,0,1,.9.34,1.56,1.56,0,0,1,.41,1.13h-.69a1.13,1.13,0,0,0-.17-.65.55.55,0,0,0-.45-.2.57.57,0,0,0-.47.21c-.2.28-.24.73-.24,2.08s0,1.81.24,2.08a.55.55,0,0,0,.47.22.56.56,0,0,0,.45-.21,1.11,1.11,0,0,0,.18-.65h.69A1.59,1.59,0,0,1,188.44,6.32Z" style="fill: #82c341"/>
      <path d="M190.93,4.27v2.3h-.69V4.27L189.19.88h.75l.64,2.43.64-2.43H192Z" style="fill: #82c341"/>
      <path d="M193.37,6.57V1.64l-.84.68V1.56l.84-.68H194V6.57Z" style="fill: #82c341"/>
      <path d="M197.39,6.31a1.17,1.17,0,0,1-.82.32,1.19,1.19,0,0,1-.82-.29,1.15,1.15,0,0,1-.33-.88V5.13h.65v.38c0,.42.22.6.5.6a.43.43,0,0,0,.36-.17,2.43,2.43,0,0,0,.16-1.19,2.17,2.17,0,0,0-.16-1.13.4.4,0,0,0-.36-.19.51.51,0,0,0-.5.57v.19h-.62V.88h2.21v.58h-1.61V3.23a.8.8,0,0,1,.28-.27.79.79,0,0,1,.42-.11.86.86,0,0,1,.71.32c.24.3.27.74.27,1.54S197.72,6,197.39,6.31Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M187.11,88V74.64l-2,1.8v-1l2-1.74h.76V88Z" style="fill: #80c241"/>
      <path d="M196,85.42V88h-.76V85.42h-3.7v-.68l3.6-11h.76l-3.6,11h2.94V80.22H196v4.52h1v.68Z" style="fill: #80c241"/>
      <path d="M200.65,81.06a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,200.65,81.06Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22ZM201.35,88h-.68l5-14.24h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84V82.5a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,206.33,88.14Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #80c241"/>
    </g>
    
    <g>
      <path d="M242.48,6.32a1.21,1.21,0,0,1-.88.31,1.24,1.24,0,0,1-1-.4c-.39-.44-.41-1.08-.41-2.51s0-2.07.41-2.5a1.25,1.25,0,0,1,1-.41,1.21,1.21,0,0,1,.9.34,1.6,1.6,0,0,1,.41,1.13h-.69a1.06,1.06,0,0,0-.18-.65.52.52,0,0,0-.44-.2.57.57,0,0,0-.47.21c-.2.28-.24.73-.24,2.08s0,1.81.24,2.08a.55.55,0,0,0,.47.22.52.52,0,0,0,.44-.21,1,1,0,0,0,.19-.65h.69A1.59,1.59,0,0,1,242.48,6.32Z" style="fill: #82c341"/>
      <path d="M245,4.27v2.3h-.68V4.27L243.23.88H244l.64,2.43.64-2.43H246Z" style="fill: #82c341"/>
      <path d="M247.4,6.57V1.64l-.83.68V1.56l.83-.68h.65V6.57Z" style="fill: #82c341"/>
      <path d="M251.48,6.25a1.2,1.2,0,0,1-1.75,0,2.05,2.05,0,0,1-.28-1.38,4,4,0,0,1,.23-1.43l1-2.56h.66l-.93,2.37a.65.65,0,0,1,.41-.13.89.89,0,0,1,.7.32c.21.25.29.52.29,1.43A2,2,0,0,1,251.48,6.25ZM251,3.82a.47.47,0,0,0-.36-.16.48.48,0,0,0-.35.16,1.83,1.83,0,0,0-.16,1,1.87,1.87,0,0,0,.16,1,.45.45,0,0,0,.35.15A.45.45,0,0,0,251,5.9a1.78,1.78,0,0,0,.16-1C251.12,4.36,251.12,4,251,3.82Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M241.11,92.09V78.74l-2,1.8v-1l2-1.74h.76V92.09Z" style="fill: #80c241"/>
      <path d="M249.91,91.49a2.13,2.13,0,0,1-1.64.76,2.36,2.36,0,0,1-1.64-.6,2.55,2.55,0,0,1-.7-1.92v-1h.76v.94c0,1.34.7,1.92,1.58,1.92a1.31,1.31,0,0,0,1.08-.54c.4-.54.54-1.16.54-3.38s-.16-2.86-.56-3.4a1.24,1.24,0,0,0-1.06-.53,1.65,1.65,0,0,0-1.58,1.81v.8H246V77.84h4.46v.68h-3.76V84a1.93,1.93,0,0,1,.64-.66,1.81,1.81,0,0,1,1.08-.28,1.88,1.88,0,0,1,1.52.74c.58.7.72,1.47.72,3.85S250.49,90.79,249.91,91.49Z" style="fill: #80c241"/>
      <path d="M254.65,85.17a1.71,1.71,0,0,1-1.76-1.84V79.52a1.76,1.76,0,1,1,3.52,0v3.81A1.71,1.71,0,0,1,254.65,85.17Zm1.06-5.65c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.81c0,.74.36,1.21,1.06,1.21s1.06-.47,1.06-1.21Zm-.36,12.57h-.68l5-14.25h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,260.33,92.25Zm1.06-5.64c0-.74-.36-1.23-1.06-1.23s-1.06.49-1.06,1.23v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #80c241"/>
    </g>
    <line x1="0.47" y1="103.51" x2="329.47" y2="103.51" style="fill: none;stroke: #929497;stroke-linecap: round;stroke-linejoin: round"/>
    <g style="clip-path: url(#clip-path1)">
      <path d="M341.88,103.73a.91.91,0,0,0,.65,0,.75.75,0,0,0,.28-.18l10.25-9.9a.79.79,0,0,0,0-1.16.86.86,0,0,0-1.21,0L343.06,101V75.75a.86.86,0,0,0-1.71,0V101l-8.79-8.49a.86.86,0,0,0-1.21,0,.8.8,0,0,0,0,1.16l10.25,9.9a.75.75,0,0,0,.28.18" style="fill: #929497"/>
    </g>
    <g style="clip-path: url(#clip-path1-2)">
      <path d="M122.07,56.41a.5.5,0,0,0,.34,0,.56.56,0,0,0,.15-.1l5.32-5.14a.41.41,0,0,0,0-.61.47.47,0,0,0-.63,0L122.69,55V41.87a.45.45,0,0,0-.89,0V55l-4.57-4.42a.45.45,0,0,0-.76.31.43.43,0,0,0,.13.3l5.33,5.14a.71.71,0,0,0,.14.1" style="fill: #82c341"/>
    </g>
    <g style="clip-path: url(#clip-path1-3)">
      <path d="M176.41,88.74a.5.5,0,0,0,.34,0,.42.42,0,0,0,.14-.09l5.33-5.15a.42.42,0,0,0,0-.6.45.45,0,0,0-.63,0L177,87.31V74.2a.45.45,0,0,0-.89,0V87.31l-4.57-4.41a.44.44,0,0,0-.62,0,.41.41,0,0,0,0,.6l5.32,5.15a.38.38,0,0,0,.15.09" style="fill: #82c341"/>
    </g>
    <g style="clip-path: url(#clip-path1-4)">
      <path d="M231.41,92.74a.5.5,0,0,0,.34,0,.42.42,0,0,0,.14-.09l5.33-5.15a.42.42,0,0,0,0-.6.45.45,0,0,0-.63,0L232,91.31V78.2a.45.45,0,0,0-.89,0V91.31l-4.57-4.41a.44.44,0,0,0-.62,0,.41.41,0,0,0,0,.6l5.32,5.15a.38.38,0,0,0,.15.09" style="fill: #82c341"/>
    </g>
    <g style="clip-path: url(#clip-path1-5)">
      <path d="M67.74,73.41a.5.5,0,0,0,.34,0,.71.71,0,0,0,.14-.1l5.33-5.14a.43.43,0,0,0,0-.61.47.47,0,0,0-.63,0L68.35,72V58.87a.44.44,0,0,0-.88,0V72L62.9,67.56a.47.47,0,0,0-.63,0,.43.43,0,0,0-.13.31.39.39,0,0,0,.13.3l5.33,5.14a.5.5,0,0,0,.14.1" style="fill: #82c341"/>
    </g>
    <g style="clip-path: url(#clip-path1-6)">
      <path d="M12.07,71.74a.5.5,0,0,0,.34,0,.38.38,0,0,0,.15-.09l5.32-5.15a.4.4,0,0,0,0-.6.45.45,0,0,0-.63,0l-4.56,4.41V57.2a.45.45,0,0,0-.89,0V70.31L7.23,65.9a.45.45,0,0,0-.63,0,.41.41,0,0,0,0,.6l5.33,5.15a.42.42,0,0,0,.14.09" style="fill: #82c341"/>
    </g>
    <g style="clip-path: url(#clip-path1-7)">
      <path d="M284,100.41a.5.5,0,0,0,.34,0,.71.71,0,0,0,.14-.1l5.33-5.14a.43.43,0,0,0,0-.61.47.47,0,0,0-.63,0L284.57,99V85.87a.44.44,0,0,0-.88,0V99l-4.57-4.42a.47.47,0,0,0-.63,0,.43.43,0,0,0-.13.31.39.39,0,0,0,.13.3l5.33,5.14a.39.39,0,0,0,.14.1" style="fill: #005cb9"/>
    </g>
    <g>
      <polygon points="318.29 85.11 315.96 87.09 318.31 89.08 320.64 87.1 318.29 85.11" style="fill: #005cb9"/>
      <path d="M318,87.1l.33-1,.33,1Zm.18-1.27L317.42,88h.26l.21-.66h.8l.2.66h.29l-.71-2.14Z" style="fill: #fff"/>
    </g>
  </g>
</svg>

				<span class="footnote margin-top-20"><img src="../_images/scorecard/global/a.svg" class="aNote"> Reviewed by Ernst & Young LLP. Please refer to the <a href="../financials/index.php#review" class="link hideLinkMobile">Review Report</a><a href="../financials/nonfinancial.pdf" class="link mobileLinkOnly" target="_blank">Review Report</a>.</span>
			</div>
		</div>
		<div class="progressContent--4__tab progressContent--4__tab--3">
			<div class="progressContent--4__callout progressContent--4__callout--3">
				<img class="progressContent--4__target" src="../_images/strategy/growth/icon1.svg" alt="">
				<h4>2020 Goal</h4>
				<p>
					Reduce greenhouse <br>
					gas emissions by <br>
					<span><img class="progressContent--4__arrow" src="../_images/strategy/growth/arrow.svg" alt="">20%</span> <br>
					per case of product sold <br>
					versus a 2011 calendar <br>
					year baseline.
				</p>
				<h4>Results to Date</h4>
				<img class="progressContent--4__arrow" src="../_images/strategy/growth/arrow.svg" alt=""><span>32%</span>
			</div>

			<h2 class="progressContent__heading">GHG Emissions Reductions Ahead of<br> 2020 Goal</h2>

			<p>We’ve now cut our greenhouse gas emissions by 32 percent, exceeding our 20 percent goal three years ahead of plan. Achieving this goal is the result of steady progress throughout the goal period, with the exception of a slight setback in 2014 because of extreme weather that required additional energy use. It also takes into account our restated greenhouse gas emissions.<sup>1</sup></p>
			<p>Similar to our energy use, some of the recent reductions in greenhouse gas emissions on an intensity basis are due to our increase in product volume and the resulting efficiencies of scale. Greenhouse gas emissions were also reduced through facility-based initiatives to install energy-efficient LED lighting.</p>
			<p>Last year we began using some renewable energy, with solar panels activated at our Fairfield, California, plant and our regional distribution center in Aberdeen, Maryland. Both solar panel arrays were built with a third-party provider as power purchase agreements. That means we didn’t spend company money to build these projects, and the facilities buy the solar- produced power from the third party instead of from the utility.</p>

			<p class="footnote footnote--progress"><sup>1</sup> In 2017, we changed our methodology for calculating Scope 3 emissions because the U.S. EPA stopped supporting the methodology we had previously adopted. Scope 3 emissions for business travel are calculated using “per vehicle-mile traveled” and “per passenger-mile traveled” emissions factors from the EPA’s Center for Corporate Climate Leadership guidance, published in 2018. Emissions from finished goods transportation are calculated using “per ton-mile” emission factors, according to the same guidance. In prior years, Scope 3 emissions were calculated based on fuel usage using the EPA’s “btu/ton-mile” and “GHG emissions per unit of fuel” emission factors. For the purposes of our 2020 reduction goal, we’ve revised the 2011 GHG baseline to apply the same methodology being adopted in 2017 to the baseline year. This increases our 2011 baseline year emissions from 507,216 metric tons CO2e to 761,980 metric tons CO2e, against which 2017 and future years in our 2020 goal period will be reported. This enables us to accurately compare GHG emissions for 2017 going forward to the 2011 baseline. We haven’t revised GHG emissions for 2012 through 2016.</p>
			<img src="../_images/strategy/growth/progress3.jpg" alt="" class="progressContent--4__image progressContent--4__image--4">
			<div class="progressContent--4__chart progressContent--4__chart--2">
				<h4>GHG Emissions <br><span>(annual progress versus 2011 base year):</span></h4>
				<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="412.04" height="134.38" viewBox="0 0 412.04 134.38" class="growthChart growthChart--2">
  <defs>
    <clipPath id="clip-path2">
      <rect x="328.92" y="49.2" width="22.21" height="28.87" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path2-2">
      <rect x="7.84" y="51.05" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path2-3">
      <rect x="282.18" y="115.38" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path2-4">
      <rect x="62.51" y="59.05" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path2-5">
      <rect x="115.84" y="55.05" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path2-6">
      <rect x="171.51" y="82.72" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path2-7">
      <rect x="224.51" y="82.38" width="11.54" height="15" style="fill: none"/>
    </clipPath>
  </defs>
  <title>chart2</title>
  <rect class="bar" x="20.34" y="13.25" width="16.29" height="33.33" style="fill: #82c341"/>
  <rect class="bar" x="75.63" y="12.92" width="16.29" height="42.33" style="fill: #82c341"/>
  <rect class="bar" x="129.46" y="12.59" width="16.29" height="38" style="fill: #82c341"/>
  <rect class="bar" x="184.39" y="12.25" width="16.29" height="56.33" style="fill: #82c341"/>
  <rect class="bar" x="238.52" y="12.25" width="16.29" height="59.67" style="fill: #82c341"/>
  <rect class="bar" x="293.16" y="12.25" width="16.29" height="98.66" style="fill: #005cb9"/>
  
  <line x1="0.5" y1="79.25" x2="329.9" y2="79.25" style="fill: none;stroke: #929497;stroke-linecap: round;stroke-linejoin: round"/>
  <g>
    <path d="M352.85,78.3V74.63l7.27-14.13a11.37,11.37,0,0,0,1.18-5.19c0-1.67-.9-2.53-2.08-2.53a2.18,2.18,0,0,0-2.17,2.49v1.88h-4.32V55.44a6.1,6.1,0,0,1,1.79-4.82,6.93,6.93,0,0,1,4.7-1.72,6.32,6.32,0,0,1,4.49,1.56,6.56,6.56,0,0,1,1.92,5A14.85,14.85,0,0,1,364,61.85l-6.58,12.57h8.17V78.3Z" style="fill: #929497"/>
    <path d="M380.12,76.91a6.58,6.58,0,0,1-4.61,1.72,6.72,6.72,0,0,1-4.66-1.72A6.11,6.11,0,0,1,369,72.1V55.44a6.12,6.12,0,0,1,1.83-4.82,6.77,6.77,0,0,1,4.66-1.72,6.63,6.63,0,0,1,4.61,1.72A6.09,6.09,0,0,1,382,55.44V72.1A6.08,6.08,0,0,1,380.12,76.91Zm-2.49-21.64c0-1.67-.94-2.49-2.12-2.49a2.18,2.18,0,0,0-2.16,2.49v17a2.18,2.18,0,0,0,2.16,2.49c1.18,0,2.12-.82,2.12-2.49Z" style="fill: #929497"/>
    <path d="M390.78,64.13c-2.78,0-5.18-1.67-5.18-4.9V53.8c0-3.22,2.4-4.9,5.18-4.9S396,50.58,396,53.8v5.43C396,62.46,393.56,64.13,390.78,64.13Zm1.63-10.25c0-1.26-.65-1.83-1.63-1.83s-1.67.57-1.67,1.83v5.27c0,1.27.69,1.84,1.67,1.84s1.63-.57,1.63-1.84Zm2.86,24.42h-3.35l10.13-29.07h3.35Zm11.19.33c-2.78,0-5.18-1.67-5.18-4.9V68.3c0-3.23,2.4-4.9,5.18-4.9s5.19,1.67,5.19,4.9v5.43C411.65,77,409.24,78.63,406.46,78.63Zm1.63-10.25c0-1.27-.65-1.84-1.63-1.84s-1.63.57-1.63,1.84v5.27c0,1.26.65,1.84,1.63,1.84s1.63-.58,1.63-1.84Z" style="fill: #929497"/>
  </g>
  <g>
    <path d="M358.61,43.29a2.3,2.3,0,0,1-1.6.56,2.28,2.28,0,0,1-1.73-.69c-.73-.78-.81-1.69-.81-5.25s.08-4.48.81-5.26A2.28,2.28,0,0,1,357,32a2.25,2.25,0,0,1,1.67.62,3.11,3.11,0,0,1,.75,2.17h-1a2.29,2.29,0,0,0-.46-1.53,1.3,1.3,0,0,0-1-.39,1.26,1.26,0,0,0-1,.42c-.48.57-.56,1.24-.56,4.66s.08,4.08.56,4.65a1.46,1.46,0,0,0,2,0,2.25,2.25,0,0,0,.46-1.53h1A3,3,0,0,1,358.61,43.29Z" style="fill: #929497"/>
    <path d="M363.16,38.85v4.87h-1V38.85l-2-6.76h1.06l1.46,5.33,1.47-5.33h1.06Z" style="fill: #929497"/>
    <path d="M366.08,43.72V43l2.78-6.37a6.12,6.12,0,0,0,.55-2.45c0-.91-.51-1.35-1.14-1.35s-1.16.44-1.16,1.35V35h-.92v-.82a2.1,2.1,0,0,1,.59-1.61,2.15,2.15,0,0,1,1.49-.58,2.08,2.08,0,0,1,1.45.56,2.19,2.19,0,0,1,.6,1.66,7.39,7.39,0,0,1-.66,2.7l-2.6,6h3.26v.82Z" style="fill: #929497"/>
    <path d="M375.57,43.28a2.19,2.19,0,0,1-1.49.57A2,2,0,0,1,372,41.63V34.18A2,2,0,0,1,374.08,32a2.15,2.15,0,0,1,1.49.58,2.12,2.12,0,0,1,.59,1.64v7.45A2.16,2.16,0,0,1,375.57,43.28Zm-.33-9.15c0-.91-.52-1.35-1.16-1.35s-1.14.44-1.14,1.35v7.55c0,.91.51,1.35,1.14,1.35s1.16-.44,1.16-1.35Z" style="fill: #929497"/>
  </g>
  <g>
    <path d="M385.46,44.64a2.88,2.88,0,0,1-2.34-1c-.9-1-.88-2.78-.88-5.16s0-4.15.88-5.17a2.88,2.88,0,0,1,2.34-1,2.93,2.93,0,0,1,2.16.81,3.76,3.76,0,0,1,.94,2.54h-1.91c0-.68-.17-1.64-1.19-1.64a1,1,0,0,0-.9.46c-.35.58-.42,1.81-.42,4s.07,3.43.42,4a1,1,0,0,0,.9.46c.82,0,1.19-.72,1.19-1.55V39.49h-1.19V37.93h3.1v3.35C388.56,43.47,387.27,44.64,385.46,44.64Z" style="fill: #929497"/>
    <path d="M395.54,43.62a3.21,3.21,0,0,1-4.69,0c-.9-1-.88-2.78-.88-5.16s0-4.15.88-5.17a3.21,3.21,0,0,1,4.69,0c.9,1,.89,2.79.89,5.17S396.44,42.6,395.54,43.62Zm-1.42-9.18a1,1,0,0,0-.92-.46,1,1,0,0,0-.9.46c-.36.58-.43,1.81-.43,4s.07,3.43.43,4a1,1,0,0,0,.9.46,1,1,0,0,0,.92-.46c.35-.58.41-1.8.41-4S394.47,35,394.12,34.44Z" style="fill: #929497"/>
    <path d="M403,44.51l-.49-2.4h-2.81l-.47,2.4h-2l3-12.11H402L405,44.51Zm-1.89-9.18-1,5.06h2.07Z" style="fill: #929497"/>
    <path d="M406.1,44.51V32.4H408V42.79h3.17v1.72Z" style="fill: #929497"/>
  </g>
  <g>
    <path d="M23.48,65.58V52.24l-2,1.8v-1l2-1.74h.76V65.58Z" style="fill: #80c241"/>
    <path d="M32.28,65.1a2.42,2.42,0,0,1-3.28,0,2.49,2.49,0,0,1-.66-1.9V53.72a2.49,2.49,0,0,1,.66-1.9,2.42,2.42,0,0,1,3.28,0,2.49,2.49,0,0,1,.66,1.9V63.2A2.49,2.49,0,0,1,32.28,65.1Zm-.1-11.42c0-1.22-.68-1.82-1.54-1.82s-1.54.6-1.54,1.82v9.56c0,1.22.68,1.82,1.54,1.82s1.54-.6,1.54-1.82Z" style="fill: #80c241"/>
    <path d="M37,58.66a1.71,1.71,0,0,1-1.76-1.84V53a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,37,58.66ZM38.08,53c0-.74-.36-1.22-1.06-1.22S36,52.28,36,53v3.8C36,57.56,36.32,58,37,58s1.06-.48,1.06-1.22Zm-.36,12.56H37l5-14.24h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84V60.1a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,42.7,65.74Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #80c241"/>
  </g>
  <g>
    <path d="M26.33,7.25a1.18,1.18,0,0,1-.88.31,1.23,1.23,0,0,1-1-.41c-.39-.43-.42-1.08-.42-2.5s0-2.07.42-2.5a1.23,1.23,0,0,1,1-.41,1.28,1.28,0,0,1,.91.33,1.6,1.6,0,0,1,.4,1.14h-.68a1.07,1.07,0,0,0-.18-.66.54.54,0,0,0-.45-.2.53.53,0,0,0-.46.22c-.2.27-.24.73-.24,2.08s0,1.81.24,2.08a.52.52,0,0,0,.46.21.54.54,0,0,0,.45-.2,1,1,0,0,0,.18-.65h.69A1.61,1.61,0,0,1,26.33,7.25Z" style="fill: #82c341"/>
    <path d="M28.82,5.19V7.5h-.69V5.19l-1-3.39h.75l.64,2.43.64-2.43h.76Z" style="fill: #82c341"/>
    <path d="M31.26,7.5V2.56l-.83.68V2.49l.83-.69h.65V7.5Z" style="fill: #82c341"/>
    <path d="M33.33,7.5V7L34.72,4A2.58,2.58,0,0,0,35,2.9c0-.39-.22-.58-.49-.58S34,2.51,34,2.9v.38h-.65V2.91A1.14,1.14,0,0,1,33.67,2a1.21,1.21,0,0,1,.82-.3,1.11,1.11,0,0,1,.8.29,1.16,1.16,0,0,1,.34.89,3.2,3.2,0,0,1-.33,1.29L34,6.91h1.6V7.5Z" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M298.92,6.6a1.2,1.2,0,0,1-.88.31,1.21,1.21,0,0,1-1-.41c-.4-.43-.42-1.07-.42-2.5s0-2.07.42-2.5a1.36,1.36,0,0,1,1.87-.07,1.56,1.56,0,0,1,.41,1.13h-.69a1,1,0,0,0-.17-.65.54.54,0,0,0-.45-.2.55.55,0,0,0-.46.21c-.2.28-.24.73-.24,2.08s0,1.81.24,2.08a.53.53,0,0,0,.46.22.54.54,0,0,0,.45-.21,1,1,0,0,0,.18-.65h.69A1.61,1.61,0,0,1,298.92,6.6Z" style="fill: #005cb9"/>
    <path d="M301.41,4.55v2.3h-.69V4.55l-1.05-3.39h.76l.64,2.43.63-2.43h.76Z" style="fill: #005cb9"/>
    <path d="M303.85,6.85V1.92L303,2.6V1.84l.83-.68h.65V6.85Z" style="fill: #005cb9"/>
    <path d="M306.74,6.85h-.66l1.5-5.11h-1.1v.84h-.63V1.16h2.39v.53Z" style="fill: #005cb9"/>
  </g>
  <g>
    <path d="M79.61,6.6a1.21,1.21,0,0,1-.88.31,1.25,1.25,0,0,1-1-.41c-.39-.43-.41-1.08-.41-2.5s0-2.07.41-2.5a1.25,1.25,0,0,1,1-.41,1.21,1.21,0,0,1,.9.34A1.6,1.6,0,0,1,80,2.56h-.69a1,1,0,0,0-.18-.65.52.52,0,0,0-.44-.2.54.54,0,0,0-.47.21c-.2.27-.24.73-.24,2.08s0,1.81.24,2.08a.55.55,0,0,0,.47.22.52.52,0,0,0,.44-.21,1,1,0,0,0,.19-.65h.69A1.61,1.61,0,0,1,79.61,6.6Z" style="fill: #82c341"/>
    <path d="M82.09,4.55v2.3h-.68V4.55l-1-3.39h.75l.64,2.43.64-2.43h.76Z" style="fill: #82c341"/>
    <path d="M84.54,6.85V1.92l-.84.67V1.84l.84-.68h.64V6.85Z" style="fill: #82c341"/>
    <path d="M88.53,6.61a1.17,1.17,0,0,1-.81.3,1.21,1.21,0,0,1-.82-.3,1.12,1.12,0,0,1-.32-.87V5.37h.64v.38c0,.39.23.58.5.58a.46.46,0,0,0,.35-.15c.14-.16.17-.46.17-1s0-.8-.17-1a.43.43,0,0,0-.35-.16h-.3V3.55h.3A.41.41,0,0,0,88,3.42c.14-.15.16-.41.16-.82a1.28,1.28,0,0,0-.14-.79.42.42,0,0,0-.33-.14c-.26,0-.46.19-.46.56v.4h-.64V2.27a1.14,1.14,0,0,1,.31-.88,1.14,1.14,0,0,1,.79-.3,1.08,1.08,0,0,1,.78.29,1.54,1.54,0,0,1,.34,1.18,1.91,1.91,0,0,1-.15.94,1,1,0,0,1-.32.32,1,1,0,0,1,.32.31,1.87,1.87,0,0,1,.2,1.12C88.89,5.94,88.85,6.3,88.53,6.61Z" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M133.68,6.6a1.18,1.18,0,0,1-.88.31,1.24,1.24,0,0,1-1-.41c-.39-.43-.42-1.08-.42-2.5s0-2.07.42-2.5a1.37,1.37,0,0,1,1.88-.07,1.6,1.6,0,0,1,.41,1.13h-.69a1,1,0,0,0-.18-.65.52.52,0,0,0-.45-.2.54.54,0,0,0-.46.21c-.2.27-.24.73-.24,2.08s0,1.81.24,2.08a.54.54,0,0,0,.46.22.53.53,0,0,0,.45-.21,1,1,0,0,0,.19-.65h.68A1.57,1.57,0,0,1,133.68,6.6Z" style="fill: #82c341"/>
    <path d="M136.17,4.55v2.3h-.68V4.55l-1.05-3.39h.75l.64,2.43.64-2.43h.76Z" style="fill: #82c341"/>
    <path d="M138.61,6.85V1.92l-.83.67V1.84l.83-.68h.65V6.85Z" style="fill: #82c341"/>
    <path d="M142.72,5.91v.94h-.65V5.91h-1.54V5.33L142,1.16h.62l-1.41,4.17h.88V4h.65v1.3h.4v.58Z" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M188.92,6.6a1.2,1.2,0,0,1-.88.31,1.23,1.23,0,0,1-1-.41c-.4-.43-.42-1.08-.42-2.5s0-2.07.42-2.5a1.23,1.23,0,0,1,1-.41,1.21,1.21,0,0,1,.9.34,1.56,1.56,0,0,1,.41,1.13h-.69a1,1,0,0,0-.17-.65.54.54,0,0,0-.45-.2.52.52,0,0,0-.46.21c-.2.27-.24.73-.24,2.08s0,1.81.24,2.08a.53.53,0,0,0,.46.22.54.54,0,0,0,.45-.21,1,1,0,0,0,.18-.65h.69A1.61,1.61,0,0,1,188.92,6.6Z" style="fill: #82c341"/>
    <path d="M191.41,4.55v2.3h-.69V4.55l-1.05-3.39h.76l.64,2.43.63-2.43h.76Z" style="fill: #82c341"/>
    <path d="M193.85,6.85V1.92l-.83.67V1.84l.83-.68h.65V6.85Z" style="fill: #82c341"/>
    <path d="M197.87,6.58a1.13,1.13,0,0,1-.82.33,1.21,1.21,0,0,1-.82-.29,1.15,1.15,0,0,1-.32-.88V5.41h.64v.38c0,.42.22.6.5.6a.43.43,0,0,0,.36-.17A2.33,2.33,0,0,0,197.57,5a2.21,2.21,0,0,0-.15-1.13.43.43,0,0,0-.37-.19.51.51,0,0,0-.5.57v.19h-.61V1.16h2.2v.58h-1.61V3.51a1.07,1.07,0,0,1,.28-.28.9.9,0,0,1,.42-.1.84.84,0,0,1,.71.32A2.46,2.46,0,0,1,198.22,5C198.22,5.81,198.2,6.24,197.87,6.58Z" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M243,6.6a1.2,1.2,0,0,1-.88.31,1.25,1.25,0,0,1-1-.41c-.39-.43-.41-1.07-.41-2.5s0-2.07.41-2.5a1.25,1.25,0,0,1,1-.41,1.21,1.21,0,0,1,.9.34,1.56,1.56,0,0,1,.41,1.13h-.69a1,1,0,0,0-.17-.65.54.54,0,0,0-.45-.2.55.55,0,0,0-.46.21c-.2.28-.24.73-.24,2.08s0,1.81.24,2.08a.53.53,0,0,0,.46.22.54.54,0,0,0,.45-.21,1,1,0,0,0,.18-.65h.69A1.61,1.61,0,0,1,243,6.6Z" style="fill: #82c341"/>
    <path d="M245.45,4.55v2.3h-.69V4.55l-1-3.39h.75l.64,2.43.64-2.43h.76Z" style="fill: #82c341"/>
    <path d="M247.89,6.85V1.92l-.83.68V1.84l.83-.68h.65V6.85Z" style="fill: #82c341"/>
    <path d="M252,6.53a1.08,1.08,0,0,1-.88.38,1,1,0,0,1-.87-.38c-.24-.3-.29-.62-.29-1.38a4,4,0,0,1,.23-1.44l1-2.55h.66l-.92,2.37a.63.63,0,0,1,.4-.14.91.91,0,0,1,.71.33c.21.25.29.51.29,1.43A2,2,0,0,1,252,6.53Zm-.52-2.43a.46.46,0,0,0-.36-.16.42.42,0,0,0-.35.16c-.16.18-.16.54-.16,1a1.78,1.78,0,0,0,.16,1,.43.43,0,0,0,.35.15.48.48,0,0,0,.36-.15,1.87,1.87,0,0,0,.16-1A1.83,1.83,0,0,0,251.45,4.1Z" style="fill: #82c341"/>
  </g>
  <g style="clip-path: url(#clip-path2)">
    <path d="M339.69,78a.94.94,0,0,0,.66,0,1.34,1.34,0,0,0,.28-.18l10.25-9.9a.82.82,0,0,0,0-1.17.88.88,0,0,0-1.21,0l-8.79,8.49V50a.86.86,0,0,0-1.71,0V75.25l-8.79-8.49a.88.88,0,0,0-1.21,0,.83.83,0,0,0-.25.59.79.79,0,0,0,.25.58l10.25,9.9a1.06,1.06,0,0,0,.27.18" style="fill: #929497"/>
  </g>
  <g style="clip-path: url(#clip-path2-2)">
    <path d="M13.44,66a.5.5,0,0,0,.34,0,.4.4,0,0,0,.15-.1l5.32-5.14a.4.4,0,0,0,0-.6.45.45,0,0,0-.63,0l-4.56,4.41V51.48a.45.45,0,0,0-.89,0V64.59L8.6,60.18a.45.45,0,0,0-.63,0,.41.41,0,0,0,0,.6l5.33,5.14a.45.45,0,0,0,.14.1" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M299.73,129.56a2.42,2.42,0,0,1-3.28,0,2.49,2.49,0,0,1-.68-1.9v-1h.76v1c0,1.22.7,1.84,1.56,1.84a1.36,1.36,0,0,0,1.06-.44c.4-.46.56-1,.56-2.92,0-2.16-.12-2.54-.56-3a1.39,1.39,0,0,0-1.06-.44h-.86v-.68h.86a1.28,1.28,0,0,0,1-.38c.38-.4.52-1,.52-2.48s-.16-2.08-.5-2.46a1.37,1.37,0,0,0-1-.4c-.86,0-1.46.62-1.46,1.84v1h-.76v-1a2.49,2.49,0,0,1,.64-1.9,2.35,2.35,0,0,1,3.16,0c.5.5.68,1.14.68,2.94a4.36,4.36,0,0,1-.4,2.48,2,2,0,0,1-.8.72,2.23,2.23,0,0,1,.78.62c.4.54.54.92.54,3.16S300.31,128.94,299.73,129.56Z" style="fill: #005cb9"/>
    <path d="M302.71,130.06v-.62L306,121.3a8.08,8.08,0,0,0,.72-3.14c0-1.22-.68-1.82-1.54-1.82s-1.54.6-1.54,1.82v1h-.76v-1a2.48,2.48,0,0,1,.66-1.86,2.42,2.42,0,0,1,3.28,0,2.49,2.49,0,0,1,.66,1.9,9.52,9.52,0,0,1-.82,3.38l-3.18,7.8h4v.68Z" style="fill: #005cb9"/>
    <path d="M311.49,123.14a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,311.49,123.14Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56h-.68l5-14.24h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,317.17,130.22Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #005cb9"/>
  </g>
  <g style="clip-path: url(#clip-path2-3)">
    <path d="M287.78,130.35a.5.5,0,0,0,.34,0,.42.42,0,0,0,.14-.09l5.33-5.14a.43.43,0,0,0,0-.61.45.45,0,0,0-.63,0l-4.57,4.41V115.81a.45.45,0,0,0-.89,0v13.11l-4.57-4.41a.44.44,0,0,0-.62,0,.39.39,0,0,0-.13.3.43.43,0,0,0,.13.31l5.32,5.14a.38.38,0,0,0,.15.09" style="fill: #005cb9"/>
  </g>
  <g>
    <path d="M78.14,73.58V60.24l-2,1.8v-1l2-1.74h.76V73.58Z" style="fill: #80c241"/>
    <path d="M82.9,73.58V73l3.32-8.14a8.08,8.08,0,0,0,.72-3.14c0-1.22-.68-1.82-1.54-1.82s-1.54.6-1.54,1.82v1H83.1v-1a2.48,2.48,0,0,1,.66-1.86,2.42,2.42,0,0,1,3.28,0,2.49,2.49,0,0,1,.66,1.9,9.52,9.52,0,0,1-.82,3.38L83.7,72.9h4v.68Z" style="fill: #80c241"/>
    <path d="M91.68,66.66a1.71,1.71,0,0,1-1.76-1.84V61a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,91.68,66.66ZM92.74,61c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56H91.7l5-14.24h.69Zm5,.16a1.71,1.71,0,0,1-1.75-1.84V68.1a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,97.36,73.74Zm1.07-5.64c0-.74-.36-1.22-1.07-1.22s-1,.48-1,1.22v3.8c0,.74.35,1.22,1,1.22s1.07-.48,1.07-1.22Z" style="fill: #80c241"/>
  </g>
  <g style="clip-path: url(#clip-path2-4)">
    <path d="M68.11,74a.5.5,0,0,0,.34,0,.45.45,0,0,0,.14-.1l5.33-5.14a.42.42,0,0,0,0-.6.45.45,0,0,0-.63,0l-4.57,4.41V59.48a.44.44,0,0,0-.88,0V72.59l-4.57-4.41a.45.45,0,0,0-.63,0,.41.41,0,0,0,0,.6L68,73.92a.3.3,0,0,0,.14.1" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M131.48,69.58V56.24l-2,1.8v-1l2-1.74h.76V69.58Z" style="fill: #80c241"/>
    <path d="M138.4,69.58V56.24l-2,1.8v-1l2-1.74h.76V69.58Z" style="fill: #80c241"/>
    <path d="M145,62.66a1.71,1.71,0,0,1-1.76-1.84V57a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,145,62.66ZM146.08,57c0-.74-.36-1.22-1.06-1.22S144,56.28,144,57v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56H145l5-14.24h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84V64.1a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,150.7,69.74Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #80c241"/>
  </g>
  <g style="clip-path: url(#clip-path2-5)">
    <path d="M121.44,70a.5.5,0,0,0,.34,0,.4.4,0,0,0,.15-.1l5.32-5.14a.4.4,0,0,0,0-.6.45.45,0,0,0-.63,0l-4.56,4.41V55.48a.45.45,0,0,0-.89,0V68.59l-4.57-4.41a.45.45,0,0,0-.63,0,.41.41,0,0,0,0,.6l5.33,5.14a.45.45,0,0,0,.14.1" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M187.14,97.25V83.9l-2,1.8v-1l2-1.74h.76V97.25Z" style="fill: #80c241"/>
    <path d="M192.94,97.25h-.84l3.84-13.57h-3.3v2.46h-.76V83h4.86v.6Z" style="fill: #80c241"/>
    <path d="M200.68,90.32a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,200.68,90.32Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.57h-.68l5-14.25h.69Zm5,.16a1.71,1.71,0,0,1-1.75-1.84V91.76a1.76,1.76,0,1,1,3.52,0v3.81A1.71,1.71,0,0,1,206.36,97.41Zm1.07-5.65c0-.74-.36-1.22-1.07-1.22s-1.05.48-1.05,1.22v3.81c0,.74.35,1.22,1.05,1.22s1.07-.48,1.07-1.22Z" style="fill: #80c241"/>
  </g>
  <g style="clip-path: url(#clip-path2-6)">
    <path d="M177.11,97.69a.5.5,0,0,0,.34,0,.71.71,0,0,0,.14-.1l5.33-5.14a.43.43,0,0,0,0-.61.47.47,0,0,0-.63,0l-4.57,4.41V83.15a.44.44,0,0,0-.88,0v13.1l-4.57-4.41a.47.47,0,0,0-.63,0,.43.43,0,0,0-.13.31.39.39,0,0,0,.13.3L177,97.59a.39.39,0,0,0,.14.1" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M240.14,96.91V83.57l-2,1.8v-1l2-1.74h.76V96.91Z" style="fill: #80c241"/>
    <path d="M248.94,96.41a2.37,2.37,0,0,1-3.28,0c-.58-.62-.74-1.28-.74-3.38s.14-2.62.54-3.16a2.23,2.23,0,0,1,.78-.62,2,2,0,0,1-.8-.72,4.3,4.3,0,0,1-.42-2.48c0-1.8.2-2.44.7-2.94a2.38,2.38,0,0,1,3.16,0c.5.5.7,1.14.7,2.94a4.3,4.3,0,0,1-.42,2.48,2,2,0,0,1-.8.72,2.23,2.23,0,0,1,.78.62c.4.54.54.92.54,3.16S249.52,95.79,248.94,96.41ZM248.36,90a1.5,1.5,0,0,0-2.12,0c-.44.46-.56.84-.56,3,0,1.9.16,2.46.56,2.92a1.5,1.5,0,0,0,2.12,0c.4-.46.56-1,.56-2.92C248.92,90.87,248.8,90.49,248.36,90Zm-.06-6.44a1.45,1.45,0,0,0-2,0c-.34.38-.52.94-.52,2.46s.16,2.08.54,2.48a1.45,1.45,0,0,0,2,0c.38-.4.54-1,.54-2.48S248.64,84,248.3,83.59Z" style="fill: #80c241"/>
    <path d="M253.68,90a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,253.68,90Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56h-.68l5-14.24h.69Zm5,.16a1.71,1.71,0,0,1-1.75-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,259.36,97.07Zm1.07-5.64c0-.74-.36-1.22-1.07-1.22s-1.05.48-1.05,1.22v3.8c0,.74.35,1.22,1.05,1.22s1.07-.48,1.07-1.22Z" style="fill: #80c241"/>
  </g>
  <g style="clip-path: url(#clip-path2-7)">
    <path d="M230.11,97.35a.5.5,0,0,0,.34,0,.42.42,0,0,0,.14-.09l5.33-5.14a.43.43,0,0,0,0-.61.45.45,0,0,0-.63,0l-4.57,4.41V82.81a.44.44,0,0,0-.88,0V95.92l-4.57-4.41a.45.45,0,0,0-.63,0,.39.39,0,0,0-.13.3.43.43,0,0,0,.13.31L230,97.26a.28.28,0,0,0,.14.09" style="fill: #82c341"/>
  </g>
  <g>
    <polygon points="321.6 115.23 319.27 117.2 321.63 119.19 323.96 117.22 321.6 115.23" style="fill: #005cb9"/>
    <path d="M321.27,117.21l.34-1,.33,1Zm.18-1.27-.71,2.14H321l.2-.66h.8l.21.66h.29l-.71-2.14Z" style="fill: #fff"/>
  </g>
</svg>
				<span class="footnote margin-top-20"><img src="../_images/scorecard/global/a.svg" class="aNote"> Reviewed by Ernst & Young LLP. Please refer to the <a href="../financials/index.php#review" class="link hideLinkMobile">Review Report</a><a href="../financials/nonfinancial.pdf" class="link mobileLinkOnly" target="_blank">Review Report</a>.</span>
			</div>
		</div>
		<div class="progressContent--4__tab progressContent--4__tab--4">
			<div class="progressContent--4__callout progressContent--4__callout--4">
				<img class="progressContent--4__target" src="../_images/strategy/growth/icon1.svg" alt="">
				<h4>2020 Goal</h4>
				<p>Reduce solid-<br>waste-to-landfill by <br>
					<span><img class="progressContent--4__arrow" src="../_images/strategy/growth/arrow.svg" alt="">20%</span> <br>
					per case of product sold <br>
					versus a 2011 calendar <br>
					year baseline.<sup>1</sup>
				</p>
				<h4>Results to Date</h4>
				<img class="progressContent--4__arrow" src="../_images/strategy/growth/arrow.svg" alt=""><span>33%</span>
			</div>

			<h2 class="progressContent__heading">Waste to Landfill Reductions <br>Surpass 2020 Goal</h2>

			<p>We exceeded our 2020 solid-waste-to-landfill goal just two years into our goal period, but we are still working to build on our progress. In 2017, a major construction project for the new Atlanta West plant and several capital equipment projects resulted in an increase in hard-to-recycle construction demolition and debris. Additionally, once-reliable markets for certain plastics recycling dried up, forcing us to send more material to landfill. Despite these temporary setbacks, we remain well ahead of our 20 percent reduction goal.</p>
			<p>As a company, we reused or recycled nearly 90 percent of nonsellable materials in 2017 and are identifying new opportunities to reduce solid-waste-to-landfill, such as the decision by our manufacturing site and distribution center in Mexico to send certain waste to a co-processing facility. With co-processing, waste is used for energy, and the residual material is used as a raw material for a concrete mix. We also made progress toward our goal of 10 zero-waste-to-landfill sites by 2020, bringing the total number to eight.</p>
			<p class="footnote footnote--progress"><sup>1</sup> Calendar year 2011 baseline value for solid-waste-to-landfill has been restated to reflect: 1) the removal from the baseline of waste volumes attributed to the Aplicare business, divested by Clorox in calendar year 2017, and 2) the addition of the previously excluded waste stream, cafeteria waste sludge, to the landfill waste volume at our Lima, Peru, manufacturing facility.</p>

			<img src="../_images/strategy/growth/progress4.jpg" alt="" class="progressContent--4__image progressContent--4__image--5">

			<div class="progressContent--4__chart progressContent--4__chart--3">
				<h4>Zero-Waste-to-Landfill Sites <br><span>(annual progress versus 2011 base year):</span></h4>
				<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 295.5 295.8" enable-background="new 0 0 295.5 295.8" xml:space="preserve" class="growthChart--3">
<g id="Layer_1">
	<g>
		<g id="Layer_2_1_">
			<g>
				<path fill="#82C341" stroke="#FFFFFF" stroke-miterlimit="10" d="M147.8,147.9L175.9,3.4c31.9,6.2,57.4,20.3,79.5,44.1
					L147.8,147.9z"/>
				<path fill="#82C341" stroke="#FFFFFF" stroke-miterlimit="10" d="M147.8,147.9L85.6,14.5C115,0.8,143.9-2.8,175.9,3.4
					L147.8,147.9z"/>
				<path fill="#D0D2D3" stroke="#FFFFFF" stroke-miterlimit="10" d="M147.8,147.9L19.1,76.5c15.8-28.4,37-48.3,66.5-62L147.8,147.9
					z"/>
				<path fill="#D0D2D3" stroke="#FFFFFF" stroke-miterlimit="10" d="M147.8,147.9l-146,17.9c-4-32.3,1.6-60.8,17.4-89.3
					L147.8,147.9z"/>
				<path fill="#82C341" stroke="#FFFFFF" stroke-miterlimit="10" d="M147.8,147.9L40.2,248.2C18,224.4,5.7,198.1,1.7,165.8
					L147.8,147.9z"/>
				<path fill="#82C341" stroke="#FFFFFF" stroke-miterlimit="10" d="M147.8,147.9l-28.1,144.4c-31.9-6.2-57.4-20.3-79.5-44.1
					L147.8,147.9z"/>
				<path fill="#82C341" stroke="#FFFFFF" stroke-miterlimit="10" d="M147.8,147.9L210,281.2c-29.5,13.8-58.4,17.3-90.3,11.1
					L147.8,147.9z"/>
				<path fill="#82C341" stroke="#FFFFFF" stroke-miterlimit="10" d="M147.8,147.9l128.7,71.3c-15.8,28.4-37,48.3-66.5,62
					L147.8,147.9z"/>
				<path fill="#82C341" stroke="#FFFFFF" stroke-miterlimit="10" d="M147.8,147.9l146-17.9c4,32.3-1.6,60.8-17.4,89.3L147.8,147.9z
					"/>
				<path fill="#82C341" stroke="#FFFFFF" stroke-miterlimit="10" d="M147.8,147.9L255.4,47.5c22.2,23.8,34.5,50.2,38.4,82.4
					L147.8,147.9z"/>
			</g>
			<circle fill="#FFFFFF" cx="147.3" cy="147.5" r="133.3"/>
			<g id="text" class='text'>
				<g>
					<path fill="#929497" d="M84.1,214.6V183l-5.8,4.4V181l5.8-4.6h5.7v38.3L84.1,214.6z"/>
					<path fill="#929497" d="M113,212.7c-1.7,1.5-3.8,2.3-6.1,2.3c-2.3,0.1-4.5-0.7-6.1-2.3c-1.7-1.6-2.6-4-2.4-6.3v-21.9
						c-0.2-2.4,0.7-4.7,2.4-6.4c1.7-1.5,3.9-2.3,6.1-2.2c2.2-0.1,4.4,0.7,6.1,2.2c1.7,1.7,2.6,4,2.4,6.4v21.9
						C115.6,208.8,114.7,211.1,113,212.7z M109.7,184.2c0-2.2-1.2-3.3-2.8-3.3s-2.8,1.1-2.8,3.3v22.4c0,2.2,1.3,3.3,2.8,3.3
						s2.8-1.1,2.8-3.3V184.2z"/>
					<path fill="#929497" d="M146.6,212.4c-1.6,1.5-4.1,2.5-7.5,2.5s-5.8-0.9-7.4-2.5c-1.8-1.8-2.5-4.2-2.5-8.2h6
						c0,2,0.2,3.3,1.1,4.3c0.7,0.7,1.8,1.1,2.8,1c1.1,0.1,2.2-0.3,2.9-1.1c0.8-0.9,1-2.2,1-4.2c0-4.1-0.6-5.1-3.6-6.3l-4.5-1.9
						c-3.9-1.6-5.3-3.7-5.3-9.6c0-3.4,1-6.2,3.1-8.1c1.8-1.6,4.2-2.4,6.6-2.3c3.1,0,5.3,0.8,6.9,2.3c2,1.9,2.7,4.7,2.7,8.3h-6
						c0-1.7-0.1-3.1-0.9-4.1c-1.4-1.5-3.7-1.5-5.2-0.1c0,0,0,0-0.1,0.1c-0.8,1.1-1.1,2.4-1,3.8c0,3.1,0.5,4.1,3.2,5.2l4.5,1.8
						c4.6,1.8,5.8,4.3,5.8,10.8C149,207.9,148.5,210.5,146.6,212.4z"/>
					<path fill="#929497" d="M154.3,214.6v-38.3h6v38.3H154.3z"/>
					<path fill="#929497" d="M177.1,181.7v32.8h-6v-32.8h-6.4v-5.4h18.9v5.4H177.1z"/>
					<path fill="#929497" d="M187.9,214.6v-38.3H204v5.4h-10.1v10.9h8.6v5.4h-8.6v11.1H204v5.4H187.9z"/>
					<path fill="#929497" d="M225.2,212.4c-1.6,1.5-4.1,2.5-7.5,2.5s-5.8-0.9-7.4-2.5c-1.8-1.8-2.5-4.2-2.5-8.2h6
						c0,2,0.2,3.3,1.1,4.3c0.7,0.7,1.8,1.1,2.8,1c1.1,0.1,2.2-0.3,2.9-1.1c0.8-0.9,1-2.2,1-4.2c0-4.1-0.6-5.1-3.6-6.3l-4.5-1.9
						c-3.9-1.6-5.3-3.7-5.3-9.6c0-3.4,1-6.2,3.1-8.1c1.8-1.6,4.2-2.4,6.6-2.3c3.1,0,5.3,0.8,6.9,2.3c2,1.9,2.7,4.7,2.7,8.3h-6
						c0-1.7-0.1-3.1-0.9-4.1c-0.7-0.8-1.7-1.2-2.7-1.1c-1-0.1-1.9,0.3-2.6,1.1c-0.8,1.1-1.1,2.4-1,3.8c0,3.1,0.5,4.1,3.2,5.2
						l4.5,1.8c4.6,1.8,5.8,4.3,5.8,10.8C227.7,207.9,227.2,210.5,225.2,212.4z"/>
				</g>
				<g>
					<path fill="#82C341" d="M91.5,135.5c-1.7,1.5-3.8,2.3-6.1,2.3c-2.3,0.1-4.5-0.7-6.1-2.3c-2.2-2.3-2.5-4.8-2.5-9
						c0-3.2,0.2-5.1,1.1-6.8c0.5-1,1.3-1.8,2.2-2.4c-0.9-0.6-1.6-1.4-2.1-2.3c-0.9-1.7-1-3.3-1-6c0-3.7,0.5-6.2,2.5-8.2
						c1.6-1.5,3.7-2.3,5.9-2.2c2.2-0.1,4.3,0.7,5.9,2.2c1.9,1.9,2.5,4.5,2.5,8.2c0,2.6-0.2,4.3-1,6c-0.5,0.9-1.2,1.8-2.1,2.4
						c0.9,0.6,1.7,1.5,2.2,2.4c0.9,1.7,1.1,3.6,1.1,6.8C94,130.7,93.7,133.2,91.5,135.5z M87.5,120.6c-0.5-0.6-1.2-0.9-2-0.9
						c-0.8,0-1.6,0.3-2.1,0.9c-0.9,1.1-0.9,3.2-0.9,5.6c0,2.2,0,4.4,0.9,5.5c0.5,0.6,1.3,0.9,2.1,0.9c0.8,0,1.5-0.3,2-0.9
						c0.9-1.1,0.9-3.3,0.9-5.5C88.3,123.8,88.4,121.7,87.5,120.6L87.5,120.6z M87.3,104.5c-0.5-0.5-1.1-0.8-1.8-0.8
						c-0.7-0.1-1.4,0.2-1.9,0.8c-0.8,1-0.8,3-0.8,4.8s0,4,1,5c1,0.9,2.5,0.9,3.4,0c1-1,0.9-3.1,0.9-5S88,105.5,87.3,104.5
						L87.3,104.5z"/>
					<path fill="#82C341" d="M125,135.2c-1.6,1.5-4.1,2.5-7.5,2.5s-5.8-0.9-7.4-2.5c-1.8-1.8-2.5-4.2-2.5-8.2h6c0,2,0.2,3.3,1.1,4.3
						c0.7,0.7,1.8,1.1,2.8,1c1.1,0.1,2.1-0.3,2.9-1.1c0.8-0.9,1-2.2,1-4.2c0-4.1-0.6-5-3.6-6.3l-4.6-1.9c-3.9-1.6-5.3-3.7-5.3-9.6
						c0-3.4,1-6.2,3.1-8.1c1.8-1.6,4.2-2.4,6.6-2.3c3.1,0,5.3,0.8,6.9,2.3c2,1.9,2.7,4.7,2.7,8.3h-6c0-1.7-0.1-3.1-0.9-4.1
						c-0.7-0.8-1.7-1.2-2.7-1.1c-1-0.1-1.9,0.3-2.6,1.1c-0.8,1.1-1.1,2.4-1,3.8c0,3.1,0.5,4.1,3.2,5.2l4.5,1.8
						c4.6,1.8,5.8,4.3,5.8,10.8C127.5,130.7,126.9,133.3,125,135.2z"/>
					<path fill="#82C341" d="M132.8,137.3V99.1h6v38.3H132.8z"/>
					<path fill="#82C341" d="M155.5,104.5v32.8h-6v-32.8h-6.4v-5.4H162v5.4H155.5z"/>
					<path fill="#82C341" d="M166.4,137.3V99.1h16.1v5.4h-10v10.9h8.6v5.4h-8.7v11.1h10v5.4L166.4,137.3z"/>
					<path fill="#82C341" d="M203.7,135.2c-1.6,1.5-4.1,2.5-7.5,2.5s-5.8-0.9-7.4-2.5c-1.8-1.8-2.5-4.2-2.5-8.2h6
						c0,2,0.2,3.3,1.1,4.3c0.7,0.7,1.8,1.1,2.8,1c1.1,0.1,2.1-0.3,2.9-1.1c0.8-0.9,1-2.2,1-4.2c0-4.1-0.6-5-3.6-6.3l-4.6-1.9
						c-3.9-1.6-5.3-3.7-5.3-9.6c0-3.4,1-6.2,3.1-8.1c1.8-1.6,4.2-2.4,6.6-2.3c3.1,0,5.3,0.8,6.9,2.3c2,1.9,2.7,4.7,2.7,8.3h-6
						c0-1.7-0.1-3.1-0.9-4.1c-0.7-0.8-1.7-1.2-2.7-1.1c-1-0.1-1.9,0.3-2.6,1.1c-0.8,1.1-1.1,2.4-1,3.8c0,3.1,0.5,4.1,3.2,5.2
						l4.5,1.8c4.6,1.8,5.8,4.3,5.8,10.8C206.1,130.7,205.6,133.3,203.7,135.2z"/>
				</g>
				<g>
					<path fill="#929497" d="M75.6,171.4v-2l4-7.7c0.4-0.9,0.7-1.9,0.7-2.9c0-0.9-0.5-1.4-1.1-1.4c-0.7,0-1.2,0.5-1.2,1.2
						c0,0.1,0,0.1,0,0.2v1h-2.4v-0.9c-0.1-1,0.3-2,1-2.6c0.7-0.6,1.6-1,2.6-0.9c0.9,0,1.8,0.3,2.5,0.9c0.7,0.7,1.1,1.7,1,2.8
						c0,1.2-0.3,2.4-0.9,3.5l-3.6,6.9h4.5v2.1L75.6,171.4z"/>
					<path fill="#929497" d="M90.6,170.6c-1.5,1.3-3.6,1.3-5.1,0c-0.7-0.7-1.1-1.7-1-2.6v-9.1c-0.1-1,0.3-2,1-2.6
						c1.5-1.3,3.6-1.3,5.1,0c0.7,0.7,1.1,1.7,1,2.6v9.2C91.7,169,91.3,169.9,90.6,170.6z M89.2,158.8c0-0.9-0.5-1.4-1.2-1.4
						c-0.7,0-1.2,0.5-1.2,1.2c0,0.1,0,0.1,0,0.2v9.3c-0.1,0.7,0.4,1.3,1,1.4c0.1,0,0.1,0,0.2,0c0.7,0,1.2-0.4,1.2-1.4V158.8z"/>
					<path fill="#929497" d="M93.6,171.4v-2l4-7.7c0.4-0.9,0.7-1.9,0.7-2.9c0-0.9-0.5-1.4-1.1-1.4c-0.7,0-1.2,0.5-1.2,1.2
						c0,0.1,0,0.1,0,0.2v1h-2.4v-0.9c-0.1-1,0.3-2,1-2.6c0.7-0.6,1.6-1,2.6-0.9c0.9,0,1.8,0.3,2.5,0.9c0.7,0.7,1.1,1.7,1,2.8
						c0,1.2-0.3,2.4-0.9,3.5l-3.6,6.9h4.5v2.1L93.6,171.4z"/>
					<path fill="#929497" d="M108.5,170.6c-1.5,1.3-3.6,1.3-5.1,0c-0.7-0.7-1.1-1.7-1-2.6v-9.1c-0.1-1,0.3-2,1-2.6
						c1.5-1.3,3.6-1.3,5.1,0c0.7,0.7,1.1,1.7,1,2.6v9.2C109.6,169,109.3,169.9,108.5,170.6z M107.2,158.8c0-0.9-0.5-1.4-1.2-1.4
						c-0.7,0-1.2,0.5-1.2,1.2c0,0.1,0,0.1,0,0.2v9.3c-0.1,0.7,0.4,1.3,1,1.4c0.1,0,0.1,0,0.2,0c0.7,0,1.2-0.4,1.2-1.4V158.8z"/>
					<path fill="#929497" d="M119.7,171.6c-1.2,0.1-2.3-0.4-3.1-1.3c-1.2-1.3-1.2-3.7-1.2-6.8s0-5.5,1.2-6.8
						c0.8-0.9,1.9-1.4,3.1-1.3c1.1,0,2.1,0.3,2.8,1.1c0.8,0.9,1.3,2.1,1.2,3.3h-2.5c0-0.9-0.2-2.1-1.6-2.1c-0.5,0-0.9,0.2-1.2,0.6
						c-0.5,0.8-0.6,2.4-0.6,5.3s0.1,4.5,0.6,5.3c0.3,0.4,0.7,0.6,1.2,0.6c1.1,0,1.6-0.9,1.6-2v-2.5h-1.6v-2.1h4.1v4.4
						C123.7,170,122,171.6,119.7,171.6z"/>
					<path fill="#929497" d="M132.9,170.2c-1.6,1.7-4.3,1.8-6,0.2c-0.1-0.1-0.1-0.1-0.2-0.2c-1.2-1.3-1.2-3.7-1.2-6.8s0-5.5,1.2-6.8
						c1.6-1.7,4.3-1.8,6-0.2c0.1,0.1,0.1,0.1,0.2,0.2c1.2,1.3,1.2,3.7,1.2,6.8S134.1,168.9,132.9,170.2z M131,158.1
						c-0.3-0.4-0.7-0.6-1.2-0.6c-0.5,0-0.9,0.2-1.2,0.6c-0.5,0.8-0.6,2.4-0.6,5.3s0.1,4.5,0.6,5.3c0.2,0.4,0.7,0.6,1.2,0.6
						c0.5,0,0.9-0.2,1.2-0.6c0.5-0.8,0.5-2.4,0.5-5.3S131.5,158.9,131,158.1z"/>
					<path fill="#929497" d="M142.7,171.4l-0.6-3.2h-3.7l-0.6,3.2h-2.6l3.9-15.9h2.4l3.9,15.9H142.7z M140.3,159.3l-1.4,6.7h2.7
						L140.3,159.3z"/>
					<path fill="#929497" d="M146.8,171.4v-15.9h2.5v13.7h4.2v2.3H146.8z"/>
				</g>
				<g>
					<path fill="#82C341" d="M81.9,93.3l-2.1-6.5h-1.4v6.5h-2.5V77.3h4c2.9,0,4.1,1.4,4.1,4.7c0,2-0.4,3.4-1.9,4.2l2.4,7.1H81.9z
						 M80,79.6h-1.6v4.9H80c1.3,0,1.6-1.1,1.6-2.4S81.3,79.6,80,79.6z"/>
					<path fill="#82C341" d="M86.6,93.3V77.3h6.7v2.3h-4.2v4.5h3.6v2.3h-3.6V91h4.2v2.3L86.6,93.3z"/>
					<path fill="#82C341" d="M102.2,92.4c-0.9,0.7-2,1.1-3.2,1.1c-1.1,0.1-2.2-0.3-3-1.1c-0.8-0.8-1-1.8-1-3.4h2.5
						c-0.1,0.6,0.1,1.3,0.4,1.8c0.7,0.6,1.7,0.6,2.4,0c0.3-0.5,0.5-1.1,0.4-1.8c0-1.7-0.3-2.1-1.5-2.6l-1.9-0.8
						c-1.6-0.7-2.2-1.6-2.2-4c-0.1-1.3,0.4-2.5,1.3-3.4c0.8-0.7,1.7-1,2.7-1c1.1-0.1,2.1,0.3,2.9,1c0.8,1,1.2,2.2,1.1,3.5h-2.5
						c0.1-0.6-0.1-1.2-0.4-1.7c-0.6-0.6-1.6-0.6-2.2,0c0,0,0,0,0,0c-0.3,0.5-0.5,1-0.4,1.6c0,1.3,0.2,1.7,1.3,2.2l1.9,0.8
						c1.9,0.8,2.4,1.8,2.4,4.5C103.2,90.5,103,91.6,102.2,92.4z"/>
					<path fill="#82C341" d="M112.3,92.3c-0.8,0.8-1.9,1.2-3,1.2c-1.1,0-2.2-0.4-3-1.2c-0.7-0.8-1.1-1.9-1.1-2.9v-12h2.5v12.1
						c-0.1,0.9,0.6,1.6,1.4,1.7s1.6-0.6,1.7-1.4c0-0.1,0-0.2,0-0.2V77.3h2.5v12C113.4,90.4,113,91.5,112.3,92.3z"/>
					<path fill="#82C341" d="M115.9,93.3V77.3h2.5V91h4.2v2.3L115.9,93.3z"/>
					<path fill="#82C341" d="M128.8,79.6v13.7h-2.5V79.6h-2.7v-2.3h7.9v2.3L128.8,79.6z"/>
					<path fill="#82C341" d="M140,92.4c-0.9,0.7-2,1.1-3.1,1.1c-1.1,0.1-2.2-0.3-3.1-1.1c-0.8-0.8-1-1.8-1-3.4h2.5
						c-0.1,0.6,0.1,1.3,0.4,1.8c0.7,0.6,1.7,0.6,2.4,0c0.3-0.5,0.5-1.1,0.4-1.8c0-1.7-0.3-2.1-1.5-2.6l-1.9-0.8
						c-1.6-0.7-2.2-1.6-2.2-4c-0.1-1.3,0.4-2.5,1.3-3.4c0.8-0.7,1.7-1,2.7-1c1.1-0.1,2.1,0.3,2.9,1c0.8,1,1.2,2.2,1.1,3.5h-2.5
						c0.1-0.6-0.1-1.2-0.4-1.7c-0.6-0.6-1.6-0.6-2.2,0c0,0,0,0,0,0c-0.3,0.5-0.5,1-0.4,1.6c0,1.3,0.2,1.7,1.3,2.2l1.9,0.8
						c1.9,0.8,2.4,1.8,2.4,4.5C141,90.5,140.8,91.6,140,92.4z"/>
					<path fill="#82C341" d="M151.5,79.6v13.7H149V79.6h-2.7v-2.3h7.9v2.3L151.5,79.6z"/>
					<path fill="#82C341" d="M162.9,92.1c-1.6,1.7-4.3,1.8-6,0.2c-0.1-0.1-0.1-0.1-0.2-0.2c-1.2-1.3-1.2-3.7-1.2-6.8s0-5.5,1.2-6.8
						c1.6-1.7,4.2-1.8,5.9-0.2c0.1,0.1,0.2,0.2,0.2,0.2c1.2,1.3,1.2,3.7,1.2,6.8S164.1,90.8,162.9,92.1z M161,80
						c-0.3-0.4-0.7-0.6-1.2-0.6c-0.5,0-0.9,0.2-1.2,0.6c-0.5,0.8-0.6,2.4-0.6,5.3s0.1,4.5,0.6,5.3c0.3,0.4,0.7,0.6,1.2,0.6
						c0.5,0,0.9-0.2,1.2-0.6c0.5-0.8,0.5-2.4,0.5-5.3S161.5,80.8,161,80z"/>
					<path fill="#82C341" d="M177.5,92c-0.8,0.9-1.9,1.4-3.1,1.3h-4.1v-16h4.1c1.2-0.1,2.3,0.4,3.1,1.3c1.2,1.3,1.2,3.6,1.2,6.7
						S178.7,90.6,177.5,92z M175.6,80.3c-0.3-0.4-0.8-0.7-1.3-0.7h-1.5V91h1.5c0.5,0,1-0.2,1.3-0.7c0.5-0.7,0.5-2.3,0.5-5.1
						S176.1,81,175.6,80.3L175.6,80.3z"/>
					<path fill="#82C341" d="M187.3,93.3l-0.6-3.2h-3.7l-0.6,3.2h-2.6l3.9-15.9h2.4l3.9,15.9H187.3z M184.8,81.2l-1.4,6.7h2.7
						L184.8,81.2z"/>
					<path fill="#82C341" d="M195.7,79.6v13.7h-2.5V79.6h-2.7v-2.3h7.9v2.3L195.7,79.6z"/>
					<path fill="#82C341" d="M200.2,93.3V77.3h6.7v2.3h-4.2v4.5h3.6v2.3h-3.6V91h4.2v2.3L200.2,93.3z"/>
				</g>
			</g>
		</g>
	</g>
</g>
<g id="mask">
	<circle class="mask" fill="none" stroke="#FFFFFF" stroke-width="30" stroke-miterlimit="10" cx="147.1" cy="148" r="133"/>
</g>
</svg>
			</div>
			<div class="progressContent--4__chart progressContent--4__chart--4">
				<h4>Solid-Waste-to-Landfill <br><span>(annual progress versus 2011 base year):</span></h4>
				<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="412.04" height="124.73" viewBox="0 0 412.04 124.73" class="growthChart--4">
  <defs>
    <clipPath id="clip-path4">
      <rect x="328.92" y="37.2" width="22.21" height="28.87" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path4-2">
      <rect x="7.84" y="24.05" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path4-3">
      <rect x="282.18" y="93.38" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path4-4">
      <rect x="62.51" y="93.13" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path4-5">
      <rect x="115.84" y="88.05" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path4-6">
      <rect x="170.09" y="79.13" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path4-7">
      <rect x="224.51" y="105.88" width="11.54" height="15" style="fill: none"/>
    </clipPath>
  </defs>
  <title>chart4</title>
  <line x1="0.5" y1="67.25" x2="329.9" y2="67.25" style="fill: none;stroke: #929497;stroke-linecap: round;stroke-linejoin: round"/>


  <g>
    <path d="M352.85,66.3V62.63l7.27-14.13a11.37,11.37,0,0,0,1.18-5.19c0-1.67-.9-2.53-2.08-2.53a2.18,2.18,0,0,0-2.17,2.49v1.88h-4.32V43.44a6.1,6.1,0,0,1,1.79-4.82,7,7,0,0,1,4.7-1.72,6.32,6.32,0,0,1,4.49,1.56,6.56,6.56,0,0,1,1.92,5A14.85,14.85,0,0,1,364,49.85l-6.58,12.57h8.17V66.3Z" style="fill: #929497"/>
    <path d="M380.12,64.91a6.58,6.58,0,0,1-4.61,1.72,6.72,6.72,0,0,1-4.66-1.72A6.11,6.11,0,0,1,369,60.1V43.44a6.12,6.12,0,0,1,1.83-4.82,6.77,6.77,0,0,1,4.66-1.72,6.63,6.63,0,0,1,4.61,1.72A6.09,6.09,0,0,1,382,43.44V60.1A6.08,6.08,0,0,1,380.12,64.91Zm-2.49-21.64c0-1.67-.94-2.49-2.12-2.49a2.18,2.18,0,0,0-2.16,2.49v17a2.18,2.18,0,0,0,2.16,2.49c1.18,0,2.12-.82,2.12-2.49Z" style="fill: #929497"/>
    <path d="M390.78,52.13c-2.78,0-5.18-1.67-5.18-4.9V41.8c0-3.22,2.4-4.9,5.18-4.9S396,38.58,396,41.8v5.43C396,50.46,393.56,52.13,390.78,52.13Zm1.64-10.25c0-1.26-.66-1.83-1.64-1.83s-1.67.57-1.67,1.83v5.27c0,1.27.69,1.84,1.67,1.84s1.64-.57,1.64-1.84Zm2.85,24.42h-3.35l10.13-29.07h3.35Zm11.19.33c-2.78,0-5.18-1.67-5.18-4.9V56.3c0-3.23,2.4-4.9,5.18-4.9s5.19,1.67,5.19,4.9v5.43C411.65,65,409.24,66.63,406.46,66.63Zm1.63-10.25c0-1.27-.65-1.84-1.63-1.84s-1.63.57-1.63,1.84v5.27c0,1.26.65,1.84,1.63,1.84s1.63-.58,1.63-1.84Z" style="fill: #929497"/>
  </g>
  <g>
    <path d="M358.62,31.29a2.34,2.34,0,0,1-1.61.56,2.28,2.28,0,0,1-1.73-.69c-.73-.78-.81-1.69-.81-5.25s.08-4.48.81-5.26A2.28,2.28,0,0,1,357,20a2.25,2.25,0,0,1,1.67.62,3.06,3.06,0,0,1,.75,2.17h-1a2.29,2.29,0,0,0-.46-1.53,1.3,1.3,0,0,0-1-.39,1.26,1.26,0,0,0-1,.42c-.48.57-.56,1.24-.56,4.66s.08,4.08.56,4.65a1.46,1.46,0,0,0,2,0,2.25,2.25,0,0,0,.46-1.53h1A3,3,0,0,1,358.62,31.29Z" style="fill: #929497"/>
    <path d="M363.16,26.85v4.87h-1V26.85l-2-6.76h1.06l1.46,5.33,1.47-5.33h1.06Z" style="fill: #929497"/>
    <path d="M366.08,31.72V31l2.78-6.37a6.12,6.12,0,0,0,.55-2.45c0-.91-.5-1.35-1.14-1.35s-1.16.44-1.16,1.35V23h-.92v-.82a2.1,2.1,0,0,1,.59-1.61,2.15,2.15,0,0,1,1.49-.58,2.08,2.08,0,0,1,1.45.56,2.19,2.19,0,0,1,.61,1.66,7.4,7.4,0,0,1-.67,2.7l-2.6,6h3.27v.82Z" style="fill: #929497"/>
    <path d="M375.57,31.28a2.19,2.19,0,0,1-1.49.57A2,2,0,0,1,372,29.63V22.18A2,2,0,0,1,374.08,20a2.15,2.15,0,0,1,1.49.58,2.12,2.12,0,0,1,.59,1.64v7.45A2.16,2.16,0,0,1,375.57,31.28Zm-.33-9.15c0-.91-.52-1.35-1.16-1.35s-1.14.44-1.14,1.35v7.55c0,.91.51,1.35,1.14,1.35s1.16-.44,1.16-1.35Z" style="fill: #929497"/>
  </g>
  <g>
    <path d="M385.46,32.64a2.88,2.88,0,0,1-2.34-1c-.9-1-.89-2.78-.89-5.16s0-4.15.89-5.17a2.88,2.88,0,0,1,2.34-1,2.93,2.93,0,0,1,2.16.81,3.76,3.76,0,0,1,.94,2.54h-1.91c0-.68-.17-1.64-1.19-1.64a1,1,0,0,0-.9.46c-.35.58-.42,1.81-.42,4s.07,3.43.42,4a1,1,0,0,0,.9.46c.82,0,1.19-.72,1.19-1.55V27.49h-1.19V25.93h3.1v3.35C388.56,31.47,387.27,32.64,385.46,32.64Z" style="fill: #929497"/>
    <path d="M395.54,31.62a3.21,3.21,0,0,1-4.69,0c-.9-1-.88-2.78-.88-5.16s0-4.15.88-5.17a3.21,3.21,0,0,1,4.69,0c.9,1,.89,2.79.89,5.17S396.44,30.6,395.54,31.62Zm-1.42-9.18a1,1,0,0,0-.92-.46,1,1,0,0,0-.9.46c-.36.58-.43,1.81-.43,4s.07,3.43.43,4a1,1,0,0,0,.9.46,1,1,0,0,0,.92-.46c.35-.58.4-1.8.4-4S394.47,23,394.12,22.44Z" style="fill: #929497"/>
    <path d="M403,32.51l-.49-2.4h-2.81l-.47,2.4h-2l3-12.11H402L405,32.51Zm-1.89-9.18-1,5.06h2.07Z" style="fill: #929497"/>
    <path d="M406.1,32.51V20.4H408V30.79h3.18v1.72Z" style="fill: #929497"/>
  </g>
  <g>
    <path d="M23.48,38.58V25.24l-2,1.8v-1l2-1.74h.76V38.58Z" style="fill: #80c241"/>
    <path d="M30.1,31.66a1.71,1.71,0,0,1-1.76-1.84V26a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,30.1,31.66ZM31.16,26c0-.74-.36-1.22-1.06-1.22S29,25.28,29,26v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22ZM30.8,38.58h-.68l5-14.24h.68Zm5,.16A1.71,1.71,0,0,1,34,36.9V33.1a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,35.78,38.74Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #80c241"/>
  </g>
  <g>
    <path d="M26.33,7.25a1.18,1.18,0,0,1-.88.31,1.23,1.23,0,0,1-1-.41c-.4-.43-.42-1.08-.42-2.5s0-2.07.42-2.5a1.23,1.23,0,0,1,1-.41,1.28,1.28,0,0,1,.91.33,1.6,1.6,0,0,1,.4,1.14h-.68a1.07,1.07,0,0,0-.18-.66.54.54,0,0,0-.45-.2.53.53,0,0,0-.46.22c-.2.27-.24.73-.24,2.08s0,1.81.24,2.08a.52.52,0,0,0,.46.21.54.54,0,0,0,.45-.2,1,1,0,0,0,.18-.65h.69A1.61,1.61,0,0,1,26.33,7.25Z" style="fill: #82c341"/>
    <path d="M28.82,5.19V7.5h-.69V5.19L27.08,1.8h.76l.64,2.43.64-2.43h.76Z" style="fill: #82c341"/>
    <path d="M31.26,7.5V2.56l-.83.68V2.49l.83-.69h.65V7.5Z" style="fill: #82c341"/>
    <path d="M33.33,7.5V7L34.72,4A2.58,2.58,0,0,0,35,2.9c0-.39-.22-.58-.49-.58S34,2.51,34,2.9v.38h-.65V2.91A1.14,1.14,0,0,1,33.67,2a1.21,1.21,0,0,1,.82-.3,1.11,1.11,0,0,1,.8.29,1.16,1.16,0,0,1,.34.89,3.2,3.2,0,0,1-.33,1.29L34,6.91h1.6V7.5Z" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M298.92,6.6a1.2,1.2,0,0,1-.88.31,1.21,1.21,0,0,1-1-.41c-.4-.43-.42-1.07-.42-2.5s0-2.07.42-2.5a1.36,1.36,0,0,1,1.87-.07,1.56,1.56,0,0,1,.41,1.13h-.68a1,1,0,0,0-.18-.65.54.54,0,0,0-.45-.2.55.55,0,0,0-.46.21c-.2.28-.24.73-.24,2.08s0,1.81.24,2.08a.53.53,0,0,0,.46.22.54.54,0,0,0,.45-.21,1,1,0,0,0,.18-.65h.69A1.61,1.61,0,0,1,298.92,6.6Z" style="fill: #005cb9"/>
    <path d="M301.41,4.55v2.3h-.69V4.55l-1.05-3.39h.76l.64,2.43.64-2.43h.75Z" style="fill: #005cb9"/>
    <path d="M303.85,6.85V1.92L303,2.6V1.84l.83-.68h.65V6.85Z" style="fill: #005cb9"/>
    <path d="M306.74,6.85h-.66l1.5-5.11h-1.1v.84h-.63V1.16h2.39v.53Z" style="fill: #005cb9"/>
  </g>
  <g>
    <path d="M79.61,6.6a1.21,1.21,0,0,1-.88.31,1.25,1.25,0,0,1-1-.41c-.39-.43-.41-1.08-.41-2.5s0-2.07.41-2.5a1.25,1.25,0,0,1,1-.41,1.21,1.21,0,0,1,.9.34A1.6,1.6,0,0,1,80,2.56h-.69a1,1,0,0,0-.18-.65.52.52,0,0,0-.44-.2.54.54,0,0,0-.47.21c-.2.27-.24.73-.24,2.08s0,1.81.24,2.08a.55.55,0,0,0,.47.22.52.52,0,0,0,.44-.21,1,1,0,0,0,.19-.65h.69A1.61,1.61,0,0,1,79.61,6.6Z" style="fill: #82c341"/>
    <path d="M82.09,4.55v2.3h-.68V4.55l-1-3.39h.75l.64,2.43.64-2.43h.76Z" style="fill: #82c341"/>
    <path d="M84.54,6.85V1.92l-.84.67V1.84l.84-.68h.64V6.85Z" style="fill: #82c341"/>
    <path d="M88.53,6.61a1.17,1.17,0,0,1-.81.3,1.21,1.21,0,0,1-.82-.3,1.12,1.12,0,0,1-.32-.87V5.37h.64v.38c0,.39.23.58.5.58a.46.46,0,0,0,.35-.15c.14-.16.17-.46.17-1s0-.8-.17-1a.43.43,0,0,0-.35-.16h-.3V3.55h.3A.42.42,0,0,0,88,3.42c.14-.15.16-.41.16-.82a1.28,1.28,0,0,0-.14-.79.42.42,0,0,0-.33-.14c-.26,0-.46.19-.46.56v.4h-.64V2.27a1.14,1.14,0,0,1,.31-.88,1.14,1.14,0,0,1,.79-.3,1.08,1.08,0,0,1,.78.29,1.54,1.54,0,0,1,.34,1.18,1.91,1.91,0,0,1-.15.94,1,1,0,0,1-.32.32,1,1,0,0,1,.32.31,1.87,1.87,0,0,1,.2,1.12C88.89,5.94,88.85,6.3,88.53,6.61Z" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M133.68,6.6a1.18,1.18,0,0,1-.88.31,1.23,1.23,0,0,1-1-.41c-.39-.43-.42-1.08-.42-2.5s0-2.07.42-2.5a1.37,1.37,0,0,1,1.88-.07,1.6,1.6,0,0,1,.41,1.13h-.69a1,1,0,0,0-.18-.65.52.52,0,0,0-.45-.2.54.54,0,0,0-.46.21c-.2.27-.24.73-.24,2.08s0,1.81.24,2.08a.54.54,0,0,0,.46.22.53.53,0,0,0,.45-.21,1,1,0,0,0,.19-.65h.68A1.57,1.57,0,0,1,133.68,6.6Z" style="fill: #82c341"/>
    <path d="M136.17,4.55v2.3h-.69V4.55l-1-3.39h.75l.64,2.43.64-2.43h.76Z" style="fill: #82c341"/>
    <path d="M138.61,6.85V1.92l-.83.67V1.84l.83-.68h.65V6.85Z" style="fill: #82c341"/>
    <path d="M142.72,5.91v.94h-.65V5.91h-1.54V5.33L142,1.16h.62l-1.41,4.17h.88V4h.65v1.3h.4v.58Z" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M188.92,6.6a1.2,1.2,0,0,1-.88.31,1.21,1.21,0,0,1-1-.41c-.4-.43-.42-1.08-.42-2.5s0-2.07.42-2.5a1.36,1.36,0,0,1,1.87-.07,1.56,1.56,0,0,1,.41,1.13h-.69a1,1,0,0,0-.17-.65.54.54,0,0,0-.45-.2.52.52,0,0,0-.46.21c-.2.27-.24.73-.24,2.08s0,1.81.24,2.08a.53.53,0,0,0,.46.22.54.54,0,0,0,.45-.21,1,1,0,0,0,.18-.65h.69A1.61,1.61,0,0,1,188.92,6.6Z" style="fill: #82c341"/>
    <path d="M191.41,4.55v2.3h-.69V4.55l-1.05-3.39h.76l.63,2.43.64-2.43h.76Z" style="fill: #82c341"/>
    <path d="M193.85,6.85V1.92l-.83.67V1.84l.83-.68h.65V6.85Z" style="fill: #82c341"/>
    <path d="M197.87,6.58a1.13,1.13,0,0,1-.82.33,1.21,1.21,0,0,1-.82-.29,1.15,1.15,0,0,1-.32-.88V5.41h.64v.38c0,.42.22.6.5.6a.43.43,0,0,0,.36-.17A2.45,2.45,0,0,0,197.57,5a2.33,2.33,0,0,0-.15-1.13.43.43,0,0,0-.37-.19.51.51,0,0,0-.5.57v.19h-.61V1.16h2.2v.58h-1.61V3.51a1.07,1.07,0,0,1,.28-.28.9.9,0,0,1,.42-.1.86.86,0,0,1,.71.32A2.46,2.46,0,0,1,198.22,5C198.22,5.81,198.2,6.24,197.87,6.58Z" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M243,6.6a1.2,1.2,0,0,1-.88.31,1.25,1.25,0,0,1-1-.41c-.39-.43-.41-1.07-.41-2.5s0-2.07.41-2.5a1.25,1.25,0,0,1,1-.41,1.21,1.21,0,0,1,.9.34,1.56,1.56,0,0,1,.41,1.13h-.69a1,1,0,0,0-.17-.65.54.54,0,0,0-.45-.2.55.55,0,0,0-.46.21c-.2.28-.24.73-.24,2.08s0,1.81.24,2.08a.53.53,0,0,0,.46.22.54.54,0,0,0,.45-.21,1,1,0,0,0,.18-.65h.69A1.61,1.61,0,0,1,243,6.6Z" style="fill: #82c341"/>
    <path d="M245.45,4.55v2.3h-.69V4.55l-1-3.39h.75l.64,2.43.64-2.43h.76Z" style="fill: #82c341"/>
    <path d="M247.89,6.85V1.92l-.83.68V1.84l.83-.68h.65V6.85Z" style="fill: #82c341"/>
    <path d="M252,6.53a1.08,1.08,0,0,1-.88.38,1,1,0,0,1-.87-.38c-.24-.3-.29-.62-.29-1.38a4,4,0,0,1,.23-1.44l1-2.55h.66l-.92,2.37a.63.63,0,0,1,.4-.14.91.91,0,0,1,.71.33c.21.25.29.51.29,1.43A2,2,0,0,1,252,6.53Zm-.52-2.43a.46.46,0,0,0-.36-.16.42.42,0,0,0-.35.16c-.16.18-.16.54-.16,1a1.78,1.78,0,0,0,.16,1,.43.43,0,0,0,.35.15.48.48,0,0,0,.36-.15,1.87,1.87,0,0,0,.16-1A1.83,1.83,0,0,0,251.45,4.1Z" style="fill: #82c341"/>
  </g>
  <g style="clip-path: url(#clip-path4)">
    <path d="M339.69,66a.94.94,0,0,0,.66,0,1.34,1.34,0,0,0,.28-.18l10.25-9.9a.82.82,0,0,0,0-1.17.88.88,0,0,0-1.21,0l-8.79,8.49V38a.86.86,0,0,0-1.71,0V63.25l-8.79-8.49a.88.88,0,0,0-1.21,0,.83.83,0,0,0-.25.59.79.79,0,0,0,.25.58l10.25,9.9a1.06,1.06,0,0,0,.27.18" style="fill: #929497"/>
  </g>
  <g style="clip-path: url(#clip-path4-2)">
    <path d="M13.44,39a.5.5,0,0,0,.34,0,.4.4,0,0,0,.15-.1l5.32-5.14a.4.4,0,0,0,0-.6.45.45,0,0,0-.63,0l-4.56,4.41V24.48a.45.45,0,0,0-.89,0V37.59L8.6,33.18a.45.45,0,0,0-.63,0,.41.41,0,0,0,0,.6l5.33,5.14a.45.45,0,0,0,.14.1" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M299.73,107.56a2.42,2.42,0,0,1-3.28,0,2.49,2.49,0,0,1-.68-1.9v-1h.76v1c0,1.22.7,1.84,1.56,1.84a1.36,1.36,0,0,0,1.06-.44c.4-.46.56-1,.56-2.92,0-2.16-.12-2.54-.56-3a1.39,1.39,0,0,0-1.06-.44h-.86v-.68h.86a1.28,1.28,0,0,0,1-.38c.38-.4.52-1,.52-2.48s-.16-2.08-.5-2.46a1.37,1.37,0,0,0-1-.4c-.86,0-1.46.62-1.46,1.84v1h-.76v-1a2.49,2.49,0,0,1,.64-1.9,2.35,2.35,0,0,1,3.16,0c.5.5.68,1.14.68,2.94a4.36,4.36,0,0,1-.4,2.48,2,2,0,0,1-.8.72,2.23,2.23,0,0,1,.78.62c.4.54.54.92.54,3.16S300.31,106.94,299.73,107.56Z" style="fill: #005cb9"/>
    <path d="M306.65,107.56a2.42,2.42,0,0,1-3.28,0,2.49,2.49,0,0,1-.68-1.9v-1h.76v1c0,1.22.7,1.84,1.56,1.84a1.36,1.36,0,0,0,1.06-.44c.4-.46.56-1,.56-2.92,0-2.16-.12-2.54-.56-3a1.39,1.39,0,0,0-1.06-.44h-.86v-.68H305a1.28,1.28,0,0,0,1-.38c.38-.4.52-1,.52-2.48s-.16-2.08-.5-2.46a1.37,1.37,0,0,0-1-.4c-.86,0-1.46.62-1.46,1.84v1h-.76v-1a2.49,2.49,0,0,1,.64-1.9,2.35,2.35,0,0,1,3.16,0c.5.5.68,1.14.68,2.94a4.36,4.36,0,0,1-.4,2.48,2,2,0,0,1-.8.72,2.23,2.23,0,0,1,.78.62c.4.54.54.92.54,3.16S307.23,106.94,306.65,107.56Z" style="fill: #005cb9"/>
    <path d="M311.49,101.14a1.71,1.71,0,0,1-1.76-1.84V95.5a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,311.49,101.14Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56h-.68l5-14.24h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,317.17,108.22Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #005cb9"/>
  </g>
  <g style="clip-path: url(#clip-path4-3)">
    <path d="M287.78,108.35a.5.5,0,0,0,.34,0,.42.42,0,0,0,.14-.09l5.33-5.14a.43.43,0,0,0,0-.61.45.45,0,0,0-.63,0l-4.57,4.41V93.81a.45.45,0,0,0-.89,0v13.11l-4.57-4.41a.44.44,0,0,0-.62,0,.39.39,0,0,0-.13.3.43.43,0,0,0,.13.31l5.32,5.14a.38.38,0,0,0,.15.09" style="fill: #005cb9"/>
  </g>
  <g>
    <path d="M79.92,107.16a2.42,2.42,0,0,1-3.28,0,2.49,2.49,0,0,1-.68-1.9v-1h.76v1c0,1.22.7,1.84,1.56,1.84a1.36,1.36,0,0,0,1.06-.44c.4-.46.56-1,.56-2.92,0-2.16-.12-2.54-.56-3a1.4,1.4,0,0,0-1.06-.45h-.86v-.68h.86a1.25,1.25,0,0,0,1-.38c.38-.39.52-1,.52-2.48s-.16-2.08-.5-2.46a1.37,1.37,0,0,0-1-.4c-.86,0-1.46.62-1.46,1.84v1h-.76v-1a2.49,2.49,0,0,1,.64-1.9,2.35,2.35,0,0,1,3.16,0c.5.5.68,1.14.68,2.94a4.36,4.36,0,0,1-.4,2.48,2,2,0,0,1-.8.73,2.23,2.23,0,0,1,.78.62c.4.54.54.92.54,3.16S80.5,106.54,79.92,107.16Z" style="fill: #80c241"/>
    <path d="M87,105.1v2.56h-.76V105.1h-3.7v-.68l3.6-11h.76l-3.6,11h2.94V99.9H87v4.52h1v.68Z" style="fill: #80c241"/>
    <path d="M91.68,100.74a1.71,1.71,0,0,1-1.76-1.84V95.09a1.76,1.76,0,1,1,3.52,0V98.9A1.71,1.71,0,0,1,91.68,100.74Zm1.06-5.65c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22V98.9c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.57H91.7l5-14.25h.69Zm5,.16A1.72,1.72,0,0,1,95.6,106v-3.8a1.77,1.77,0,1,1,3.53,0V106A1.71,1.71,0,0,1,97.36,107.82Zm1.07-5.64c0-.74-.37-1.22-1.07-1.22s-1,.48-1,1.22V106c0,.74.35,1.22,1,1.22s1.07-.48,1.07-1.22Z" style="fill: #80c241"/>
  </g>
  <g style="clip-path: url(#clip-path4-4)">
    <path d="M68.11,108.1a.5.5,0,0,0,.34,0,.71.71,0,0,0,.14-.1l5.33-5.14a.43.43,0,0,0,0-.61.47.47,0,0,0-.63,0l-4.57,4.42V93.56a.44.44,0,0,0-.88,0v13.11l-4.57-4.42a.47.47,0,0,0-.63,0,.43.43,0,0,0-.13.31.39.39,0,0,0,.13.3L68,108a.39.39,0,0,0,.14.1" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M133.26,102.08a2.42,2.42,0,0,1-3.28,0,2.49,2.49,0,0,1-.68-1.9v-1h.76v1c0,1.22.7,1.84,1.56,1.84a1.36,1.36,0,0,0,1.06-.44c.4-.46.56-1,.56-2.92,0-2.16-.12-2.54-.56-3a1.39,1.39,0,0,0-1.06-.44h-.86v-.68h.86a1.28,1.28,0,0,0,1-.38c.38-.4.52-1,.52-2.48s-.16-2.08-.5-2.46a1.37,1.37,0,0,0-1-.4c-.86,0-1.46.62-1.46,1.84v1h-.76v-1a2.49,2.49,0,0,1,.64-1.9,2.35,2.35,0,0,1,3.16,0c.5.5.68,1.14.68,2.94a4.36,4.36,0,0,1-.4,2.48,2,2,0,0,1-.8.72,2.23,2.23,0,0,1,.78.62c.4.54.54.92.54,3.16S133.84,101.46,133.26,102.08Z" style="fill: #80c241"/>
    <path d="M140.28,102.1a2.42,2.42,0,0,1-3.28,0,2.49,2.49,0,0,1-.66-1.9V90.72a2.49,2.49,0,0,1,.66-1.9,2.42,2.42,0,0,1,3.28,0,2.49,2.49,0,0,1,.66,1.9v9.48A2.49,2.49,0,0,1,140.28,102.1Zm-.1-11.42c0-1.22-.68-1.82-1.54-1.82s-1.54.6-1.54,1.82v9.56c0,1.22.68,1.82,1.54,1.82s1.54-.6,1.54-1.82Z" style="fill: #80c241"/>
    <path d="M145,95.66a1.71,1.71,0,0,1-1.76-1.84V90a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,145,95.66ZM146.08,90c0-.74-.36-1.22-1.06-1.22S144,89.28,144,90v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56H145l5-14.24h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84V97.1a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,150.7,102.74Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #80c241"/>
  </g>
  <g style="clip-path: url(#clip-path4-5)">
    <path d="M121.44,103a.5.5,0,0,0,.34,0,.4.4,0,0,0,.15-.1l5.32-5.14a.4.4,0,0,0,0-.6.45.45,0,0,0-.63,0l-4.56,4.41V88.48a.45.45,0,0,0-.89,0v13.11l-4.57-4.41a.45.45,0,0,0-.63,0,.41.41,0,0,0,0,.6l5.33,5.14a.45.45,0,0,0,.14.1" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M183.57,93.66V93l3.32-8.14a8.08,8.08,0,0,0,.72-3.14c0-1.22-.68-1.82-1.54-1.82s-1.54.6-1.54,1.82v1h-.76v-1a2.48,2.48,0,0,1,.66-1.86,2.42,2.42,0,0,1,3.28,0,2.49,2.49,0,0,1,.66,1.9,9.52,9.52,0,0,1-.82,3.38L184.37,93h4v.68Z" style="fill: #80c241"/>
    <path d="M194.53,93.06a2.13,2.13,0,0,1-1.64.76,2.36,2.36,0,0,1-1.64-.6,2.55,2.55,0,0,1-.7-1.92v-1h.76v.94c0,1.34.7,1.92,1.58,1.92A1.31,1.31,0,0,0,194,92.6c.4-.54.54-1.16.54-3.38s-.16-2.86-.56-3.4a1.25,1.25,0,0,0-1.06-.52,1.64,1.64,0,0,0-1.58,1.8v.8h-.7V79.42h4.46v.68h-3.76v5.48a1.84,1.84,0,0,1,.64-.66,1.81,1.81,0,0,1,1.08-.28,1.88,1.88,0,0,1,1.52.74c.58.7.72,1.46.72,3.84S195.11,92.36,194.53,93.06Z" style="fill: #80c241"/>
    <path d="M199.27,86.74a1.71,1.71,0,0,1-1.76-1.84V81.1a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,199.27,86.74Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22ZM200,93.66h-.68l5-14.24h.68Zm5,.16A1.71,1.71,0,0,1,203.19,92v-3.8a1.76,1.76,0,1,1,3.52,0V92A1.71,1.71,0,0,1,205,93.82ZM206,88.18c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22V92c0,.74.36,1.22,1.06,1.22S206,92.72,206,92Z" style="fill: #80c241"/>
  </g>
  <g style="clip-path: url(#clip-path4-6)">
    <path d="M175.69,94.1a.5.5,0,0,0,.34,0,.38.38,0,0,0,.15-.09l5.32-5.14a.41.41,0,0,0,0-.61.45.45,0,0,0-.63,0l-4.56,4.41V79.56a.45.45,0,0,0-.89,0V92.67l-4.57-4.41a.45.45,0,0,0-.63,0,.43.43,0,0,0-.13.3.48.48,0,0,0,.13.31L175.55,94a.42.42,0,0,0,.14.09" style="fill: #82c341"/>
  </g>
  <g>
    <path d="M242.12,117.85v2.56h-.76v-2.56h-3.7v-.68l3.6-11H242l-3.6,11h2.94v-4.52h.76v4.52h1v.68Z" style="fill: #80c241"/>
    <path d="M247.06,120.41V107.07l-2,1.8v-1l2-1.74h.76v14.24Z" style="fill: #80c241"/>
    <path d="M253.68,113.49a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,253.68,113.49Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56h-.68l5-14.24h.69Zm5,.16a1.72,1.72,0,0,1-1.76-1.84v-3.8a1.77,1.77,0,1,1,3.53,0v3.8A1.71,1.71,0,0,1,259.36,120.57Zm1.07-5.64c0-.74-.37-1.22-1.07-1.22s-1.05.48-1.05,1.22v3.8c0,.74.35,1.22,1.05,1.22s1.07-.48,1.07-1.22Z" style="fill: #80c241"/>
  </g>
  <g style="clip-path: url(#clip-path4-7)">
    <path d="M230.11,120.85a.5.5,0,0,0,.34,0,.42.42,0,0,0,.14-.09l5.33-5.14a.43.43,0,0,0,0-.61.45.45,0,0,0-.63,0l-4.57,4.41V106.31a.44.44,0,0,0-.88,0v13.11L225.27,115a.45.45,0,0,0-.63,0,.39.39,0,0,0-.13.3.43.43,0,0,0,.13.31l5.33,5.14a.28.28,0,0,0,.14.09" style="fill: #82c341"/>
  </g>
  <rect class="bar" x="20.51" y="13.25" width="16.29" height="7.5" style="fill: #82c341"/>
  <rect class="bar" x="75.33" y="13.25" width="16.29" height="77.44" style="fill: #82c341"/>
  <rect class="bar" x="129.69" y="13.25" width="16.29" height="71.44" style="fill: #82c341"/>
  <rect class="bar" x="184.12" y="13.25" width="16.29" height="62.44" style="fill: #82c341"/>
  <rect class="bar" x="238.32" y="13.25" width="16.29" height="89.44" style="fill: #82c341"/>
  <rect class="bar" x="293.16" y="13.25" width="16.29" height="75.44" style="fill: #005cb9"/>
</svg>
			</div>
		</div>
		<div class="progressContent--4__tab progressContent--4__tab--5">
			<div class="progressContent--4__callout progressContent--4__callout--4">
				<img class="progressContent--4__target" src="../_images/strategy/growth/icon1.svg" alt="">
				<h4>2020 Goal</h4>
				<p>Reduce water use by <br>
					<span><img class="progressContent--4__arrow" src="../_images/strategy/growth/arrow.svg" alt="">20%</span> <br>
					per case of product sold versus a 2011 calendar year baseline.
				</p>
				<h4>Results to Date</h4>
				<img class="progressContent--4__arrow" src="../_images/strategy/growth/arrow.svg" alt=""><span>22%</span>
			</div>

			<h2 class="progressContent__heading">Water Reductions Remain Ahead of 2020&nbsp;Goal</h2>

			<p>With steady progress throughout the goal period, we surpassed our 20 percent water reduction goal in 2016, four years early. We continued to reduce overall usage in 2017 but noticed increased water usage for equipment cleaning as our plants strived to reduce water use without compromising quality requirements. Water leaks discovered in underground piping at some of our older plants, which required repairs, also affected our progress.</p>
			<p>These challenges were offset by our new Atlanta West plant that is designed to generate little wastewater. And we continue to benefit from and implement water-reduction best practices identified through a third-party water audit conducted in 2015 and 2016 for our most resource-intensive plants. These initiatives have enabled us to accelerate our progress from a 14 percent reduction in water use in 2015 to a 22 percent reduction in the current year. Going forward, we believe additional water savings initiatives reporting across the company have the potential to reduce water use by more than 15 million gallons per year, particularly through efficiency, recycling and reuse.</p>

			<img class="progressContent--4__image progressContent--4__image--6 margin-neg-left-100" src="../_images/strategy/growth/progress5.jpg" alt="">
			<div class="progressContent--4__chart progressContent--4__chart--5">
				<h4>Water Use <br><span>(annual progress versus 2011 base year):</span></h4>
				<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="411.59" height="111.62" viewBox="0 0 411.59 111.62" class="growthChart--5">
  <defs>
    <clipPath id="clip-path">
      <rect x="326.26" y="53.04" width="22.21" height="28.87" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path-2">
      <rect x="224.67" y="88.23" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path-3">
      <rect x="171.34" y="63.56" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path-4">
      <rect x="116" y="53.56" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path-5">
      <rect x="60" y="41.23" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path-6">
      <rect x="5" y="33.23" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path-7">
      <rect x="277.67" y="93.56" width="11.54" height="15" style="fill: none"/>
    </clipPath>
  </defs>
  <g>
    <g>
      <path d="M23.88,47.74a2.14,2.14,0,0,1-1.65.76,2.36,2.36,0,0,1-1.64-.6,2.55,2.55,0,0,1-.7-1.92V45h.76v.94c0,1.34.7,1.92,1.58,1.92a1.31,1.31,0,0,0,1.08-.54c.4-.54.54-1.16.54-3.38s-.16-2.86-.56-3.4A1.25,1.25,0,0,0,22.23,40a1.64,1.64,0,0,0-1.58,1.8v.8H20V34.1h4.47v.68H20.65v5.48a1.84,1.84,0,0,1,.64-.66,1.81,1.81,0,0,1,1.08-.28,1.9,1.9,0,0,1,1.53.74c.58.7.72,1.46.72,3.84S24.46,47,23.88,47.74Z" style="fill: #82c341"/>
      <path d="M28.61,41.42a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.77,1.77,0,1,1,3.53,0v3.8A1.72,1.72,0,0,1,28.61,41.42Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56h-.68l5-14.24h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,34.3,48.5Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #82c341"/>
    </g>
	<rect class="bar" x="19.85" y="12.77" width="16.29" height="17.3" style="fill: #82c341"/>
	<rect class="bar" x="74.42" y="12.77" width="16.29" height="26.64" style="fill: #82c341"/>
	<rect class="bar" x="128.99" y="12.77" width="16.29" height="37.3" style="fill: #82c341"/>
	<rect class="bar" x="183.55" y="12.77" width="16.29" height="49.3" style="fill: #82c341"/>
	<rect class="bar" x="238.12" y="12.77" width="16.29" height="71.3" style="fill: #82c341"/>
    <rect class="bar" x="292.69" y="12.77" width="16.29" height="76.64" style="fill: #005cb9"/>
    
    <g>
      <path d="M24.42,7.69a1.38,1.38,0,0,1-1.85-.1c-.4-.43-.42-1.08-.42-2.5s0-2.07.42-2.51a1.22,1.22,0,0,1,1-.4,1.28,1.28,0,0,1,.91.33,1.6,1.6,0,0,1,.4,1.14h-.68A1.07,1.07,0,0,0,24,3a.54.54,0,0,0-.45-.2.53.53,0,0,0-.46.22c-.2.27-.24.73-.24,2.08s0,1.8.24,2.08a.55.55,0,0,0,.46.21A.54.54,0,0,0,24,7.17a1,1,0,0,0,.18-.64h.69A1.61,1.61,0,0,1,24.42,7.69Z" style="fill: #82c341"/>
      <path d="M26.91,5.63v2.3h-.69V5.63l-1-3.39h.76l.64,2.43.64-2.43H28Z" style="fill: #82c341"/>
      <path d="M29.35,7.93V3l-.83.68V2.93l.83-.69H30V7.93Z" style="fill: #82c341"/>
      <path d="M31.42,7.93V7.39l1.39-2.95a2.58,2.58,0,0,0,.26-1.1c0-.39-.22-.58-.49-.58s-.49.19-.49.58v.38h-.65V3.35a1.14,1.14,0,0,1,.32-.87,1.21,1.21,0,0,1,.82-.3,1.15,1.15,0,0,1,.8.28,1.2,1.2,0,0,1,.34.9,3.24,3.24,0,0,1-.33,1.29l-1.27,2.7h1.6v.58Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M79.09,7.69a1.39,1.39,0,0,1-1.86-.1c-.39-.43-.41-1.08-.41-2.5s0-2.07.41-2.51a1.4,1.4,0,0,1,1.88-.07,1.6,1.6,0,0,1,.41,1.14h-.69A1.14,1.14,0,0,0,78.66,3a.61.61,0,0,0-.92,0c-.2.27-.24.73-.24,2.08s0,1.8.24,2.08a.57.57,0,0,0,.47.21.56.56,0,0,0,.45-.21,1.1,1.1,0,0,0,.18-.64h.69A1.61,1.61,0,0,1,79.09,7.69Z" style="fill: #82c341"/>
      <path d="M81.58,5.63v2.3h-.69V5.63l-1-3.39h.75l.64,2.43.64-2.43h.76Z" style="fill: #82c341"/>
      <path d="M84,7.93V3l-.83.68V2.93L84,2.24h.64V7.93Z" style="fill: #82c341"/>
      <path d="M88,7.69a1.24,1.24,0,0,1-1.64,0,1.14,1.14,0,0,1-.32-.87V6.45h.64v.39a.5.5,0,0,0,.5.57.43.43,0,0,0,.35-.15c.14-.16.17-.45.17-1s0-.8-.17-1a.43.43,0,0,0-.35-.16h-.3V4.63h.3a.41.41,0,0,0,.31-.13c.14-.14.16-.4.16-.81s0-.65-.14-.79a.42.42,0,0,0-.33-.14c-.26,0-.46.18-.46.56v.4H86.1V3.35a1.16,1.16,0,0,1,.31-.88,1.13,1.13,0,0,1,.79-.29,1.06,1.06,0,0,1,.78.28,1.53,1.53,0,0,1,.34,1.19,1.84,1.84,0,0,1-.15.93,1,1,0,0,1-.31.32,1.18,1.18,0,0,1,.32.31,2,2,0,0,1,.19,1.12C88.37,7,88.33,7.38,88,7.69Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M133.75,7.69a1.21,1.21,0,0,1-.87.31,1.25,1.25,0,0,1-1-.41c-.39-.43-.42-1.08-.42-2.5s0-2.07.42-2.51a1.24,1.24,0,0,1,1-.4,1.26,1.26,0,0,1,.9.33,1.65,1.65,0,0,1,.41,1.14h-.69a1.07,1.07,0,0,0-.18-.66.52.52,0,0,0-.44-.2.55.55,0,0,0-.47.22c-.2.27-.24.73-.24,2.08s0,1.8.24,2.08a.57.57,0,0,0,.47.21.52.52,0,0,0,.44-.21,1,1,0,0,0,.19-.64h.68A1.57,1.57,0,0,1,133.75,7.69Z" style="fill: #82c341"/>
      <path d="M136.24,5.63v2.3h-.68V5.63l-1.05-3.39h.75l.64,2.43.64-2.43h.76Z" style="fill: #82c341"/>
      <path d="M138.68,7.93V3l-.83.68V2.93l.83-.69h.65V7.93Z" style="fill: #82c341"/>
      <path d="M142.79,7v.93h-.65V7H140.6V6.41l1.45-4.17h.62l-1.41,4.17h.88V5.11h.65v1.3h.4V7Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M187.75,7.69a1.21,1.21,0,0,1-.87.31,1.25,1.25,0,0,1-1-.41c-.39-.43-.42-1.08-.42-2.5s0-2.07.42-2.51a1.24,1.24,0,0,1,1-.4,1.26,1.26,0,0,1,.9.33,1.65,1.65,0,0,1,.41,1.14h-.69a1.07,1.07,0,0,0-.18-.66.52.52,0,0,0-.44-.2.55.55,0,0,0-.47.22c-.2.27-.24.73-.24,2.08s0,1.8.24,2.08a.57.57,0,0,0,.47.21.52.52,0,0,0,.44-.21,1,1,0,0,0,.19-.64h.68A1.57,1.57,0,0,1,187.75,7.69Z" style="fill: #82c341"/>
      <path d="M190.24,5.63v2.3h-.68V5.63l-1.05-3.39h.75l.64,2.43.64-2.43h.76Z" style="fill: #82c341"/>
      <path d="M192.68,7.93V3l-.83.68V2.93l.83-.69h.65V7.93Z" style="fill: #82c341"/>
      <path d="M196.71,7.67a1.17,1.17,0,0,1-.83.33,1.19,1.19,0,0,1-.81-.3,1.14,1.14,0,0,1-.33-.88V6.49h.65v.39c0,.41.21.6.49.6a.43.43,0,0,0,.36-.18,2.29,2.29,0,0,0,.16-1.18A2.23,2.23,0,0,0,196.25,5a.43.43,0,0,0-.37-.19.51.51,0,0,0-.49.58v.19h-.62V2.24H197v.58h-1.62V4.59a1.19,1.19,0,0,1,.28-.27.83.83,0,0,1,.43-.1.87.87,0,0,1,.71.32c.24.29.27.74.27,1.53S197,7.33,196.71,7.67Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M243.09,7.69a1.39,1.39,0,0,1-1.86-.1c-.39-.43-.41-1.08-.41-2.5s0-2.07.41-2.51a1.4,1.4,0,0,1,1.88-.07,1.6,1.6,0,0,1,.41,1.14h-.69a1.14,1.14,0,0,0-.17-.66.55.55,0,0,0-.45-.2.52.52,0,0,0-.46.22c-.21.27-.25.73-.25,2.08s0,1.8.25,2.08a.53.53,0,0,0,.46.21.56.56,0,0,0,.45-.21,1.1,1.1,0,0,0,.18-.64h.69A1.61,1.61,0,0,1,243.09,7.69Z" style="fill: #82c341"/>
      <path d="M245.58,5.63v2.3h-.69V5.63l-1-3.39h.75l.64,2.43.64-2.43h.76Z" style="fill: #82c341"/>
      <path d="M248,7.93V3l-.83.68V2.93l.83-.69h.65V7.93Z" style="fill: #82c341"/>
      <path d="M252.1,7.61a1.06,1.06,0,0,1-.88.39,1.08,1.08,0,0,1-.88-.39c-.23-.3-.28-.61-.28-1.38a4,4,0,0,1,.23-1.43l1-2.56h.66L251,4.62a.68.68,0,0,1,.41-.14.91.91,0,0,1,.71.33c.2.25.28.51.28,1.42A2.1,2.1,0,0,1,252.1,7.61Zm-.52-2.43a.5.5,0,0,0-.36-.16.45.45,0,0,0-.35.16,1.78,1.78,0,0,0-.16,1c0,.5,0,.86.16,1a.4.4,0,0,0,.35.15.44.44,0,0,0,.36-.15,1.83,1.83,0,0,0,.16-1A1.87,1.87,0,0,0,251.58,5.18Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M298.42,7.69a1.38,1.38,0,0,1-1.85-.1c-.4-.43-.42-1.08-.42-2.5s0-2.07.42-2.51a1.22,1.22,0,0,1,1-.4,1.28,1.28,0,0,1,.91.33,1.64,1.64,0,0,1,.4,1.14h-.68A1.07,1.07,0,0,0,298,3a.54.54,0,0,0-.45-.2.53.53,0,0,0-.46.22c-.2.27-.24.73-.24,2.08s0,1.8.24,2.08a.55.55,0,0,0,.46.21.54.54,0,0,0,.45-.21,1,1,0,0,0,.18-.64h.69A1.61,1.61,0,0,1,298.42,7.69Z" style="fill: #005cb9"/>
      <path d="M300.91,5.63v2.3h-.69V5.63l-1.05-3.39h.76l.64,2.43.64-2.43H302Z" style="fill: #005cb9"/>
      <path d="M303.35,7.93V3l-.83.68V2.93l.83-.69H304V7.93Z" style="fill: #005cb9"/>
      <path d="M306.24,7.93h-.66l1.5-5.11H306v.84h-.63V2.24h2.39v.54Z" style="fill: #005cb9"/>
    </g>
    <g>
      <path d="M291.86,108.39v-.62l3.32-8.15a8,8,0,0,0,.72-3.14c0-1.22-.68-1.82-1.54-1.82s-1.54.6-1.54,1.82v1h-.76v-1a2.48,2.48,0,0,1,.66-1.86,2.42,2.42,0,0,1,3.28,0,2.49,2.49,0,0,1,.66,1.9,9.52,9.52,0,0,1-.82,3.38l-3.18,7.81h4v.68Z" style="fill: #005cb9"/>
      <path d="M298.78,108.39v-.62l3.32-8.15a8,8,0,0,0,.72-3.14c0-1.22-.68-1.82-1.54-1.82s-1.54.6-1.54,1.82v1H299v-1a2.48,2.48,0,0,1,.66-1.86,2.42,2.42,0,0,1,3.28,0,2.49,2.49,0,0,1,.66,1.9,9.52,9.52,0,0,1-.82,3.38l-3.18,7.81h4v.68Z" style="fill: #005cb9"/>
      <path d="M307.56,101.46a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,307.56,101.46Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.75.36,1.23,1.06,1.23s1.06-.48,1.06-1.23Zm-.36,12.57h-.68l5-14.25h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,313.24,108.55Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #005cb9"/>
    </g>
    <g>
      <path d="M78.88,55.84a2.38,2.38,0,0,1-3.29,0c-.58-.62-.74-1.28-.74-3.38s.14-2.62.54-3.16a2.23,2.23,0,0,1,.78-.62,2,2,0,0,1-.8-.72A4.3,4.3,0,0,1,75,45.48c0-1.8.2-2.44.7-2.94a2.21,2.21,0,0,1,1.58-.6,2.17,2.17,0,0,1,1.58.6c.5.5.71,1.14.71,2.94A4.3,4.3,0,0,1,79.1,48a2,2,0,0,1-.81.72,2.27,2.27,0,0,1,.79.62c.4.54.54.92.54,3.16S79.46,55.22,78.88,55.84Zm-.59-6.38a1.5,1.5,0,0,0-2.12,0c-.44.46-.56.84-.56,3,0,1.9.16,2.46.56,2.92a1.5,1.5,0,0,0,2.12,0c.4-.46.56-1,.56-2.92C78.85,50.3,78.73,49.92,78.29,49.46ZM78.23,43a1.45,1.45,0,0,0-2,0c-.34.38-.52.94-.52,2.46s.16,2.08.54,2.48a1.45,1.45,0,0,0,2,0c.38-.4.54-1,.54-2.48S78.57,43.4,78.23,43Z" style="fill: #82c341"/>
      <path d="M83.61,49.42a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.77,1.77,0,1,1,3.53,0v3.8A1.72,1.72,0,0,1,83.61,49.42Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56h-.68l5-14.24h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,89.3,56.5Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M132.33,67.67V54.33l-2,1.8v-1l2-1.74h.76V67.67Z" style="fill: #82c341"/>
      <path d="M139.25,67.67V54.33l-2,1.8v-1l2-1.74H140V67.67Z" style="fill: #82c341"/>
      <path d="M145.87,60.75a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,145.87,60.75Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56h-.68l5-14.24h.68Zm5,.16A1.71,1.71,0,0,1,149.79,66v-3.8a1.76,1.76,0,1,1,3.52,0V66A1.71,1.71,0,0,1,151.55,67.83Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22V66c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M187,78.34V65l-2,1.8v-1l2-1.74h.76V78.34Z" style="fill: #82c341"/>
      <path d="M195.9,75.78v2.56h-.77V75.78h-3.7V75.1l3.6-11h.76l-3.6,11h2.94V70.58h.77V75.1h1v.68Z" style="fill: #82c341"/>
      <path d="M200.53,71.42a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,200.53,71.42Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56h-.68l5-14.24h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,206.22,78.5Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M238.83,102.67v-.62l3.33-8.14a8.08,8.08,0,0,0,.72-3.14c0-1.22-.68-1.82-1.55-1.82s-1.54.6-1.54,1.82v1H239v-1a2.48,2.48,0,0,1,.66-1.86,2.38,2.38,0,0,1,1.64-.64,2.43,2.43,0,0,1,1.65.64,2.49,2.49,0,0,1,.66,1.9,9.52,9.52,0,0,1-.82,3.38l-3.19,7.8h4v.68Z" style="fill: #82c341"/>
      <path d="M247.92,102.67V89.33l-2,1.8v-1l2-1.74h.75v14.24Z" style="fill: #82c341"/>
      <path d="M254.53,95.75a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,254.53,95.75Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56h-.68l5-14.24h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0V101A1.71,1.71,0,0,1,260.22,102.83Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22V101c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M350.89,82.09V78.41l7.27-14.13a11.19,11.19,0,0,0,1.19-5.18c0-1.68-.9-2.53-2.09-2.53s-2.16.81-2.16,2.49v1.88h-4.33V59.22a6.11,6.11,0,0,1,1.8-4.82,6.91,6.91,0,0,1,4.69-1.71,6.39,6.39,0,0,1,4.5,1.55,6.56,6.56,0,0,1,1.92,5,14.71,14.71,0,0,1-1.6,6.37l-6.57,12.58h8.17v3.88Z" style="fill: #929497"/>
      <path d="M378.17,80.7a6.64,6.64,0,0,1-4.61,1.71,6.76,6.76,0,0,1-4.66-1.71,6.12,6.12,0,0,1-1.84-4.82V59.22a6.12,6.12,0,0,1,1.84-4.82,6.76,6.76,0,0,1,4.66-1.71,6.64,6.64,0,0,1,4.61,1.71A6.12,6.12,0,0,1,380,59.22V75.88A6.12,6.12,0,0,1,378.17,80.7Zm-2.49-21.64c0-1.68-.94-2.49-2.12-2.49s-2.17.81-2.17,2.49V76c0,1.68,1,2.49,2.17,2.49s2.12-.81,2.12-2.49Z" style="fill: #929497"/>
      <path d="M388.83,67.92c-2.78,0-5.19-1.68-5.19-4.9V57.59c0-3.23,2.41-4.9,5.19-4.9s5.18,1.67,5.18,4.9V63C394,66.24,391.61,67.92,388.83,67.92Zm1.63-10.25c0-1.27-.65-1.84-1.63-1.84s-1.68.57-1.68,1.84v5.27a1.6,1.6,0,0,0,1.68,1.83c1,0,1.63-.57,1.63-1.83Zm2.86,24.42H390L400.1,53h3.35Zm11.19.32c-2.78,0-5.19-1.67-5.19-4.9V72.08c0-3.22,2.41-4.9,5.19-4.9s5.18,1.68,5.18,4.9v5.43C409.69,80.74,407.29,82.41,404.51,82.41Zm1.63-10.24c0-1.27-.65-1.84-1.63-1.84s-1.63.57-1.63,1.84v5.26c0,1.27.65,1.84,1.63,1.84s1.63-.57,1.63-1.84Z" style="fill: #929497"/>
    </g>
    <g>
      <path d="M356.66,47.08a2.34,2.34,0,0,1-1.6.55,2.29,2.29,0,0,1-1.73-.68c-.73-.79-.81-1.7-.81-5.26s.08-4.47.81-5.26a2.29,2.29,0,0,1,1.73-.68,2.25,2.25,0,0,1,1.67.62,3.14,3.14,0,0,1,.75,2.17h-1a2.3,2.3,0,0,0-.46-1.54,1.46,1.46,0,0,0-2,0c-.47.57-.55,1.24-.55,4.65s.08,4.08.55,4.65a1.46,1.46,0,0,0,2,0,2.3,2.3,0,0,0,.46-1.54h1A3,3,0,0,1,356.66,47.08Z" style="fill: #929497"/>
      <path d="M361.2,42.64V47.5h-1V42.64l-2-6.76h1.06l1.45,5.32,1.47-5.32h1.07Z" style="fill: #929497"/>
      <path d="M364.13,47.5v-.76l2.77-6.37a6,6,0,0,0,.56-2.45c0-.92-.51-1.36-1.14-1.36s-1.16.44-1.16,1.36v.83h-.92v-.81a2.14,2.14,0,0,1,.59-1.62,2.19,2.19,0,0,1,1.49-.57,2.08,2.08,0,0,1,1.45.55,2.21,2.21,0,0,1,.6,1.67,7.2,7.2,0,0,1-.67,2.69l-2.59,6h3.26v.81Z" style="fill: #929497"/>
      <path d="M373.62,47.06a2.17,2.17,0,0,1-1.49.57,2.1,2.1,0,0,1-1.47-.57,2.16,2.16,0,0,1-.59-1.65V38a2,2,0,0,1,2.06-2.22,2.21,2.21,0,0,1,1.49.57A2.16,2.16,0,0,1,374.2,38v7.44A2.16,2.16,0,0,1,373.62,47.06Zm-.33-9.14c0-.92-.52-1.36-1.16-1.36S371,37,371,37.92v7.54c0,.92.5,1.36,1.14,1.36s1.16-.44,1.16-1.36Z" style="fill: #929497"/>
    </g>
    <g>
      <path d="M383.51,48.43a2.88,2.88,0,0,1-2.34-1c-.91-1-.89-2.79-.89-5.17s0-4.15.89-5.17a2.88,2.88,0,0,1,2.34-1,2.93,2.93,0,0,1,2.16.82,3.71,3.71,0,0,1,.94,2.53H384.7c0-.68-.17-1.63-1.19-1.63a1,1,0,0,0-.9.46c-.36.58-.42,1.8-.42,4s.06,3.43.42,4a1,1,0,0,0,.9.46c.82,0,1.19-.71,1.19-1.55V43.28h-1.19V41.71h3.1v3.35C386.61,47.25,385.31,48.43,383.51,48.43Z" style="fill: #929497"/>
      <path d="M393.59,47.41a3.21,3.21,0,0,1-4.69,0c-.9-1-.88-2.79-.88-5.17s0-4.15.88-5.17a3.21,3.21,0,0,1,4.69,0c.9,1,.89,2.79.89,5.17S394.49,46.39,393.59,47.41Zm-1.43-9.18a1.13,1.13,0,0,0-1.82,0c-.35.58-.42,1.8-.42,4s.07,3.43.42,4a1.13,1.13,0,0,0,1.82,0c.36-.58.41-1.8.41-4S392.52,38.81,392.16,38.23Z" style="fill: #929497"/>
      <path d="M401,48.29l-.5-2.4h-2.8l-.48,2.4h-2l3-12.1h1.85L403,48.29Zm-1.89-9.18-1,5.07h2.08Z" style="fill: #929497"/>
      <path d="M404.15,48.29V36.19h1.9V46.57h3.18v1.72Z" style="fill: #929497"/>
    </g>
    <line y1="79.92" x2="325.15" y2="79.85" style="fill: none;stroke: #929497;stroke-linecap: round;stroke-linejoin: round"/>
    <g style="clip-path: url(#clip-path)">
      <path d="M337,81.85a.82.82,0,0,0,.65,0,.75.75,0,0,0,.28-.18l10.25-9.89a.82.82,0,0,0,0-1.17.88.88,0,0,0-1.21,0l-8.79,8.49V53.87a.86.86,0,0,0-1.71,0V79.1l-8.79-8.49a.88.88,0,0,0-1.21,0,.79.79,0,0,0-.25.58.81.81,0,0,0,.25.59l10.25,9.89a.75.75,0,0,0,.28.18" style="fill: #929497"/>
    </g>
    <g style="clip-path: url(#clip-path-2)">
      <path d="M230.27,103.2a.5.5,0,0,0,.34,0l.15-.1L236.08,98a.42.42,0,0,0,0-.6.45.45,0,0,0-.63,0l-4.57,4.41V88.66a.44.44,0,0,0-.88,0v13.11l-4.57-4.41a.45.45,0,0,0-.63,0,.41.41,0,0,0,0,.6l5.33,5.14a.71.71,0,0,0,.14.1" style="fill: #82c341"/>
    </g>
    <g style="clip-path: url(#clip-path-3)">
      <path d="M176.94,78.53a.5.5,0,0,0,.34,0,.42.42,0,0,0,.14-.09l5.33-5.14a.43.43,0,0,0,0-.61.45.45,0,0,0-.63,0l-4.57,4.41V64a.45.45,0,0,0-.89,0V77.1l-4.56-4.41a.45.45,0,0,0-.63,0,.39.39,0,0,0-.13.3.43.43,0,0,0,.13.31l5.32,5.14a.38.38,0,0,0,.15.09" style="fill: #82c341"/>
    </g>
    <g style="clip-path: url(#clip-path-4)">
      <path d="M121.6,68.53a.5.5,0,0,0,.34,0,.38.38,0,0,0,.15-.09l5.32-5.14a.41.41,0,0,0,0-.61.44.44,0,0,0-.62,0l-4.57,4.41V54a.45.45,0,0,0-.89,0V67.1l-4.57-4.41a.45.45,0,0,0-.63,0,.43.43,0,0,0-.13.3.48.48,0,0,0,.13.31l5.33,5.14a.42.42,0,0,0,.14.09" style="fill: #82c341"/>
    </g>
    <g style="clip-path: url(#clip-path-5)">
      <path d="M65.6,56.2a.5.5,0,0,0,.34,0,.56.56,0,0,0,.15-.1L71.41,51a.4.4,0,0,0,0-.6.44.44,0,0,0-.62,0l-4.57,4.41V41.66a.45.45,0,0,0-.89,0V54.77l-4.57-4.41a.45.45,0,0,0-.63,0,.41.41,0,0,0,0,.6l5.33,5.14a.71.71,0,0,0,.14.1" style="fill: #82c341"/>
    </g>
    <g style="clip-path: url(#clip-path-6)">
      <path d="M10.6,48.2a.5.5,0,0,0,.34,0,.56.56,0,0,0,.15-.1L16.41,43a.4.4,0,0,0,0-.6.44.44,0,0,0-.62,0l-4.57,4.41V33.66a.45.45,0,0,0-.89,0V46.77L5.76,42.36a.45.45,0,0,0-.63,0,.41.41,0,0,0,0,.6l5.33,5.14a.71.71,0,0,0,.14.1" style="fill: #82c341"/>
    </g>
    <g style="clip-path: url(#clip-path-7)">
      <path d="M283.27,108.53a.5.5,0,0,0,.34,0,.6.6,0,0,0,.15-.09l5.32-5.14a.43.43,0,0,0,0-.61.45.45,0,0,0-.63,0l-4.57,4.41V94a.44.44,0,0,0-.88,0V107.1l-4.57-4.41a.45.45,0,0,0-.63,0,.39.39,0,0,0-.13.3.43.43,0,0,0,.13.31l5.33,5.14a.42.42,0,0,0,.14.09" style="fill: #005cb9"/>
    </g>
    <g>
      <polygon points="319.22 93.64 316.89 95.61 319.24 97.6 321.57 95.62 319.22 93.64" style="fill: #005cb9"/>
      <path d="M318.89,95.62l.33-1.05.33,1.05Zm.18-1.27-.72,2.14h.26l.21-.66h.8l.2.66h.29l-.71-2.14Z" style="fill: #fff"/>
    </g>
  </g>
</svg>
				<span class="footnote margin-top-20"><img src="../_images/scorecard/global/a.svg" class="aNote"> Reviewed by Ernst & Young LLP. Please refer to the <a href="../financials/index.php#review" class="link hideLinkMobile">Review Report</a><a href="../financials/nonfinancial.pdf" class="link mobileLinkOnly" target="_blank">Review Report</a>.</span>
			</div>
		</div>
	</div>
</div>
<div class="subnav subnav--strategy">
	<div class="container">
		<div class="row">
			<ul class="subNav__items">
				<li><a href="index.php">2020 <br>Strategy</a></li>
				<li><a href="people.php">Engage Our <br>People</a></li>
				<li><a href="value.php">Drive Superior <br>Consumer Value</a></li>
				<li><a href="portfolio.php">Accelerate <br>Portfolio Momentum</a></li>
				<li><a href="growth.php">Fund <br>Growth</a></li>
			</ul>
		</div>
	</div>
</div>
<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="../_js/jquery.fancybox.min.js"></script>
<script src="../_js/jquery.mousewheel.js"></script>
<script src="../_js/greensock/TimelineMax.min.js"></script>
<script src="../_js/greensock/TweenMax.min.js"></script>
<script src="../_js/ScrollMagic.js"></script>
<script src="../_js/plugins/jquery.ScrollMagic.js"></script>
<script src="../_js/plugins/debug.addIndicators.js"></script>
<script src="../_js/greensock/plugins/DrawSVGPlugin.min.js"></script>
<script src="../_js/plugins/animation.gsap.js"></script>
<script src="../_js/jquery.cycle2.min.js"></script>
<script src="../_js/main.js?v.2018.2"></script><script>strategy();</script>
</body>
</html>
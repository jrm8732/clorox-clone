<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=Edge"/>
<meta charset="UTF-8"><script type="text/javascript">window.NREUM||(NREUM={}),__nr_require=function(e,n,t){function r(t){if(!n[t]){var o=n[t]={exports:{}};e[t][0].call(o.exports,function(n){var o=e[t][1][n];return r(o||n)},o,o.exports)}return n[t].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<t.length;o++)r(t[o]);return r}({1:[function(e,n,t){function r(){}function o(e,n,t){return function(){return i(e,[c.now()].concat(u(arguments)),n?null:this,t),n?void 0:this}}var i=e("handle"),a=e(3),u=e(4),f=e("ee").get("tracer"),c=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],d="api-",l=d+"ixn-";a(p,function(e,n){s[n]=o(d+n,!0,"api")}),s.addPageAction=o(d+"addPageAction",!0),s.setCurrentRouteName=o(d+"routeName",!0),n.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,n){var t={},r=this,o="function"==typeof n;return i(l+"tracer",[c.now(),e,t],r),function(){if(f.emit((o?"":"no-")+"fn-start",[c.now(),r,o],t),o)try{return n.apply(this,arguments)}catch(e){throw f.emit("fn-err",[arguments,this,e],t),e}finally{f.emit("fn-end",[c.now()],t)}}}};a("actionText,setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,n){m[n]=o(l+n)}),newrelic.noticeError=function(e,n){"string"==typeof e&&(e=new Error(e)),i("err",[e,c.now(),!1,n])}},{}],2:[function(e,n,t){function r(e,n){if(!o)return!1;if(e!==o)return!1;if(!n)return!0;if(!i)return!1;for(var t=i.split("."),r=n.split("."),a=0;a<r.length;a++)if(r[a]!==t[a])return!1;return!0}var o=null,i=null,a=/Version\/(\S+)\s+Safari/;if(navigator.userAgent){var u=navigator.userAgent,f=u.match(a);f&&u.indexOf("Chrome")===-1&&u.indexOf("Chromium")===-1&&(o="Safari",i=f[1])}n.exports={agent:o,version:i,match:r}},{}],3:[function(e,n,t){function r(e,n){var t=[],r="",i=0;for(r in e)o.call(e,r)&&(t[i]=n(r,e[r]),i+=1);return t}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],4:[function(e,n,t){function r(e,n,t){n||(n=0),"undefined"==typeof t&&(t=e?e.length:0);for(var r=-1,o=t-n||0,i=Array(o<0?0:o);++r<o;)i[r]=e[n+r];return i}n.exports=r},{}],5:[function(e,n,t){n.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,n,t){function r(){}function o(e){function n(e){return e&&e instanceof r?e:e?f(e,u,i):i()}function t(t,r,o,i){if(!d.aborted||i){e&&e(t,r,o);for(var a=n(o),u=v(t),f=u.length,c=0;c<f;c++)u[c].apply(a,r);var p=s[y[t]];return p&&p.push([b,t,r,a]),a}}function l(e,n){h[e]=v(e).concat(n)}function m(e,n){var t=h[e];if(t)for(var r=0;r<t.length;r++)t[r]===n&&t.splice(r,1)}function v(e){return h[e]||[]}function g(e){return p[e]=p[e]||o(t)}function w(e,n){c(e,function(e,t){n=n||"feature",y[t]=n,n in s||(s[n]=[])})}var h={},y={},b={on:l,addEventListener:l,removeEventListener:m,emit:t,get:g,listeners:v,context:n,buffer:w,abort:a,aborted:!1};return b}function i(){return new r}function a(){(s.api||s.feature)&&(d.aborted=!0,s=d.backlog={})}var u="nr@context",f=e("gos"),c=e(3),s={},p={},d=n.exports=o();d.backlog=s},{}],gos:[function(e,n,t){function r(e,n,t){if(o.call(e,n))return e[n];var r=t();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,n,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return e[n]=r,r}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],handle:[function(e,n,t){function r(e,n,t,r){o.buffer([e],r),o.emit(e,n,t)}var o=e("ee").get("handle");n.exports=r,r.ee=o},{}],id:[function(e,n,t){function r(e){var n=typeof e;return!e||"object"!==n&&"function"!==n?-1:e===window?0:a(e,i,function(){return o++})}var o=1,i="nr@id",a=e("gos");n.exports=r},{}],loader:[function(e,n,t){function r(){if(!E++){var e=x.info=NREUM.info,n=l.getElementsByTagName("script")[0];if(setTimeout(s.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&n))return s.abort();c(y,function(n,t){e[n]||(e[n]=t)}),f("mark",["onload",a()+x.offset],null,"api");var t=l.createElement("script");t.src="https://"+e.agent,n.parentNode.insertBefore(t,n)}}function o(){"complete"===l.readyState&&i()}function i(){f("mark",["domContent",a()+x.offset],null,"api")}function a(){return O.exists&&performance.now?Math.round(performance.now()):(u=Math.max((new Date).getTime(),u))-x.offset}var u=(new Date).getTime(),f=e("handle"),c=e(3),s=e("ee"),p=e(2),d=window,l=d.document,m="addEventListener",v="attachEvent",g=d.XMLHttpRequest,w=g&&g.prototype;NREUM.o={ST:setTimeout,SI:d.setImmediate,CT:clearTimeout,XHR:g,REQ:d.Request,EV:d.Event,PR:d.Promise,MO:d.MutationObserver};var h=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1118.min.js"},b=g&&w&&w[m]&&!/CriOS/.test(navigator.userAgent),x=n.exports={offset:u,now:a,origin:h,features:{},xhrWrappable:b,userAgent:p};e(1),l[m]?(l[m]("DOMContentLoaded",i,!1),d[m]("load",r,!1)):(l[v]("onreadystatechange",o),d[v]("onload",r)),f("mark",["firstbyte",u],null,"api");var E=0,O=e(5)},{}]},{},["loader"]);</script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="../_images/global/shareImage.png?v.2018.1" />

<title>Clorox 2018 Integrated Annual Report</title>
<link rel="stylesheet" href="../_css/main.css?v.2018.4">
<link rel="stylesheet" href="../_js/jquery.fancybox.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	    <script src="//assets.adobedtm.com/cfd7100a02cbfa40b2c485d333da22f89ccabd9c/satelliteLib-e1a96af74edf26406b64b1c5cb0abedb7b5a6c6c.js"></script>
	</head>
<body class="strategyLanding">
<header>
	<div class="header__hamburger">
		<span>MENU</span>
		<div class="header__hamburger__bars">
			<div></div>
		</div>
	</div>

	<a class="logoWrap" href="../index.php">
		<img class="header__logo" src="../_images/global/logo.svg">
	</a>
    <div class="container container--header">
        <div class="row">
			<div class="header__links">
				<span class="ir">2018 Integrated Annual Report</span>
				<ul>
					<li><a class="header__links__resources" href="#">Resources</a></li>
					<li><a class="header__links__download" href="#">Download</a></li>
					<li><a class="header__links__search" href="#"><i class="fas fa-search"></i></a></li>
					<li class="socialLink facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="socialLink twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
					<li class="socialLink linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="socialLink"><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
				</ul>
			</div>

			<div class="headerSearch">
				<div class="headerSearch__relativeWrapper">
					<form action="../search.php">
						<input class="headerSearch__input" type="text" class="search" name="q" id="tipue_search_input" autocomplete="off" placeholder="Search" required="">
						<span class="headerSearch__del">X</span>
					</form>
				</div>
			</div>

			<div class="headerResources">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../about.php">About This Report</a></li>
						<li><a href="../materiality.php">Materiality Overview</a></li>
						<li><a href="../gri.php">GRI Content Index</a></li>
						<li><a href="../info.php">Stockholder Information</a></li>
						<li><a target="_blank" href="https://www.thecloroxcompany.com/">The Clorox Company</a></li>
					</ul>
				</div>
			</div>

			<div class="downloads">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../Clorox_2018_Integrated_Report.pdf?v10-11-2018" target="_blank">Full PDF</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_English.pdf" target="_blank">Executive Summary English</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_Spanish.pdf" target="_blank">Executive Summary Spanish</a></li>
					</ul>
				</div>
			</div>
        </div>
	</div>

	<nav class="mainNav">
		<div class="mainNav__box mainNav__box--1">
			<a class="mainNav__mainLink" href="../ceo-letter/">CEO Letter</a>

			<img src="../_images/global/nav1.png" class="mainNav__product mainNav__product--1">
		</div>

		<div class="mainNav__box mainNav__box--2">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../strategy/">2020 Strategy</a>

				<ul class="secondaryNav">
					<li><a href="../strategy/people.php">Engage our People</a></li>
					<li><a href="../strategy/value.php">Drive Superior Consumer Value</a></li>
					<li><a href="../strategy/portfolio.php">Accelerate Portfolio Momentum</a></li>
					<li><a href="../strategy/growth.php">Fund Growth</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav2.png" class="mainNav__product mainNav__product--2">
		</div>

		<div class="mainNav__box mainNav__box--3">
			<a class="mainNav__mainLink" href="../innovation/">Innovation</a>

			<img src="../_images/global/nav3.png" class="mainNav__product mainNav__product--3">
		</div>

		<div class="mainNav__box mainNav__box--4">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../scorecard/">Scorecard</a>

				<ul class="secondaryNav">
					<li><a href="../scorecard/footprint.php">Global Footprint</a></li>
					<li><a href="../scorecard/performance.php">Performance</a></li>
					<li><a href="../scorecard/product.php">Product</a></li>
					<li><a href="../scorecard/people.php">People</a></li>
					<li><a href="../scorecard/community.php">Community</a></li>
					<li><a href="../scorecard/planet.php">Planet</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav4.png" class="mainNav__product mainNav__product--4">
		</div>

		<div class="mainNav__box mainNav__box--5">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../recognitions/">Recognitions</a>

				<ul class="secondaryNav">
					<li><a href="../recognitions/">Company Recognitions</a></li>
					<li><a href="../recognitions/brand.php">Brand Recognitions</a></li>
				</ul>
			</div>
			<img src="../_images/global/nav5.png" class="mainNav__product mainNav__product--5">
		</div>

		<div class="mainNav__box mainNav__box--6">
			<a class="mainNav__mainLink" href="../financials/">Financials</a>

			<img src="../_images/global/nav6.png" class="mainNav__product mainNav__product--6">
		</div>

		<div class="mainNav__box mainNav__box--7">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../governance/">Governance</a>

				<ul class="secondaryNav">
					<li><a href="../governance/board.php">Board of Directors</a></li>
					<li><a href="../governance/committee.php">Executive Committee</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav7.png" class="mainNav__product mainNav__product--7">
		</div>

		<div class="mainNav__box mainNav__box--mobile">
			<ul>
				<li class="facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li class="twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li class="linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
			</ul>
		</div>
	</nav>
</header>
<div class="interiorWrapper interiorWrapper--strategyLanding">
	<div class="container">
		<div class="row">
			<h1 class="strategyHeading">2020 Strategy</h1>
		</div>
		<div class="row">
			<div class="strategyLandingWrapper strategyLandingWrapper--large">
				<div class="strategyLandingHalf strategyLandingHalf--left">
					<p>In its sixth and penultimate year, our 2020 Strategy continued to serve as a guidepost for the company. Value, Innovation and Leadership, hallmarks of our business and corporate responsibility strategies, drive us toward our goal of Good Growth — that’s profitable, sustainable and responsible.</p>
				</div>
				<div class="strategyLandingHalf strategyLandingHalf--right">
					<h4>Mission</h4>
					<p>We make everyday life better, every day.</p>
					
					<h4>Objective</h4>
					<p>Be the best at building big-share brands in midsized categories.</p>

					<h4>Commitment</h4>
					<p>Leverage environmental, social and governance performance to help drive long-term, sustainable value creation.</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="strategyLandingWrapper strategyLandingWrapper--small">
				<h3 class="heading">Strategies</h3>
				<p class="caption">Click on a strategy to learn more.</p>
				
				<table class="strategyLandingTable">
					<tbody>
						<tr>
							<th>&nbsp;</th>
							<th>Business</th>
							<th>Corporate Responsibility</th>
						</tr>
						<tr class="strategyLink" data-link="1">
							<td><a href="people.php"><span>01</span></a></td>
							<td><a href="people.php">Engage our people as business owners.</a></td>
							<td><a href="people.php">Promote diversity, opportunity and respectful treatment for all people who touch our business.</a></td>
						</tr>
						<tr class="strategyLink" data-link="2">
							<td><a href="value.php"><span>02</span></a></td>
							<td><a href="value.php">Drive superior consumer value behind strong brand investment, innovation and technology transformation.</a></td>
							<td><a href="value.php">Make responsible products responsibly.</a></td>
						</tr>
						<tr class="strategyLink" data-link="3">
							<td><a href="portfolio.php"><span>03</span></a></td>
							<td><a href="portfolio.php">Accelerate portfolio momentum in and around the core.</a></td>
							<td><a href="portfolio.php">Safeguard families through initiatives that promote health, education and safety.</a></td>
						</tr>
						<tr class="strategyLink" data-link="4">
							<td><a href="growth.php"><span>04</span></a></td>
							<td><a href="growth.php">Fund growth by reducing waste in our work, products and supply chain.</a></td>
							<td><a href="growth.php">Shrink our environmental footprint while we grow.</a></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		<div class="row">
			<div class="strategyLandingWrapper strategyLandingWrapper--small">
				<h1 class="heading">Annual Long-Term Aspirations</h1>
				<div class="strategyAspirations__stat">
					<h5 class="strategyAspirations__stat__title">Grow</h5>
					<span class="strategyAspirations__stat__med">Net Sales By</span>
					<br>
					<span class="strategyAspirations__stat__large">+3-5%</span>
				</div>
				<div class="strategyAspirations__stat">
					<h5 class="strategyAspirations__stat__title">Expand</h5>
					<span class="strategyAspirations__stat__med">EBIT Margin</span>
					<br>
					<span class="strategyAspirations__stat__large">+25-50</span>
					<br>
					<span class="strategyAspirations__stat__small">Basis Points</span>
				</div>
				<div class="strategyAspirations__stat">
					<h5 class="strategyAspirations__stat__title">Deliver</h5>
					<span class="strategyAspirations__stat__med">Free Cash Flow as a % of Net Sales</span>
					<br>
					<span class="strategyAspirations__stat__large">11-13%</span>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="strategyLandingWrapper strategyLandingWrapper--med strategyLandingWrapper--last">
				<h1 class="heading margin-bottom-20">Operating Model</h1>
				<h2 class="subHeading">Factors Driving Our Business Success</h2>
				<p>To achieve our business goals, we need to leverage the unique attributes of our company; strengthen our relationships with important partners such as our employees, non-retail customers and communities; and manage external factors that can influence our success.</p>

				<div class="strategyModel__wrapper">
					<div class="strategyModel">
						<div class="strategyModel__icon strategyModel__icon--1">
							<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="47.1" height="41.83" viewBox="0 0 47.1 41.83">
  <title>icon1</title>
  <path d="M28.11,36.07A3.09,3.09,0,0,0,32.3,36a3,3,0,0,0,.11-4.12l-3.62-3.55m3.62,3.55a3.09,3.09,0,0,0,4.19-.11,3,3,0,0,0,.11-4.11L33,23.92M23.08,6.53A11.53,11.53,0,0,0,13,.73,12.22,12.22,0,0,0,.73,12.83c0,4.75,3.53,8.3,3.53,8.3l4.16,4.12M20.19,36.9l3.38,3.32a3.12,3.12,0,0,0,4.34,0A3,3,0,0,0,28,36.08L24.38,32.5m12.4-5a3.07,3.07,0,0,0,4.32-.27l0,0a3,3,0,0,0-.26-4.1l-5.37-5.3" style="fill: none;stroke: #48a842;stroke-linecap: round;stroke-linejoin: round;stroke-width: 1.4670000076293945px"/>
  <path d="M22.44,7.6l-9.24,9a2.12,2.12,0,0,0-.32,3,2.24,2.24,0,0,0,.45.42,2.57,2.57,0,0,0,3.48.1l3.89-3.83c3.88-3.84,8.46-4.71,12.36-.89L40.83,23a12,12,0,0,0,5.54-10.08A11.69,11.69,0,0,0,34.64.88C28.19.88,22.44,7.6,22.44,7.6ZM7.11,29.42h0a2,2,0,0,1,0-2.83l0,0,2.34-2.28a2.08,2.08,0,0,1,2.91,0,2,2,0,0,1,0,2.83l0,0L10,29.42A2.1,2.1,0,0,1,7.11,29.42Zm3,2.91h0a2,2,0,0,1,0-2.83l0,0,2.34-2.28a2.08,2.08,0,0,1,2.91,0,2,2,0,0,1,0,2.83l0,0L13,32.33A2.11,2.11,0,0,1,10.07,32.33ZM13,35.24h0a2,2,0,0,1,0-2.83l0,0,2.34-2.29a2.1,2.1,0,0,1,2.91,0,2,2,0,0,1,0,2.83l0,0L16,35.24a2.1,2.1,0,0,1-3,0Zm3,2.91h0a2,2,0,0,1,0-2.83l0,0L18.33,33a2.11,2.11,0,0,1,2.92,0,2,2,0,0,1,0,2.83l0,0-2.34,2.29A2.1,2.1,0,0,1,16,38.15Z" style="fill: none;stroke: #005cb9;stroke-linecap: round;stroke-linejoin: round;stroke-width: 1.4670000076293945px"/>
</svg>
							<h5>&nbsp; <br>Foundation</h5>
						</div>
						<ul class="strategyModel__list">
							<li>Our Values
								<ul class="strategyModel__subList list">
									<li>Do the right thing</li>
									<li>Stretch for results</li>
									<li>Take personal ownership</li>
									<li>Work together to win</li>
								</ul>
							</li>
							<li>Our Resources
								<ul class="strategyModel__subList list">
									<li>Consumers</li>
									<li>Employees</li>
									<li>Retail and Non-Retail</li>
									<li>Customers</li>
									<li>Suppliers and Other</li>
									<li>Business Partners</li>
									<li>Communities</li>
									<li>Investors</li>
									<li>Civil Society/NGOs</li>
								</ul>
							</li>
						</ul>
					</div>
					<div class="strategyModel">
						<div class="strategyModel__icon strategyModel__icon--2">
							<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="58.84" height="41.06" viewBox="0 0 58.84 41.06">
  <title>icon2</title>
  <path d="M35.43,35.51a2.65,2.65,0,0,1-3.18,4.24h0l-2.66-1.89m10.23-5.72a2.65,2.65,0,0,1-3.19,4.23l-3.48-2.62M43.7,28.43a2.65,2.65,0,0,1-3.18,4.23L35.1,28.59M46.74,24a2.65,2.65,0,0,1-3.19,4.23l-5.41-4.06m-37.4-5L8.33,24l10-16.2-8-5.14ZM18.2,7.74l11.14.5M8.33,24l4.72,3.38" style="fill: none;stroke: #005cb9;stroke-linecap: round;stroke-linejoin: round;stroke-width: 1.4700000286102295px"/>
  <path d="M19.14,38h0a2.37,2.37,0,0,1,0-3.34l5.25-5.25a2.37,2.37,0,0,1,3.35,3.34L22.48,38A2.37,2.37,0,0,1,19.14,38Zm-3.88-2.86h0a2.38,2.38,0,0,1,0-3.35l5.25-5.25a2.36,2.36,0,0,1,3.34,3.34L18.6,35.15a2.38,2.38,0,0,1-3.34,0Zm9.18,4.48h0a2.38,2.38,0,0,1,0-3.34l1.47-1.47a2.36,2.36,0,0,1,3.34,3.34l-1.46,1.47a2.38,2.38,0,0,1-3.35,0ZM11.72,32.11h0a2.37,2.37,0,0,1,0-3.34l1.35-1.36,2.7-2.7a2.37,2.37,0,0,1,3.35,3.34l-4.06,4.06A2.37,2.37,0,0,1,11.72,32.11ZM47,.74l-8.8,5.4,12,17.21,7.93-5.23Zm3.21,22.61-1.77,1.77L32.35,13.41l-10.47,5.7a3,3,0,0,1-3.32-5,3.75,3.75,0,0,1,.44-.24L30.6,7.55h8.59" style="fill: none;stroke: #48a842;stroke-linecap: round;stroke-linejoin: round;stroke-width: 1.4700000286102295px"/>
</svg>
							<h5>Our <br>Relationships</h5>
						</div>	
						<ul class="strategyModel__list">
							<li>Consumers</li>
							<li>Employees</li>
							<li>Retail and Non-Retail</li>
							<li>Customers</li>
							<li>Suppliers and Other<br> Business Partners</li>
							<li>Communities</li>
							<li>Investors</li>
							<li>Civil Society/NGOs</li>
						</ul>
					</div>
					<div class="strategyModel">
						<div class="strategyModel__icon strategyModel__icon--3">
							<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="48.76" height="49.6" viewBox="0 0 48.76 49.6">
  <title>icon3</title>
  <circle cx="23.95" cy="29.89" r="18.73" style="fill: none;stroke: #005cb9;stroke-linecap: round;stroke-linejoin: round;stroke-width: 1.4700000286102295px;stroke-dasharray: 0.9630863070487976,2.3050591945648193"/>
  <path d="M30.45,27.72l2.11-3.34-2.87-2.86-3.07,2.36L25.74,20h-4l-.5,3.84-3.08-2.36L15.3,24.34l2.1,3.34-3.84.51v4l3.84.88L15,36.22l2.86,2.87L21.19,37l.5,3.84h4L26.62,37,30,39.09l2.87-2.87L30.5,33.15l3.85-.88v-4Zm-3,2.53a3.68,3.68,0,1,0-3.68,3.68,3.68,3.68,0,0,0,3.68-3.68v0Z" style="fill: none;stroke: #48a842;stroke-linecap: round;stroke-linejoin: round;stroke-width: 1.4700000286102295px"/>
  <path d="M14.21,43.39v-.71a.61.61,0,0,0-.28-.53L9.8,39.45a.62.62,0,0,1-.26-.72A11.93,11.93,0,0,0,10,35.17c0-1.37-.73-3.05-2.63-3.05C5.68,32.12,5,33.17,5,35.17a11.61,11.61,0,0,0,.46,3.56.62.62,0,0,1-.26.72L1,42.15a.61.61,0,0,0-.28.53v.71a.63.63,0,0,0,.63.63H13.58a.63.63,0,0,0,.63-.63ZM30.22,12v-.71a.64.64,0,0,0-.29-.53l-4.55-3a9.74,9.74,0,0,0,.63-4c0-1.37-.53-3-2.42-3-1.69,0-2.59,1-2.59,3a11.61,11.61,0,0,0,.46,3.56.62.62,0,0,1-.26.72L17,10.76a.64.64,0,0,0-.29.53V12a.64.64,0,0,0,.63.64H29.59A.64.64,0,0,0,30.22,12ZM48,43.28V42.23l-4.4-2.88a.64.64,0,0,1-.26-.72,11.62,11.62,0,0,0,.47-3.56c0-1.37-.74-3.06-2.63-3.06-1.69,0-2.43,1.06-2.43,3.06a11.62,11.62,0,0,0,.47,3.56.64.64,0,0,1-.26.72L34.83,42a.64.64,0,0,0-.29.53v.71a.63.63,0,0,0,.63.63H47.39A.63.63,0,0,0,48,43.28Z" style="fill: #fff;stroke: #48a842;stroke-linecap: round;stroke-linejoin: round;stroke-width: 1.4700000286102295px"/>
</svg>
	
							<h5>External <br>Influences</h5>
						</div>	
						<ul class="strategyModel__list">
							<li>Laws and Regulations</li>
							<li>Global Economy</li>
							<li>Natural Resources</li>
							<li>Competition</li>
							<li>Raw Materials and Other<br> Input Costs</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="landingFooter"><div class="subnav subnav--strategy">
	<div class="container">
		<div class="row">
			<ul class="subNav__items">
				<li><a href="index.php">2020 <br>Strategy</a></li>
				<li><a href="people.php">Engage Our <br>People</a></li>
				<li><a href="value.php">Drive Superior <br>Consumer Value</a></li>
				<li><a href="portfolio.php">Accelerate <br>Portfolio Momentum</a></li>
				<li><a href="growth.php">Fund <br>Growth</a></li>
			</ul>
		</div>
	</div>
</div></div>

<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="../_js/jquery.fancybox.min.js"></script>
<script src="../_js/jquery.mousewheel.js"></script>
<script src="../_js/greensock/TimelineMax.min.js"></script>
<script src="../_js/greensock/TweenMax.min.js"></script>
<script src="../_js/ScrollMagic.js"></script>
<script src="../_js/plugins/jquery.ScrollMagic.js"></script>
<script src="../_js/plugins/debug.addIndicators.js"></script>
<script src="../_js/greensock/plugins/DrawSVGPlugin.min.js"></script>
<script src="../_js/plugins/animation.gsap.js"></script>
<script src="../_js/jquery.cycle2.min.js"></script>
<script src="../_js/main.js?v.2018.2"></script><script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"90a95d8474","applicationID":"2526212","transactionName":"MgRaYxZVDBIDW0BbWQtObUUNGxEVEFlAV1EcTlFZAFEaTxJQRA==","queueTime":0,"applicationTime":1,"atts":"HkNZFV5PHxw=","errorBeacon":"bam.nr-data.net","agent":""}</script></body>
</html>
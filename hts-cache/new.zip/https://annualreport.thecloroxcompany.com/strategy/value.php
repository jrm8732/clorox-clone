<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=Edge"/>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="../_images/global/shareImage.png?v.2018.1" />

<title>Clorox 2018 Integrated Annual Report</title>
<link rel="stylesheet" href="../_css/main.css?v.2018.4">
<link rel="stylesheet" href="../_js/jquery.fancybox.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	    <script src="//assets.adobedtm.com/cfd7100a02cbfa40b2c485d333da22f89ccabd9c/satelliteLib-e1a96af74edf26406b64b1c5cb0abedb7b5a6c6c.js"></script>
	</head>
<body class="strategyValue">
<header>
	<div class="header__hamburger">
		<span>MENU</span>
		<div class="header__hamburger__bars">
			<div></div>
		</div>
	</div>

	<a class="logoWrap" href="../index.php">
		<img class="header__logo" src="../_images/global/logo.svg">
	</a>
    <div class="container container--header">
        <div class="row">
			<div class="header__links">
				<span class="ir">2018 Integrated Annual Report</span>
				<ul>
					<li><a class="header__links__resources" href="#">Resources</a></li>
					<li><a class="header__links__download" href="#">Download</a></li>
					<li><a class="header__links__search" href="#"><i class="fas fa-search"></i></a></li>
					<li class="socialLink facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="socialLink twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
					<li class="socialLink linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="socialLink"><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
				</ul>
			</div>

			<div class="headerSearch">
				<div class="headerSearch__relativeWrapper">
					<form action="../search.php">
						<input class="headerSearch__input" type="text" class="search" name="q" id="tipue_search_input" autocomplete="off" placeholder="Search" required="">
						<span class="headerSearch__del">X</span>
					</form>
				</div>
			</div>

			<div class="headerResources">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../about.php">About This Report</a></li>
						<li><a href="../materiality.php">Materiality Overview</a></li>
						<li><a href="../gri.php">GRI Content Index</a></li>
						<li><a href="../info.php">Stockholder Information</a></li>
						<li><a target="_blank" href="https://www.thecloroxcompany.com/">The Clorox Company</a></li>
					</ul>
				</div>
			</div>

			<div class="downloads">
				<div class="headerResources__relativeWrapper">
					<ul>
						<li><a href="../Clorox_2018_Integrated_Report.pdf?v10-11-2018" target="_blank">Full PDF</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_English.pdf" target="_blank">Executive Summary English</a></li>
						<li><a href="../Clorox_2018_Executive_Summary_Spanish.pdf" target="_blank">Executive Summary Spanish</a></li>
					</ul>
				</div>
			</div>
        </div>
	</div>

	<nav class="mainNav">
		<div class="mainNav__box mainNav__box--1">
			<a class="mainNav__mainLink" href="../ceo-letter/">CEO Letter</a>

			<img src="../_images/global/nav1.png" class="mainNav__product mainNav__product--1">
		</div>

		<div class="mainNav__box mainNav__box--2">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../strategy/">2020 Strategy</a>

				<ul class="secondaryNav">
					<li><a href="../strategy/people.php">Engage our People</a></li>
					<li><a href="../strategy/value.php">Drive Superior Consumer Value</a></li>
					<li><a href="../strategy/portfolio.php">Accelerate Portfolio Momentum</a></li>
					<li><a href="../strategy/growth.php">Fund Growth</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav2.png" class="mainNav__product mainNav__product--2">
		</div>

		<div class="mainNav__box mainNav__box--3">
			<a class="mainNav__mainLink" href="../innovation/">Innovation</a>

			<img src="../_images/global/nav3.png" class="mainNav__product mainNav__product--3">
		</div>

		<div class="mainNav__box mainNav__box--4">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../scorecard/">Scorecard</a>

				<ul class="secondaryNav">
					<li><a href="../scorecard/footprint.php">Global Footprint</a></li>
					<li><a href="../scorecard/performance.php">Performance</a></li>
					<li><a href="../scorecard/product.php">Product</a></li>
					<li><a href="../scorecard/people.php">People</a></li>
					<li><a href="../scorecard/community.php">Community</a></li>
					<li><a href="../scorecard/planet.php">Planet</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav4.png" class="mainNav__product mainNav__product--4">
		</div>

		<div class="mainNav__box mainNav__box--5">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../recognitions/">Recognitions</a>

				<ul class="secondaryNav">
					<li><a href="../recognitions/">Company Recognitions</a></li>
					<li><a href="../recognitions/brand.php">Brand Recognitions</a></li>
				</ul>
			</div>
			<img src="../_images/global/nav5.png" class="mainNav__product mainNav__product--5">
		</div>

		<div class="mainNav__box mainNav__box--6">
			<a class="mainNav__mainLink" href="../financials/">Financials</a>

			<img src="../_images/global/nav6.png" class="mainNav__product mainNav__product--6">
		</div>

		<div class="mainNav__box mainNav__box--7">
			<div class="mainNav__linkWrap">
				<a class="mainNav__mainLink" href="../governance/">Governance</a>

				<ul class="secondaryNav">
					<li><a href="../governance/board.php">Board of Directors</a></li>
					<li><a href="../governance/committee.php">Executive Committee</a></li>
				</ul>
			</div>

			<img src="../_images/global/nav7.png" class="mainNav__product mainNav__product--7">
		</div>

		<div class="mainNav__box mainNav__box--mobile">
			<ul>
				<li class="facebook" id="facebook"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li class="twitter" id="twitter"><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li class="linkedIn" id="linkedIn"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="mailto:corporate.communications@clorox.com"><i class="fas fa-envelope"></i></a></li>
			</ul>
		</div>
	</nav>
</header>
<div class="interiorWrapper">
	<div class="container">
		<div class="row">
			<div class="sectionBoxWrap">
				<div class="sectionBox sectionBox--value">
					<div class="sectionName">Strategy</div>
					<div class="sectionNumber">02</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="hero">
				<h1 class="pageTitle pageTitle--value">Drive Superior<br class="valueBreak"> Consumer Value</h1>
				<img src="../_images/strategy/value/hero.jpg">

				<div class="hero__whiteBar"></div>
			</div>
		</div>

		<div class="row">
			<div class="content content--start fade fade--up">
				<h1 class="heading">Business Highlights</h1>
				<h2 class="sectionSubHeading">Drive superior consumer value behind strong brand investment, innovation and technology transformation.</h2>
				<ul class="list">
					<li>
						Clorox delivered 3 percent of incremental sales behind product innovation — the eighth consecutive year of this achievement. Some of the new products introduced in fiscal year 2018 included the following:
						<ul class="list list--indented">
							<li>Burt’s Bees cosmetics, masks, lip treatments and liquid lipsticks</li>
							<li>Clorox disinfecting wipes (Easy to Pull), Clorox Scentiva bathroom foam cleaner, Clorox bleach with Cloromax</li>
							<li>Totally Spot-Less Powered by Clorox 2<sup>&reg;</sup></li>
							<li>Kingsford EcoLight charcoal lighter</li>
							<li>RenewLife probiotics + organic prebiotics (Daily Balance, Women’s Daily, Kids Daily, Strong &amp; Ready, Settle &amp; Restore, Return to Regular)</li>
						</ul>
					</li>
				</ul>
			</div>
			
			<div class="peopleStatWrap--1 fade fade--left">
				<div class="peopleCallout--1">
					<div class="calloutNum calloutNum--green">+3%</div>
					<div class="calloutText calloutText--green"><strong>INCREMENTAL SALES <br>FROM PRODUCT <br>INNOVATION</strong></div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="valueImg valueImg--offsetOne fade fade--right">
				<img src="../_images/strategy/value/image1.jpg" alt="">
				<p class="caption">We built on last year’s successful introduction of the Clorox Scentiva experiential scent cleaners platform by expanding into new product categories and fragrances.</p>
			</div>
			<div class="valueCopy fade fade--up">
				<ul class="list">
					<ul class="list list--indented">
						<li>RenewLife probiotics (Restore; Mood &amp; Stress; Prenatal; Kids Daily Boost; Kids Ear, Nose &amp; Throat; Baby Colic Drops)</li>
						<li>Fresh Step Clean Paws Triple Action and Fresh Step Clean Paws Multi-Cat with the Power of Febreze cat litter</li>
						<li>Glad<sup>&reg;</sup> ForceFlex Plus, Glad ForceFlex Plus Advanced Protection and Glad OdorShield Gain Moonlight Breeze trash bags; Glad Home Collection containers</li>
						<li>Hidden Valley<sup>&reg;</sup> Ranch Simply Dinners&trade; and Hidden Valley Ranch seasoning shakers</li>
						<li>Clorox Clothes ultra stain remover (Middle East)</li>
						<li>Clorox Triple Accion bleach (Latin America)</li>
						<li>Poett<sup>&reg;</sup> Lov(e)volution<sup>&reg;</sup> cleaners (Latin America)</li>
						<li>Ever Clean<sup>&reg;</sup> Fast Acting Odour Control cat litter (Europe)</li>
					</ul>
				</ul>
			</div>
		</div>
	</div>
	<div class="valueWaveWrap"><img src="../_images/strategy/value/wave1.png"></div>
	<div class="container">
		<div class="row">
			<div class="valueImg valueImg--pushLeft valueImg--large fade fade--right">
				<img src="../_images/strategy/value/image2.jpg">
				<p class="caption">The pop-up Cats on Glass Gallery offered an Instagrammable visual of the new Fresh Step Clean Paws low-tracking&nbsp;litter.</p>
			</div>
			<div class="valueImg valueImg--kingsford valueImg--pushLeft fade fade--left">
				<p class="caption margin-bottom-20">To reach consumers where they are, Kingsford developed content for the Google Assistant to help answer questions about grilling.</p>
				<img src="../_images/strategy/value/image3.jpg">
			</div>
		</div>
		<div class="row">
			<div class="valueCopy valueCopy--centered fade fade--up">
				<div class="floatRight push">
					<img src="../_images/strategy/value/image6.jpg">
					<p class="caption">Our Poett brand partnered with Spotify to build <br>stronger connections with consumers.</p>
				</div>
				<ul class="list">
					<li>Our Burt’s Bees lip balm assumed the No. 1 13-week market share position in the total lip balm category for the first time in its history, achieving that milestone in the fourth quarter of 2018.<sup>1</sup></li> 
					<li>The Kingsford brand announced a multiyear partnership with Major League Baseball that pairs two of America’s favorite pastimes, baseball and barbecuing, around common purposes of connecting with family and friends, enjoying food and fun, and tradition.</li>
					<li>Through a partnership with Google, the Kingsford brand is tapping artificial intelligence (AI) to reach consumers where they are. Consumers can now ask their Google Assistant to “Talk to Kingsford,” and the devices will answer questions about everything from grilling to cleaning grates, storing charcoal and firing up perfect meals over a real charcoal flame.</li>
					<li>Hidden Valley Ranch became the first brand to launch an integrated campaign in partnership with a market-leading online recipe site and the market-leading online retail site, allowing millions of home cooks to purchase Hidden Valley Ranch products and make ranch recipes on the same day.</li>
				</ul>
			</div>
		</div>
		<div class="row">
			<div class="valueCopy valueCopy--left fade fade--right">
				<ul class="list">
					<li>With the insight that many consumers listen to their music and even dance while cleaning, the Pine-Sol<sup>&reg;</sup> brand created a video, “Cleaning Dance Challenge,” with Inanna Sarkis, an Asyrian-Bulgarian Canadian YouTube sensation with 2.7 million subscribers. The video drove over 3.2 million views and generated a 10 percent lift in brand consideration and favorability, according to a YouTube study.</li>
					<li>To launch Fresh Step Clean Paws litter, the brand partnered with the Humane Society of New York to create the Cats on Glass Gallery, a unique pop-up exhibit that featured adoptable cats frolicking on glass above visitors, showcasing their pristine (and litter-free) paws. The event attracted more than 7,000 attendees and garnered more than 90 million media and social impressions.</li>
					<li>In partnership with our Information Technology function, the RenewLife brand launched the company’s first AI chatbot. In its pilot phase, “Sunny” is serving as an educational resource to help consumers select the right products on RenewLife.com. It will expand in fiscal year 2019 to include e-commerce and customer service functions. Learnings from the RenewLife chatbot pilot are intended to inform similar AI initiatives across the company.</li>
				</ul>
			</div>
			<div class="valueImg valueImg--pushRight fade fade--up margin-top-20">
				<img src="../_images/strategy/value/image4.jpg" alt="">
				<p class="caption">Our new Atlanta West Home Care facility supports long-term growth.</p>
			</div>
		</div>
		<div class="row">
			<div class="valueCallout valueCallout--orange fade fade--right">
			WE CONTINUED <br>
			TO LEAD THE <br>
			INDUSTRY WITH <br>
			ABOUT 50 PERCENT <br>
			OF OUR MEDIA <br>
			SPENDING FOCUSED <br>
			ON DIGITAL
			</div>
			<div class="valueCopy valueCopy--col7 fade fade--left">
				<div class="peopleVideo">
					<a href="https://youtu.be/crBWwkEPV-w" data-fancybox><h2 class="peopleVideo__title"><img src="../_images/strategy/people/play.png" class="playButton"> Video: <strong>Atlanta West</strong></h2></a>
				</div>
				<ul class="list">
					<li>We invested in innovation within our supply chain, opening a new, state-of-the-art manufacturing facility in Georgia. Atlanta West is a 258,000-square-foot plant that is using one-of-a-kind technology to capitalize on the momentum behind our Home Care business and support long-term growth.</li>
					<li>With the adoption of more streamlined processes to get products on shelf faster, our Burt’s Bees brand was able to shorten the beauty innovation timeline by six to eight months, a vital need in a category heavily driven by trends and rapid innovation.</li>
					<li>To build stronger connections with consumers, our Poett brand partnered with Spotify to develop music playlists for each of our fragrances. The campaign used local influencers to maximize reach. As a result, there was a positive impact on sales as well as a lift in recall of ads when comparing consumers who had and had not seen them.</li>
					<li>We continued to lead the industry with about 50 percent 
					of our media spending now focused on digital, up from 
					45 percent last year.</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="valueWaveWrap"><img src="../_images/strategy/value/wave2.png"></div>
	<div class="container">
		<div class="row">
			<div class="valueImg valueImg--med valueImg--pushLeft fade fade--right valueImgRightMobile">
				<img src="../_images/strategy/value/image5.jpg" alt="">
			</div>
			<div class="valueCopy fade fade--up">
				<h3 class="heading">Corporate Responsibility Highlights</h3>
				<h4 class="sectionSubHeading">Make responsible products responsibly.</h4>
				<ul class="list">
					<li>The Brita<sup>&reg;</sup> brand’s line of Stream pitchers — introduced in 2017 featuring Filter-As-You-Pour&trade; technology, which allows users to fill the pitcher quickly and pour immediately — no longer require water reservoirs, enabling us to use 30 percent less resin than our standard model with equal capacity.</li>
					<li>The Hidden Valley Ranch brand began an initiative projected to reduce more than 1.5 million pounds of plastic needed for bottles annually while also enhancing the design by replacing the screw-on cap with a flip-cap lid that is easier to open and close.</li>
				</ul>
			</div>
		</div>
		<div class="row">
			<div class="valueCopy valueCopy--left fade fade--right">
				<ul class="list">
					<li>The Kingsford brand addressed the growing consumer interest in products from renewable sources by launching EcoLight charcoal lighter, which is USDA BioPreferred<sup>&reg;</sup>-certified and made with naturally derived ingredients (corn and soybeans).</li>
					<li>The Burt’s Bees brand collaborated with 18 diverse beauty and personal care companies, retail customers and nonprofit organizations to develop a common tool to evaluate product sustainability. The new rating system is intended to help retailers make more sustainable personal care products available and promote those attributes to consumers while also providing an incentive for manufacturers to produce more sustainable products. </li>
					<li>The Burt’s Bees brand launched the free Recycle On Us program in partnership with TerraCycle to enable consumers to recycle the packaging from Burt’s Bees personal care, lip care and beauty care products while raising money for their favorite charitable organization.</li>
				</ul>
				<p class="footnote margin-top-60"><sup>1</sup> IRI, 13 weeks ending June 17, 2018.</p>
			</div>
			<div class="valueCallout valueCallout--uppercase valueCallout--dGreen fade fade--up">
				BRITA <br>
				INTRODUCED <br>
				TWO PITCHERS <br>
				USING 30 PERCENT <br>
				LESS RESIN
			</div>
		</div>
	</div>
	<div class="stratScreen"></div>
	<div class="progressContent progressContent--2">
		<div class="progressTab" data-tab="2">
			<h3 class="progressTab__title">our progress</h3>
			<div class="arrow"></div>
		</div>

		<div class="progressContent--2__left">
			<h2 class="progressContent__heading">We’re on pace to make sustainability improvements to half our portfolio by 2020</h2>

			<p>Since our 2011 baseline, the percentage of our product portfolio with sustainability improvements has increased steadily, from 7 percent in our first year to 49 percent<sup><img src="../_images/scorecard/global/a.svg" class="aNote"></sup> in 2017, our most recent available data.</p>
			<p>To meet our 2020 goal, we have established four pathways for improving the sustainability of our products and packaging, allowing each brand to consider which approach makes the most sense while delivering superior consumer value. These options include 1) reducing materials; 2) using more sustainable materials; 3) reducing the amount of water or energy required by consumers; and 4) sourcing materials more sustainably.</p>
			<p>Most of our product sustainability improvements have been achieved through material reduction in the product or package, or both. This helps minimize the footprint associated 
			with the materials saved and reduce the transportation footprint because we can load more product onto fewer trucks for distribution.</p>
			<p>We’re just shy of our 2020 goal two years ahead of schedule and expect to meet the goal next year. Looking beyond 2020, we anticipate needing to shift more of our efforts beyond material reduction because opportunities for further material efficiency gains will be more limited.</p>
		</div>

		<div class="progressContent--2__right">

			<h3 class="chartHeading chartHeading--lBlue">Product Portfolio with <br>Sustainability Improvements <br><span>(cumulative progress since 2011 base year):</span></h3>
			<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="141.4" height="243.09" viewBox="0 0 141.4 243.09" class="valueChart">
  <defs>
    <clipPath id="clip-path">
      <rect x="56.67" y="68.13" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path-2">
      <rect x="38.12" y="99.13" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path-3">
      <rect x="32.12" y="130.13" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path-4">
      <rect x="19" y="161.13" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path-5">
      <rect x="46.01" y="192.13" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path-6">
      <rect x="32.67" y="223.46" width="11.54" height="15" style="fill: none"/>
    </clipPath>
    <clipPath id="clip-path-7">
      <rect x="54.75" y="18.75" width="22.21" height="28.87" style="fill: none"/>
    </clipPath>
  </defs>
  <title>chart1</title>
  <g>
    <g>
      <path d="M47.32,238.07h-.84l3.84-13.56H47V227h-.76v-3.14h4.86v.6Z" style="fill: #82c341"/>
      <path d="M55.06,231.15a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,55.06,231.15Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56h-.68l5-14.24h.68Zm5,.16A1.72,1.72,0,0,1,59,236.39v-3.8a1.77,1.77,0,1,1,3.53,0v3.8A1.71,1.71,0,0,1,60.75,238.23Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M2.87,238.42a1.18,1.18,0,0,1-.88.31,1.23,1.23,0,0,1-1-.41c-.4-.43-.42-1.08-.42-2.5s0-2.07.42-2.5a1.23,1.23,0,0,1,1-.41,1.25,1.25,0,0,1,.91.34,1.6,1.6,0,0,1,.4,1.13H2.62a1,1,0,0,0-.18-.65.54.54,0,0,0-.45-.2.52.52,0,0,0-.46.21c-.2.27-.24.73-.24,2.08s0,1.81.24,2.08a.53.53,0,0,0,.46.22.54.54,0,0,0,.45-.21,1,1,0,0,0,.18-.65h.69A1.61,1.61,0,0,1,2.87,238.42Z" style="fill: #82c341"/>
      <path d="M5.36,236.36v2.31H4.67v-2.31l-1-3.39h.76L5,235.4,5.66,233h.76Z" style="fill: #82c341"/>
      <path d="M7.8,238.67v-4.94l-.83.68v-.75L7.8,233h.65v5.7Z" style="fill: #82c341"/>
      <path d="M9.87,238.67v-.55l1.39-3a2.54,2.54,0,0,0,.26-1.1c0-.38-.22-.58-.49-.58s-.49.2-.49.58v.38H9.89v-.37a1.14,1.14,0,0,1,.32-.87,1.21,1.21,0,0,1,.82-.3,1.08,1.08,0,0,1,1.14,1.18,3.2,3.2,0,0,1-.33,1.29l-1.27,2.7h1.6v.59Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M61.11,206.51V193.16l-2,1.8v-1l2-1.74h.76v14.25Z" style="fill: #82c341"/>
      <path d="M69.91,205.91a2.13,2.13,0,0,1-1.64.76,2.36,2.36,0,0,1-1.64-.6,2.55,2.55,0,0,1-.7-1.92v-1h.76v.94c0,1.34.7,1.92,1.58,1.92a1.31,1.31,0,0,0,1.08-.54c.4-.54.54-1.16.54-3.38s-.16-2.86-.56-3.4a1.25,1.25,0,0,0-1.06-.52,1.64,1.64,0,0,0-1.58,1.8v.8H66v-8.49h4.46v.68H66.69v5.49a1.84,1.84,0,0,1,.64-.66,1.81,1.81,0,0,1,1.08-.28,1.88,1.88,0,0,1,1.52.74c.58.7.72,1.46.72,3.84S70.49,205.21,69.91,205.91Z" style="fill: #82c341"/>
      <path d="M74.65,199.59a1.71,1.71,0,0,1-1.76-1.84v-3.81a1.76,1.76,0,1,1,3.52,0v3.81A1.71,1.71,0,0,1,74.65,199.59Zm1.06-5.65c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.81c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.57h-.68l5-14.25h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84V201a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,80.33,206.67ZM81.39,201c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M2.87,206.73A1.18,1.18,0,0,1,2,207a1.23,1.23,0,0,1-1-.41c-.4-.43-.42-1.08-.42-2.5s0-2.07.42-2.5a1.23,1.23,0,0,1,1-.41,1.28,1.28,0,0,1,.91.33,1.64,1.64,0,0,1,.4,1.14H2.62a1.07,1.07,0,0,0-.18-.66.54.54,0,0,0-.45-.2.53.53,0,0,0-.46.22c-.2.27-.24.73-.24,2.08s0,1.81.24,2.08a.52.52,0,0,0,.46.21.54.54,0,0,0,.45-.2,1,1,0,0,0,.18-.65h.69A1.61,1.61,0,0,1,2.87,206.73Z" style="fill: #82c341"/>
      <path d="M5.36,204.67V207H4.67v-2.31l-1-3.39h.76L5,203.71l.64-2.43h.76Z" style="fill: #82c341"/>
      <path d="M7.8,207V202l-.83.68V202l.83-.69h.65V207Z" style="fill: #82c341"/>
      <path d="M11.8,206.74a1.26,1.26,0,0,1-1.63,0,1.14,1.14,0,0,1-.33-.88v-.36h.65v.38c0,.38.22.58.49.58a.44.44,0,0,0,.36-.16,1.63,1.63,0,0,0,.16-1c0-.56,0-.8-.16-1a.41.41,0,0,0-.36-.16h-.3v-.55H11a.43.43,0,0,0,.32-.13,2.14,2.14,0,0,0,0-1.6.41.41,0,0,0-.33-.14c-.26,0-.45.19-.45.56v.4H9.88v-.37a1.16,1.16,0,0,1,.31-.88,1.13,1.13,0,0,1,.79-.29,1.07,1.07,0,0,1,.79.29,1.54,1.54,0,0,1,.33,1.18,1.84,1.84,0,0,1-.15.93.89.89,0,0,1-.31.33.87.87,0,0,1,.32.31,2,2,0,0,1,.19,1.12C12.15,206.06,12.11,206.42,11.8,206.74Z" style="fill: #82c341"/>
    </g>
    <g class="bar" id="bar1">
      <rect x="18.33" y="67.55" width="83.4" height="16.29" style="fill: #005cb9"/>
    </g>
    <g>
      <path d="M2.87,80.09A1.22,1.22,0,0,1,2,80.4,1.23,1.23,0,0,1,1,80c-.4-.43-.42-1.08-.42-2.5S.62,75.42,1,75a1.22,1.22,0,0,1,1-.4,1.28,1.28,0,0,1,.91.33,1.64,1.64,0,0,1,.4,1.14H2.62a1.07,1.07,0,0,0-.18-.66.54.54,0,0,0-.45-.2.53.53,0,0,0-.46.22c-.2.27-.24.73-.24,2.08s0,1.8.24,2.08a.55.55,0,0,0,.46.21.54.54,0,0,0,.45-.21,1,1,0,0,0,.18-.64h.69A1.61,1.61,0,0,1,2.87,80.09Z" style="fill: #005cb9"/>
      <path d="M5.36,78v2.3H4.67V78l-1-3.39h.76L5,77.07l.64-2.43h.76Z" style="fill: #005cb9"/>
      <path d="M7.8,80.33V75.4L7,76.08v-.75l.83-.69h.65v5.69Z" style="fill: #005cb9"/>
      <path d="M10.69,80.33H10l1.51-5.11H10.43v.84H9.8V74.64h2.39v.54Z" style="fill: #005cb9"/>
    </g>
    <g class="bar" id="bar2">
      <rect x="18.33" y="98.54" width="58.14" height="16.29" transform="translate(-0.4 0.18) rotate(-0.22)" style="fill: #82c341"/>
      <g>
        <path d="M2.86,111.86a1.22,1.22,0,0,1-.88.32,1.25,1.25,0,0,1-1-.41c-.39-.43-.42-1.07-.42-2.5s0-2.07.4-2.5a1.25,1.25,0,0,1,1-.41,1.2,1.2,0,0,1,.9.33,1.56,1.56,0,0,1,.41,1.13H2.59a1.07,1.07,0,0,0-.18-.66A.54.54,0,0,0,2,107a.52.52,0,0,0-.46.22c-.2.27-.24.73-.24,2.08s.05,1.81.25,2.08a.54.54,0,0,0,.47.21.52.52,0,0,0,.44-.21,1,1,0,0,0,.18-.65h.69A1.56,1.56,0,0,1,2.86,111.86Z" style="fill: #82c341"/>
        <path d="M5.34,109.8v2.3H4.66v-2.3l-1.06-3.38h.75L5,108.84l.63-2.43h.76Z" style="fill: #82c341"/>
        <path d="M7.79,112.09l0-4.93-.83.68v-.75l.83-.69h.64l0,5.69Z" style="fill: #82c341"/>
        <path d="M11.87,111.76a1.08,1.08,0,0,1-.88.38,1,1,0,0,1-.88-.38,2,2,0,0,1-.29-1.38,4,4,0,0,1,.23-1.43l.95-2.56h.66l-.92,2.38a.72.72,0,0,1,.41-.14.87.87,0,0,1,.7.33c.21.25.29.51.3,1.42A2.15,2.15,0,0,1,11.87,111.76Zm-.53-2.43a.46.46,0,0,0-.36-.16.48.48,0,0,0-.36.16,1.89,1.89,0,0,0-.15,1,1.83,1.83,0,0,0,.16,1,.45.45,0,0,0,.35.15.45.45,0,0,0,.36-.15,1.87,1.87,0,0,0,.16-1A1.83,1.83,0,0,0,11.34,109.33Z" style="fill: #82c341"/>
      </g>
      <g>
        <path d="M55.22,113.32a2.41,2.41,0,0,1-3.28.05,2.42,2.42,0,0,1-.69-1.89v-1H52v1c0,1.22.71,1.84,1.57,1.84a1.34,1.34,0,0,0,1.06-.45c.39-.46.55-1,.54-2.92,0-2.16-.13-2.54-.57-3a1.35,1.35,0,0,0-1.06-.43h-.86v-.68h.86a1.29,1.29,0,0,0,1-.39c.38-.4.51-1,.51-2.48s-.17-2.08-.51-2.46a1.37,1.37,0,0,0-1-.4c-.86,0-1.46.63-1.46,1.85v1h-.76v-1a2.49,2.49,0,0,1,.64-1.9,2.37,2.37,0,0,1,3.16,0c.5.5.68,1.14.69,2.94a4.39,4.39,0,0,1-.39,2.48,2,2,0,0,1-.8.72,2.23,2.23,0,0,1,.78.62c.4.54.55.92.55,3.16S55.79,112.7,55.22,113.32Z" style="fill: #fff"/>
        <path d="M62.33,111.23v2.56h-.76v-2.56h-3.7v-.68l3.55-11h.77l-3.56,11h2.94l0-4.52h.76l0,4.52h1v.68Z" style="fill: #fff"/>
        <path d="M67,106.86A1.71,1.71,0,0,1,65.19,105l0-3.8a1.76,1.76,0,1,1,3.52,0l0,3.8A1.73,1.73,0,0,1,67,106.86Zm1-5.65c0-.74-.36-1.22-1.06-1.22s-1.06.49-1.06,1.23l0,3.8c0,.74.36,1.22,1.06,1.22S68,105.75,68,105Zm-.31,12.56H67l4.9-14.26h.69Zm5,.15a1.73,1.73,0,0,1-1.77-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,72.66,113.92Zm1-5.65c0-.74-.37-1.22-1.07-1.22s-1,.49-1,1.23v3.8c0,.74.37,1.22,1.07,1.22s1.06-.49,1-1.23Z" style="fill: #fff"/>
      </g>
    </g>
    <g class="bar" id="bar3">
      <rect x="18.33" y="129.37" width="53.01" height="16.29" style="fill: #82c341"/>
      <g>
        <path d="M2.87,143.18a1.18,1.18,0,0,1-.88.31,1.23,1.23,0,0,1-1-.41c-.4-.43-.42-1.08-.42-2.5s0-2.07.42-2.5a1.23,1.23,0,0,1,1-.41,1.28,1.28,0,0,1,.91.33,1.64,1.64,0,0,1,.4,1.14H2.62a1.07,1.07,0,0,0-.18-.66.54.54,0,0,0-.45-.2.53.53,0,0,0-.46.22c-.2.27-.24.73-.24,2.08s0,1.81.24,2.08a.52.52,0,0,0,.46.21.54.54,0,0,0,.45-.2,1,1,0,0,0,.18-.65h.69A1.61,1.61,0,0,1,2.87,143.18Z" style="fill: #82c341"/>
        <path d="M5.36,141.12v2.31H4.67v-2.31l-1-3.39h.76L5,140.16l.64-2.43h.76Z" style="fill: #82c341"/>
        <path d="M7.8,143.43v-4.94l-.83.68v-.75l.83-.69h.65v5.7Z" style="fill: #82c341"/>
        <path d="M11.82,143.16a1.13,1.13,0,0,1-.82.33,1.17,1.17,0,0,1-.82-.3,1.13,1.13,0,0,1-.32-.88V142h.64v.38c0,.42.22.6.5.6a.44.44,0,0,0,.36-.18,2.29,2.29,0,0,0,.16-1.18,2.21,2.21,0,0,0-.15-1.13.44.44,0,0,0-.37-.2.52.52,0,0,0-.5.58v.19H9.89v-3.32H12.1v.59H10.48v1.76a1.2,1.2,0,0,1,.28-.27.9.9,0,0,1,.42-.1.88.88,0,0,1,.72.32c.24.29.27.74.27,1.53S12.15,142.82,11.82,143.16Z" style="fill: #82c341"/>
      </g>
      <g>
        <path d="M49.89,144.38a2.42,2.42,0,0,1-3.28,0,2.49,2.49,0,0,1-.68-1.9v-1h.76v1c0,1.22.7,1.84,1.56,1.84a1.36,1.36,0,0,0,1.06-.44c.4-.46.56-1,.56-2.92,0-2.17-.12-2.55-.56-3a1.39,1.39,0,0,0-1.06-.44h-.86v-.68h.86a1.28,1.28,0,0,0,1-.38c.38-.4.52-1,.52-2.48s-.16-2.08-.5-2.46a1.37,1.37,0,0,0-1-.4c-.86,0-1.46.62-1.46,1.84v1H46v-1a2.49,2.49,0,0,1,.64-1.9,2.35,2.35,0,0,1,3.16,0c.5.5.68,1.14.68,2.94a4.36,4.36,0,0,1-.4,2.48,2,2,0,0,1-.8.72,2.23,2.23,0,0,1,.78.62c.4.54.54.92.54,3.17C50.63,143.1,50.47,143.76,49.89,144.38Z" style="fill: #fff"/>
        <path d="M55,144.88V131.53l-2,1.8v-1l2-1.74h.76v14.25Z" style="fill: #fff"/>
        <path d="M61.65,138a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,61.65,138Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.57h-.68l5-14.25h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.81a1.76,1.76,0,1,1,3.52,0v3.81A1.71,1.71,0,0,1,67.33,145Zm1.06-5.65c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.81c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #fff"/>
      </g>
    </g>
    <g class="bar" id="bar4">
      <rect x="18.33" y="160.39" width="37.33" height="16.29" style="fill: #82c341"/>
    </g>

    <g class="bar" id="bar5">
      <rect x="18.33" y="191.64" width="25.65" height="16.29" style="fill: #82c341"/>
    </g>
    <g class="bar" id="bar6">
      <rect x="18.33" y="222.7" width="11.97" height="16.29" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M2.87,174.84a1.18,1.18,0,0,1-.88.31,1.22,1.22,0,0,1-1-.4c-.4-.44-.42-1.08-.42-2.51s0-2.07.42-2.5a1.23,1.23,0,0,1,1-.41,1.25,1.25,0,0,1,.91.34,1.6,1.6,0,0,1,.4,1.13H2.62a1.06,1.06,0,0,0-.18-.65A.54.54,0,0,0,2,170a.53.53,0,0,0-.46.22c-.2.27-.24.72-.24,2.07s0,1.81.24,2.08a.53.53,0,0,0,.46.22.54.54,0,0,0,.45-.21,1,1,0,0,0,.18-.65h.69A1.59,1.59,0,0,1,2.87,174.84Z" style="fill: #80c241"/>
      <path d="M5.36,172.79v2.3H4.67v-2.3l-1-3.39h.76L5,171.83l.64-2.43h.76Z" style="fill: #80c241"/>
      <path d="M7.8,175.09v-4.93l-.83.68v-.76l.83-.68h.65v5.69Z" style="fill: #80c241"/>
      <path d="M11.9,174.15v.94h-.64v-.94H9.71v-.58l1.46-4.17h.62l-1.41,4.17h.88v-1.3h.64v1.3h.4v.58Z" style="fill: #80c241"/>
    </g>
    <g>
      <path d="M30.84,175.8v-.62L34.16,167a8.08,8.08,0,0,0,.72-3.14c0-1.22-.68-1.82-1.54-1.82s-1.54.6-1.54,1.82v1H31v-1A2.48,2.48,0,0,1,31.7,162,2.42,2.42,0,0,1,35,162a2.49,2.49,0,0,1,.66,1.9,9.52,9.52,0,0,1-.82,3.38l-3.18,7.8h4v.68Z" style="fill: #fff"/>
      <path d="M41.8,175.32a2.42,2.42,0,0,1-3.28,0,2.49,2.49,0,0,1-.66-1.9v-9.48a2.49,2.49,0,0,1,.66-1.9,2.42,2.42,0,0,1,3.28,0,2.49,2.49,0,0,1,.66,1.9v9.48A2.49,2.49,0,0,1,41.8,175.32Zm-.1-11.42c0-1.22-.68-1.82-1.54-1.82s-1.54.6-1.54,1.82v9.56c0,1.22.68,1.82,1.54,1.82s1.54-.6,1.54-1.82Z" style="fill: #fff"/>
      <path d="M46.54,168.88A1.71,1.71,0,0,1,44.78,167v-3.8a1.76,1.76,0,1,1,3.52,0V167A1.71,1.71,0,0,1,46.54,168.88Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22V167c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Zm-.36,12.56h-.68l5-14.24h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,52.22,176Zm1.06-5.64c0-.74-.36-1.22-1.06-1.22s-1.06.48-1.06,1.22v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #fff"/>
    </g>
    <g>
      <path d="M91.77,45.85a6.5,6.5,0,0,1-4.61,1.79A6.74,6.74,0,0,1,82.5,46a6.21,6.21,0,0,1-1.83-4.86V39.68H85v2c0,1.76.94,2.53,2.17,2.53a1.76,1.76,0,0,0,1.59-.77c.65-.86.65-3.11.65-5.52s0-4.24-.57-5.14a1.86,1.86,0,0,0-1.67-.9A2.2,2.2,0,0,0,85,34.37V35H80.87V18.24H93.41v3.88H84.83v7.8a5.54,5.54,0,0,1,1.51-1.39A4.58,4.58,0,0,1,88.42,28a4.53,4.53,0,0,1,3.92,1.76c1.23,1.51,1.39,4.2,1.39,7.76C93.73,41.35,93.69,43.93,91.77,45.85Z" style="fill: #929497"/>
      <path d="M108.15,45.93a6.66,6.66,0,0,1-4.62,1.71,6.74,6.74,0,0,1-4.65-1.71A6.09,6.09,0,0,1,97,41.11V24.45a6.09,6.09,0,0,1,1.84-4.82,6.74,6.74,0,0,1,4.65-1.71,6.66,6.66,0,0,1,4.62,1.71A6.12,6.12,0,0,1,110,24.45V41.11A6.12,6.12,0,0,1,108.15,45.93Zm-2.49-21.64c0-1.68-.94-2.49-2.13-2.49s-2.16.81-2.16,2.49v17c0,1.68,1,2.49,2.16,2.49s2.13-.81,2.13-2.49Z" style="fill: #929497"/>
      <path d="M118.8,33.15c-2.77,0-5.18-1.68-5.18-4.9V22.82c0-3.23,2.41-4.9,5.18-4.9s5.19,1.67,5.19,4.9v5.43C124,31.47,121.58,33.15,118.8,33.15Zm1.64-10.25c0-1.27-.66-1.84-1.64-1.84s-1.67.57-1.67,1.84v5.27c0,1.26.69,1.83,1.67,1.83s1.64-.57,1.64-1.83Zm2.86,24.42H120l10.12-29.08h3.35Zm11.18.32c-2.77,0-5.18-1.67-5.18-4.9V37.31c0-3.22,2.41-4.9,5.18-4.9s5.19,1.68,5.19,4.9v5.43C139.67,46,137.26,47.64,134.48,47.64Zm1.64-10.25c0-1.26-.66-1.83-1.64-1.83s-1.63.57-1.63,1.83v5.27c0,1.27.65,1.84,1.63,1.84s1.64-.57,1.64-1.84Z" style="fill: #929497"/>
    </g>
    <g>
      <path d="M84.69,13.39a2.35,2.35,0,0,1-1.6.56,2.26,2.26,0,0,1-1.73-.69c-.73-.78-.81-1.7-.81-5.26s.08-4.47.81-5.25a2.54,2.54,0,0,1,3.4-.07,3.15,3.15,0,0,1,.75,2.17h-1a2.27,2.27,0,0,0-.46-1.53,1.26,1.26,0,0,0-1-.39,1.3,1.3,0,0,0-1,.42c-.47.57-.55,1.24-.55,4.65s.08,4.09.55,4.66a1.47,1.47,0,0,0,2,0,2.29,2.29,0,0,0,.46-1.53h1A3,3,0,0,1,84.69,13.39Z" style="fill: #929497"/>
      <path d="M89.23,9v4.87h-1V9l-2-6.76h1.06l1.46,5.32,1.46-5.32h1.07Z" style="fill: #929497"/>
      <path d="M92.16,13.82v-.77l2.77-6.37a6,6,0,0,0,.56-2.45c0-.91-.51-1.35-1.14-1.35s-1.16.44-1.16,1.35v.84h-.92V4.25a2.14,2.14,0,0,1,.59-1.62,2.19,2.19,0,0,1,1.49-.57,2,2,0,0,1,1.45.56,2.19,2.19,0,0,1,.6,1.66A7.25,7.25,0,0,1,95.73,7l-2.59,6H96.4v.82Z" style="fill: #929497"/>
      <path d="M101.65,13.38a2.21,2.21,0,0,1-1.49.57,2,2,0,0,1-2.06-2.22V4.28a2.16,2.16,0,0,1,.59-1.65,2.16,2.16,0,0,1,1.47-.57,2.21,2.21,0,0,1,1.49.57,2.16,2.16,0,0,1,.58,1.65v7.45A2.16,2.16,0,0,1,101.65,13.38Zm-.33-9.15c0-.91-.52-1.35-1.16-1.35S99,3.32,99,4.23v7.55c0,.91.5,1.35,1.14,1.35s1.16-.44,1.16-1.35Z" style="fill: #929497"/>
    </g>
    <g>
      <path d="M110,14a2.89,2.89,0,0,1-2.35-1c-.9-1-.88-2.79-.88-5.17s0-4.14.88-5.16a2.89,2.89,0,0,1,2.35-1,2.94,2.94,0,0,1,2.16.81A3.73,3.73,0,0,1,113.12,5h-1.9c0-.68-.17-1.63-1.19-1.63a1,1,0,0,0-.9.46c-.36.58-.43,1.8-.43,4s.07,3.44.43,4a1,1,0,0,0,.9.46c.81,0,1.19-.71,1.19-1.54V8.84H110V7.28h3.09v3.34C113.12,12.82,111.83,14,110,14Z" style="fill: #929497"/>
      <path d="M120.11,13a3.21,3.21,0,0,1-4.69,0c-.9-1-.89-2.79-.89-5.17s0-4.14.89-5.16a3.21,3.21,0,0,1,4.69,0c.9,1,.88,2.78.88,5.16S121,12,120.11,13Zm-1.43-9.18a1,1,0,0,0-.92-.46,1,1,0,0,0-.9.46c-.36.58-.42,1.8-.42,4s.06,3.44.42,4a1,1,0,0,0,.9.46,1,1,0,0,0,.92-.46c.36-.57.41-1.8.41-4S119,4.37,118.68,3.79Z" style="fill: #929497"/>
      <path d="M127.55,13.85l-.49-2.39h-2.8l-.48,2.39h-2l3-12.1h1.85l2.94,12.1Zm-1.88-9.18-1,5.07h2.07Z" style="fill: #929497"/>
      <path d="M130.67,13.85V1.75h1.9V12.14h3.18v1.71Z" style="fill: #929497"/>
    </g>
    <line x1="104.17" y1="241.33" x2="104.17" y2="52.33" style="fill: none;stroke: #929497;stroke-linecap: round;stroke-linejoin: round"/>
    <g style="clip-path: url(#clip-path)">
      <path d="M62.61,68.16a.5.5,0,0,0-.34,0,.67.67,0,0,0-.14.09L56.8,73.4a.42.42,0,0,0,0,.6.45.45,0,0,0,.63,0L62,69.59V82.7a.45.45,0,0,0,.89,0V69.59L67.46,74a.44.44,0,0,0,.62,0,.41.41,0,0,0,0-.6l-5.32-5.15a.54.54,0,0,0-.15-.09" style="fill: #fff"/>
    </g>
    <g style="clip-path: url(#clip-path-2)">
      <path d="M44.06,99.16a.5.5,0,0,0-.34,0l-.15.09-5.32,5.15a.42.42,0,0,0,0,.6.45.45,0,0,0,.63,0l4.57-4.41V113.7a.44.44,0,0,0,.88,0V100.59L48.9,105a.45.45,0,0,0,.63,0,.41.41,0,0,0,0-.6L44.2,99.25a.67.67,0,0,0-.14-.09" style="fill: #fff"/>
    </g>
    <g style="clip-path: url(#clip-path-3)">
      <path d="M38.06,130.16a.5.5,0,0,0-.34,0l-.15.09-5.32,5.15a.42.42,0,0,0,0,.6.45.45,0,0,0,.63,0l4.57-4.41V144.7a.44.44,0,0,0,.88,0V131.59L42.9,136a.45.45,0,0,0,.63,0,.41.41,0,0,0,0-.6l-5.33-5.15a.67.67,0,0,0-.14-.09" style="fill: #fff"/>
    </g>
    <g style="clip-path: url(#clip-path-4)">
      <path d="M24.94,161.16a.5.5,0,0,0-.34,0,.75.75,0,0,0-.15.09l-5.32,5.15a.42.42,0,0,0,0,.6.45.45,0,0,0,.63,0l4.57-4.41V175.7a.44.44,0,0,0,.88,0V162.59L29.78,167a.45.45,0,0,0,.63,0,.41.41,0,0,0,0-.6l-5.33-5.15a.67.67,0,0,0-.14-.09" style="fill: #fff"/>
    </g>
    <g style="clip-path: url(#clip-path-5)">
      <path d="M52,192.16a.5.5,0,0,0-.34,0,.54.54,0,0,0-.15.09l-5.32,5.15a.4.4,0,0,0,0,.6.44.44,0,0,0,.62,0l4.57-4.41V206.7a.45.45,0,0,0,.89,0V193.59L56.79,198a.45.45,0,0,0,.63,0,.41.41,0,0,0,0-.6l-5.33-5.15a.67.67,0,0,0-.14-.09" style="fill: #82c341"/>
    </g>
    <g style="clip-path: url(#clip-path-6)">
      <path d="M38.61,223.49a.5.5,0,0,0-.34,0,.71.71,0,0,0-.14.1l-5.33,5.14a.43.43,0,0,0,0,.61.47.47,0,0,0,.63,0L38,224.93V238a.45.45,0,0,0,.89,0v-13.1l4.57,4.41a.46.46,0,0,0,.62,0,.43.43,0,0,0,.13-.31.39.39,0,0,0-.13-.3l-5.32-5.14a.56.56,0,0,0-.15-.1" style="fill: #82c341"/>
    </g>
    <g>
      <path d="M74.45,80.23v2.56h-.76V80.23H70v-.68l3.6-11h.76l-3.6,11h2.94V75h.76v4.53h1v.68Z" style="fill: #fff"/>
      <path d="M81.43,76.69l-2.22,6.1h-.74l2.28-6.26a1.91,1.91,0,0,1-1.28.48A2,2,0,0,1,78,76.37c-.52-.56-.7-1.06-.7-3.67,0-2.26.12-3,.74-3.66a2.37,2.37,0,0,1,3.28,0c.62.68.74,1.4.74,3.66A10.89,10.89,0,0,1,81.43,76.69Zm-.72-7.19a1.55,1.55,0,0,0-2.16,0c-.46.48-.54,1.28-.54,3.2s.08,2.72.54,3.21a1.55,1.55,0,0,0,2.16,0c.46-.49.54-1.29.54-3.21S81.17,70,80.71,69.5Z" style="fill: #fff"/>
      <path d="M86,75.87A1.72,1.72,0,0,1,84.25,74v-3.8a1.76,1.76,0,1,1,3.52,0V74A1.72,1.72,0,0,1,86,75.87Zm1.06-5.65c0-.74-.36-1.22-1.06-1.22S85,69.48,85,70.22V74c0,.75.36,1.23,1.06,1.23s1.06-.48,1.06-1.23Zm-.36,12.57H86l5-14.25h.68Zm5,.16a1.71,1.71,0,0,1-1.76-1.84v-3.8a1.76,1.76,0,1,1,3.52,0v3.8A1.71,1.71,0,0,1,91.69,83Zm1.06-5.64c0-.74-.36-1.23-1.06-1.23s-1.06.49-1.06,1.23v3.8c0,.74.36,1.22,1.06,1.22s1.06-.48,1.06-1.22Z" style="fill: #fff"/>
    </g>
    <g>
      <polygon points="96.83 68.41 93.14 71.54 96.87 74.68 100.56 71.55 96.83 68.41" style="fill: #057dc1"/>
      <path d="M96.3,71.55l.54-1.66.52,1.66Zm.29-2-1.13,3.39h.41l.33-1h1.26l.32,1h.46l-1.12-3.39Z" style="fill: #fff"/>
    </g>
    <g style="clip-path: url(#clip-path-7)">
      <path d="M66.18,18.81a.91.91,0,0,0-.65,0,.92.92,0,0,0-.28.19L55,28.89a.8.8,0,0,0,0,1.17.88.88,0,0,0,1.21,0L65,21.57V46.8a.86.86,0,0,0,1.71,0V21.57l8.79,8.49a.88.88,0,0,0,1.21,0,.79.79,0,0,0,.25-.58.81.81,0,0,0-.25-.59L66.46,19a1.07,1.07,0,0,0-.28-.19" style="fill: #929497"/>
    </g>
  </g>
</svg>

			<p class="footnote margin-top-40"><img src="../_images/scorecard/global/a.svg" class="aNote"> Reviewed by Ernst &amp; Young LLP. Please refer to the <a href="../financials/index.php#review" class="link hideLinkMobile">Review Report</a><a href="../financials/nonfinancial.pdf" class="link mobileLinkOnly" target="_blank">Review Report</a>.</p>
		</div>
	</div>
</div>
<div class="subnav subnav--strategy">
	<div class="container">
		<div class="row">
			<ul class="subNav__items">
				<li><a href="index.php">2020 <br>Strategy</a></li>
				<li><a href="people.php">Engage Our <br>People</a></li>
				<li><a href="value.php">Drive Superior <br>Consumer Value</a></li>
				<li><a href="portfolio.php">Accelerate <br>Portfolio Momentum</a></li>
				<li><a href="growth.php">Fund <br>Growth</a></li>
			</ul>
		</div>
	</div>
</div>
<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="../_js/jquery.fancybox.min.js"></script>
<script src="../_js/jquery.mousewheel.js"></script>
<script src="../_js/greensock/TimelineMax.min.js"></script>
<script src="../_js/greensock/TweenMax.min.js"></script>
<script src="../_js/ScrollMagic.js"></script>
<script src="../_js/plugins/jquery.ScrollMagic.js"></script>
<script src="../_js/plugins/debug.addIndicators.js"></script>
<script src="../_js/greensock/plugins/DrawSVGPlugin.min.js"></script>
<script src="../_js/plugins/animation.gsap.js"></script>
<script src="../_js/jquery.cycle2.min.js"></script>
<script src="../_js/main.js?v.2018.2"></script><script>strategy();</script>
</body>
</html>